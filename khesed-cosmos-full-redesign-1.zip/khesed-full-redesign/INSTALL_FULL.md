# Khesed-Tek Cosmos Design System — Full Frontend Redesign
## Complete Installation Guide v2.0

---

## What's in this package

```
styles/
  globals.css                    → REPLACE app/globals.css entirely

config/
  tailwind.config.ts             → REPLACE tailwind.config.ts entirely

components/
  ui/
    badge.tsx                    → REPLACE components/ui/badge.tsx
    button.tsx                   → REPLACE components/ui/button.tsx
    card.tsx                     → REPLACE components/ui/card.tsx
  layout/
    cosmos-sidebar.tsx           → REPLACE components/layout/mobile-sidebar.tsx
    cosmos-header.tsx            → REPLACE components/layout/header.tsx
  cosmos/
    cosmos-background.tsx        → NEW — add to root layout
    constellation-map.tsx        → NEW — dashboard widget
    cosmos-stat-card.tsx         → NEW — animated stat cards
  volunteers/
    coverage-cosmos-card.tsx     → NEW — Agent 12 UI
  dashboard/
    shepherds-log-cosmos.tsx     → NEW — Agent 5 UI
  triage/
    triage-cosmos-alert.tsx      → NEW — Agent 2 UI

app/
  dashboard-layout.tsx           → REPLACE app/(dashboard)/layout.tsx
  cosmos-dashboard.tsx           → REPLACE home/dashboard-client.tsx
  members-page.tsx               → REPLACE members page client
  prayer-wall-page.tsx           → REPLACE prayer-wall page client
  visitor-followups-page.tsx     → REPLACE visitor-follow-ups page client
  checkins-page.tsx              → REPLACE check-ins page client

lib/
  chart-colors.ts                → NEW — import in all Recharts components

hooks/
  use-mouse-trail.ts             → NEW — add to root layout
```

---

## STEP 1 — Replace globals.css (most impactful, affects everything)

```bash
cp styles/globals.css app/globals.css
```

This single step fixes:
- ✅ P1-A: Success/warning tokens added
- ✅ P1-B: btn-cta-gradient utility class defined
- ✅ P1-C: Status/priority badge CSS classes
- ✅ P1-D: nav-section-btn uses accent tokens
- ✅ P2-A: --accent is now distinct from --muted
- ✅ P2-B: --success and --warning tokens added
- ✅ P2-C: --primary is now gold (brand color)
- ✅ P4-A: Gradient classes use CSS vars
- ✅ P4-B: Recharts global dark mode styles

---

## STEP 2 — Replace tailwind.config.ts

```bash
cp config/tailwind.config.ts tailwind.config.ts
```

Adds:
- `text-gold`, `bg-cosmos`, `glow-gold` utilities
- `font-display` (Cinzel) + `font-body` (DM Sans)
- `success`, `warning`, `info` color tokens
- Chart colors: `chart-1` through `chart-6`
- Extended animations: `fade-up`, `live-pulse`, etc.

---

## STEP 3 — Add fonts to layout.tsx

```tsx
// app/layout.tsx
import { Cinzel, DM_Sans } from 'next/font/google';

const cinzel = Cinzel({
  subsets: ['latin'],
  weight: ['400', '600', '700'],
  variable: '--font-display',
  display: 'swap',
});

const dmSans = DM_Sans({
  subsets: ['latin'],
  weight: ['300', '400', '500'],
  variable: '--font-body',
  display: 'swap',
});

export default function RootLayout({ children }) {
  return (
    <html lang="es" className={`${cinzel.variable} ${dmSans.variable}`}>
      <body>{children}</body>
    </html>
  );
}
```

---

## STEP 4 — Replace core UI components

```bash
# Replace one at a time, test between each:
cp components/ui/badge.tsx  components/ui/badge.tsx.backup
cp components/ui/badge.tsx  [your-project]/components/ui/badge.tsx

cp components/ui/button.tsx components/ui/button.tsx.backup
cp components/ui/button.tsx [your-project]/components/ui/button.tsx

cp components/ui/card.tsx   components/ui/card.tsx.backup
cp components/ui/card.tsx   [your-project]/components/ui/card.tsx
```

---

## STEP 5 — Replace layout components

```bash
cp components/layout/cosmos-sidebar.tsx [your-project]/components/layout/mobile-sidebar.tsx
cp components/layout/cosmos-header.tsx  [your-project]/components/layout/header.tsx
```

Update your `app/(dashboard)/layout.tsx` to use these:
```tsx
import { CosmosBackground } from '@/components/cosmos/cosmos-background';
import { CosmosSidebar }    from '@/components/layout/cosmos-sidebar';
import { CosmosHeader }     from '@/components/layout/cosmos-header';
import { useMouseTrail }    from '@/hooks/use-mouse-trail';
```

Replace the layout grid:
```tsx
<div className="relative min-h-screen bg-[hsl(var(--brand-navy-deep))] overflow-hidden">
  <CosmosBackground />
  <div className="relative z-content grid h-screen"
       style={{ gridTemplateRows: '56px 1fr', gridTemplateColumns: '216px 1fr' }}>
    <div className="col-span-2"><CosmosHeader /></div>
    <CosmosSidebar />
    <main className="overflow-y-auto cosmos-scrollbar p-4 lg:p-6">
      {children}
    </main>
  </div>
</div>
```

---

## STEP 6 — Fix all Recharts components

```bash
cp lib/chart-colors.ts [your-project]/lib/chart-colors.ts
```

In every file with Recharts, replace hardcoded colors:

```tsx
// BEFORE (scattered hex values):
<Line stroke="#3b82f6" />
<Bar fill="#10b981" />
<CartesianGrid stroke="rgba(255,255,255,0.1)" />

// AFTER (centralized):
import { CHART_COLORS, DARK_CHART_GRID, DARK_CHART_AXIS } from '@/lib/chart-colors';
<Line stroke={CHART_COLORS.gold} />
<Bar fill={CHART_COLORS.emerald} />
<CartesianGrid stroke={DARK_CHART_GRID} />
<XAxis tick={{ fill: DARK_CHART_AXIS }} />
```

Files to update (from audit):
- `app/(dashboard)/social-media/_components/analytics-dashboard.tsx`
- `app/(dashboard)/prayer-wall/page.tsx`
- `app/(dashboard)/analytics/` (all chart components)
- `app/(dashboard)/home/_components/dashboard-client.tsx`

---

## STEP 7 — Fix remaining hardcoded colors

### CTA buttons (P1-B):

Search your codebase for:
```
from-blue-500 to-purple-600
```

Replace ALL instances with:
```tsx
className="btn-cta-gradient rounded-md px-4 py-2"
```

### Viewport theme color (layout.tsx):

```tsx
// BEFORE:
export const viewport = { themeColor: '#3B82F6' };

// AFTER:
export const viewport = { themeColor: '#C9922A' };
```

### Calendar event colors (smart-events-client.tsx):

```tsx
// BEFORE:
backgroundColor: '#3b82f6'

// AFTER:
import { CHART_COLORS } from '@/lib/chart-colors';
backgroundColor: CHART_COLORS.gold
```

### Profile settings defaults:

```tsx
// BEFORE:
const [primaryColor, setPrimaryColor] = useState('#3B82F6');

// AFTER:
const [primaryColor, setPrimaryColor] = useState('hsl(var(--primary))');
```

---

## STEP 8 — Replace page clients

These are drop-in replacements for the main page client components:

| File from package | Replaces |
|---|---|
| `app/cosmos-dashboard.tsx` | `app/(dashboard)/home/_components/dashboard-client.tsx` |
| `app/members-page.tsx` | `app/(dashboard)/members/_components/members-client.tsx` |
| `app/prayer-wall-page.tsx` | `app/(dashboard)/prayer-wall/page.tsx` (client portion) |
| `app/visitor-followups-page.tsx` | `app/(dashboard)/visitor-follow-ups/_components/visitor-followups-client.tsx` |
| `app/checkins-page.tsx` | `app/(dashboard)/check-ins/_components/check-ins-client.tsx` |

---

## STEP 9 — Run and verify

```bash
npm run dev
```

Check each of these in the browser:
- [ ] `/home` — Constellation map visible, stats animate in, star field moves with mouse
- [ ] Sidebar — Gold active state, no blue colors anywhere
- [ ] Header — Gold focus ring, live agent chips visible
- [ ] `/members` — Table renders, lifecycle badges use color tokens
- [ ] `/prayer-wall` — Charts render dark, no light-mode bleed
- [ ] `/visitor-follow-ups` — Status/priority badges use token colors (not hardcoded)
- [ ] `/check-ins` — CTA button is gold gradient (not blue-purple)
- [ ] Dark mode — All elements adapt correctly

---

## Audit Issues Resolved

| ID | Issue | Fix |
|---|---|---|
| P1-A | Badge success/warning hardcoded | ✅ `--success` / `--warning` CSS tokens |
| P1-B | CTA buttons hardcoded blue gradient | ✅ `btn-cta-gradient` utility class |
| P1-C | STATUS_COLORS / PRIORITY_COLORS maps | ✅ Badge variant system |
| P1-D | Sidebar section btn blue hardcoded | ✅ `nav-section-btn` uses accent tokens |
| P2-A | --accent = --muted = --secondary | ✅ All three are now visually distinct |
| P2-B | No success/warning tokens | ✅ Added to globals.css |
| P2-C | --primary vs brand blue conflict | ✅ --primary = gold (brand) |
| P2-D | No chart color system | ✅ lib/chart-colors.ts |
| P3-A | No custom typeface | ✅ Cinzel + DM Sans via next/font |
| P3-B | No typography scale doc | ✅ Type scale in tailwind.config.ts |
| P4-A | Gradients don't adapt to dark | ✅ CSS var based |
| P4-B | Recharts dark mode broken | ✅ Global Recharts CSS + chart-colors |

---

## Pages still needing Cosmos treatment (Phase 2)

These pages follow the same pattern — use the delivered components as a template:

- `/volunteers` — use CoverageCosmosCard as foundation
- `/events` — calendar with CHART_COLORS
- `/donations` — metric cards with stat card component
- `/communications` — message composer
- `/analytics` — all Recharts with chart-colors.ts
- `/automation-rules` — rule builder
- `/social-media` — already has chart component, replace colors
- `/sermons` — library with constellation card styling
- `/settings` — cosmos-input forms
- `/auth/signin` — auth page with CosmosBackground

---

*Khesed-Tek Cosmos Design System v2.0*
*Built for the Latin American Church · khesed-tek-systems.org*
*"Sé diligente en conocer el estado de tus ovejas." — Proverbios 27:23*
