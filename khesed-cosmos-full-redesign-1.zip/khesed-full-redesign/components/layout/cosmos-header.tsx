"use client";
// components/layout/cosmos-header.tsx
// Full Cosmos redesign of header.tsx
// Replaces: components/layout/header.tsx

import { useState, useEffect } from "react";
import { useSession, signOut } from "next-auth/react";
import Link from "next/link";
import {
  Bell, Search, ChevronDown, LogOut, Settings,
  User, Shield, Moon, Sun, Zap,
} from "lucide-react";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface ActiveAgent {
  name: string;
  status: "running" | "alert" | "idle";
}

const LIVE_AGENTS: ActiveAgent[] = [
  { name: "Ag.12 Cobertura", status: "alert" },
  { name: "Ag.2 Triaje",     status: "running" },
  { name: "Ag.4 Oración",    status: "running" },
];

const AGENT_COLORS = {
  running: "hsl(var(--success))",
  alert:   "hsl(var(--warning))",
  idle:    "hsl(var(--muted-foreground))",
};

interface CosmosHeaderProps {
  className?: string;
}

export function CosmosHeader({ className }: CosmosHeaderProps) {
  const { data: session } = useSession();
  const [time, setTime] = useState("");
  const [notifications, setNotifications] = useState(5);
  const [showSearch, setShowSearch] = useState(false);
  const [coverageRate, setCoverageRate] = useState(94);

  useEffect(() => {
    const tick = () => {
      const now = new Date();
      setTime(now.toLocaleTimeString("es-CO", {
        weekday: "short", hour: "2-digit", minute: "2-digit",
      }));
    };
    tick();
    const id = setInterval(tick, 30000);
    return () => clearInterval(id);
  }, []);

  // Pulse coverage chip
  useEffect(() => {
    const id = setInterval(() => {
      setCoverageRate(prev => prev); // trigger re-render for animation
    }, 3000);
    return () => clearInterval(id);
  }, []);

  return (
    <header
      className={cn(
        "sticky top-0 z-nav h-14",
        "flex items-center justify-between",
        "px-4",
        "border-b border-[rgba(201,146,42,0.15)]",
        "bg-[rgba(5,8,15,0.8)] backdrop-blur-cosmos",
        className
      )}
    >
      {/* LEFT — Live system status */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-1.5">
          <div className="live-dot" />
          <span className="text-[10px] tracking-[0.1em] text-cosmos-emerald uppercase font-medium hidden sm:block">
            Sistema en vivo
          </span>
        </div>

        {/* Active agents mini display */}
        <div className="hidden md:flex items-center gap-1">
          {LIVE_AGENTS.map((ag) => (
            <div
              key={ag.name}
              className="flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] border border-[rgba(255,255,255,0.06)] bg-[rgba(255,255,255,0.03)]"
              title={ag.name}
            >
              <div
                className="w-1.5 h-1.5 rounded-full flex-shrink-0"
                style={{
                  background: AGENT_COLORS[ag.status],
                  animation: ag.status === "alert"
                    ? "goldPulse 1.2s ease-in-out infinite"
                    : ag.status === "running"
                    ? "livePulse 1.4s ease-in-out infinite"
                    : "none",
                }}
              />
              <span className="text-muted-foreground truncate max-w-[60px]">{ag.name}</span>
            </div>
          ))}
        </div>
      </div>

      {/* CENTER — Search */}
      <div className="flex-1 max-w-xs mx-4">
        {showSearch ? (
          <input
            autoFocus
            type="text"
            placeholder="Buscar miembros, eventos, oraciones..."
            className="cosmos-input text-xs py-1.5"
            onBlur={() => setShowSearch(false)}
          />
        ) : (
          <button
            onClick={() => setShowSearch(true)}
            className="w-full flex items-center gap-2 px-3 py-1.5 rounded-lg border border-[rgba(255,255,255,0.06)] bg-[rgba(255,255,255,0.02)] text-muted-foreground text-xs hover:border-[rgba(201,146,42,0.3)] transition-colors"
          >
            <Search size={11} />
            <span className="hidden sm:block">Buscar... ⌘K</span>
          </button>
        )}
      </div>

      {/* RIGHT — Status chips + user */}
      <div className="flex items-center gap-2">
        {/* Time */}
        <div className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 rounded-full border border-[rgba(201,146,42,0.2)] bg-[rgba(201,146,42,0.06)] text-[11px] text-gold">
          🗓 {time}
        </div>

        {/* Coverage chip */}
        <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full border border-[rgba(29,201,140,0.25)] bg-[rgba(29,201,140,0.08)] text-[11px] text-cosmos-emerald cursor-pointer hover:border-[rgba(29,201,140,0.5)] transition-colors">
          <div
            className="w-1.5 h-1.5 rounded-full bg-cosmos-emerald flex-shrink-0"
            style={{ animation: "livePulse 3s ease-in-out infinite" }}
          />
          ✅ Cobertura {coverageRate}%
        </div>

        {/* Notifications */}
        <Link
          href="/notifications"
          className="relative p-2 rounded-lg hover:bg-[hsl(var(--accent)/0.3)] transition-colors"
        >
          <Bell size={16} className="text-muted-foreground" />
          {notifications > 0 && (
            <span className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full bg-[hsl(var(--destructive))] text-[9px] font-bold text-white flex items-center justify-center">
              {notifications > 9 ? "9+" : notifications}
            </span>
          )}
        </Link>

        {/* Agents quick access */}
        <Link
          href="/home#agents"
          className="hidden sm:flex items-center gap-1.5 p-2 rounded-lg hover:bg-[hsl(var(--accent)/0.3)] transition-colors"
          title="12 Agentes IA"
        >
          <Zap size={15} className="text-gold" />
          <span className="text-[11px] text-gold font-medium">12 IA</span>
        </Link>

        {/* User menu */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="flex items-center gap-2 p-1 rounded-lg hover:bg-[hsl(var(--accent)/0.3)] transition-colors">
              <div className="w-7 h-7 rounded-full bg-gradient-to-br from-gold-dim to-gold flex items-center justify-center text-[11px] font-display font-bold text-navy-deep">
                {session?.user?.name?.charAt(0) || "N"}
              </div>
              <div className="hidden sm:block text-left">
                <div className="text-[11px] font-medium text-foreground leading-none">
                  {session?.user?.name?.split(" ")[0] || "Nelson"}
                </div>
                <div className="text-[9px] text-muted-foreground mt-0.5">
                  {session?.user?.role === "PASTOR" ? "Pastor" : "Admin"}
                </div>
              </div>
              <ChevronDown size={11} className="text-muted-foreground hidden sm:block" />
            </button>
          </DropdownMenuTrigger>

          <DropdownMenuContent
            align="end"
            className="w-48 border-[rgba(201,146,42,0.15)] bg-[rgba(13,22,40,0.95)] backdrop-blur-cosmos"
          >
            <div className="px-3 py-2 border-b border-[rgba(255,255,255,0.06)]">
              <p className="text-xs font-medium text-foreground">{session?.user?.name}</p>
              <p className="text-[10px] text-muted-foreground">{session?.user?.email}</p>
            </div>

            <DropdownMenuItem asChild>
              <Link href="/settings" className="flex items-center gap-2 text-xs cursor-pointer">
                <Settings size={13} /> Configuración
              </Link>
            </DropdownMenuItem>

            <DropdownMenuItem asChild>
              <Link href="/users" className="flex items-center gap-2 text-xs cursor-pointer">
                <User size={13} /> Perfil
              </Link>
            </DropdownMenuItem>

            <DropdownMenuItem asChild>
              <Link href="/permissions" className="flex items-center gap-2 text-xs cursor-pointer">
                <Shield size={13} /> Permisos
              </Link>
            </DropdownMenuItem>

            <DropdownMenuSeparator className="bg-[rgba(255,255,255,0.06)]" />

            <DropdownMenuItem
              onClick={() => signOut({ callbackUrl: "/auth/signin" })}
              className="flex items-center gap-2 text-xs text-destructive cursor-pointer focus:text-destructive focus:bg-destructive/10"
            >
              <LogOut size={13} /> Cerrar Sesión
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}
