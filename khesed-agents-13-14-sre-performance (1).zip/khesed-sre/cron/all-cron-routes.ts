// ================================================================
// CRON JOB ROUTES — Agents 13 & 14
// All cron routes go in: app/api/cron/
// Add schedules to vercel.json (see bottom of this file)
// ================================================================

// ── ROUTE 1: SRE Health Check ─────────────────────────────────
// FILE: app/api/cron/sre-health-check/route.ts
// Runs every 60 seconds — the heartbeat of the entire system.

import { NextRequest, NextResponse } from "next/server";
import { runSRECycle } from "@/lib/agents/sre-engineer";
import { db } from "@/lib/db";

export async function GET_SRE_HEALTH(req: NextRequest) {
  const authHeader = req.headers.get("authorization");
  if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const result = await runSRECycle();
    console.log("[CRON/SRE-HEALTH]", result);
    return NextResponse.json({ ok: true, ...result, timestamp: new Date().toISOString() });
  } catch (err) {
    console.error("[CRON/SRE-HEALTH] Failed:", err);
    return NextResponse.json({ ok: false, error: String(err) }, { status: 500 });
  }
}

// ── ROUTE 2: Performance Metrics Collection ───────────────────
// FILE: app/api/cron/performance-collect/route.ts
// Runs every 5 minutes.

import {
  collectPerformanceSnapshot,
  detectPerformanceAnomalies,
  generatePerformanceRecommendations,
} from "@/lib/agents/performance-engineer";
import { sendAlertCascade } from "@/lib/alerts/alert-cascade";

export async function GET_PERF_COLLECT(req: NextRequest) {
  const authHeader = req.headers.get("authorization");
  if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const snapshot = await collectPerformanceSnapshot(5);
    const anomalies = detectPerformanceAnomalies(snapshot);

    // If P1/P2 anomalies detected, create an incident
    const criticalAnomalies = anomalies.filter(
      (a) => a.severity === "P1_CRITICAL" || a.severity === "P2_HIGH"
    );

    for (const anomaly of criticalAnomalies) {
      const existing = await db.platform_incidents.findFirst({
        where: {
          title: { contains: anomaly.type },
          status: { in: ["DETECTED", "ACKNOWLEDGED", "INVESTIGATING"] },
        },
      });

      if (!existing) {
        const incident = await db.platform_incidents.create({
          data: {
            title: `Anomalía de Rendimiento: ${anomaly.type}`,
            description: anomaly.description,
            severity: anomaly.severity,
            status: "DETECTED",
            affectedServices: anomaly.route ? [anomaly.route] : ["api"],
            affectedTenants: 0,
            isAutoDetected: true,
          },
        });

        await sendAlertCascade({
          incidentId: incident.id,
          title: incident.title,
          severity: anomaly.severity,
          description: anomaly.description,
          affectedServices: incident.affectedServices as string[],
          detectedAt: incident.detectedAt,
        });
      }
    }

    // Generate AI recommendations hourly (only when :00 minute)
    const now = new Date();
    if (now.getMinutes() < 5) {
      await generatePerformanceRecommendations(snapshot, anomalies);
    }

    return NextResponse.json({
      ok: true,
      p50Ms: snapshot.p50Ms,
      p95Ms: snapshot.p95Ms,
      errorRate: snapshot.errorRate,
      anomalyCount: anomalies.length,
      timestamp: new Date().toISOString(),
    });
  } catch (err) {
    console.error("[CRON/PERF-COLLECT] Failed:", err);
    return NextResponse.json({ ok: false, error: String(err) }, { status: 500 });
  }
}

// ── ROUTE 3: Metric Rollup ────────────────────────────────────
// FILE: app/api/cron/metrics-rollup/route.ts
// Runs every hour — rolls up raw metrics into summaries.

export async function GET_METRICS_ROLLUP(req: NextRequest) {
  const authHeader = req.headers.get("authorization");
  if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000);
    const twoHoursAgo = new Date(Date.now() - 2 * 60 * 60 * 1000);

    const hourlyMetrics = await db.api_request_metrics.findMany({
      where: { requestedAt: { gte: twoHoursAgo, lt: oneHourAgo } },
      select: { route: true, durationMs: true, isError: true },
    });

    if (hourlyMetrics.length === 0) {
      return NextResponse.json({ ok: true, message: "No metrics to roll up" });
    }

    const durations = hourlyMetrics.map((m) => m.durationMs).sort((a, b) => a - b);
    const errorCount = hourlyMetrics.filter((m) => m.isError).length;

    const p = (arr: number[], pct: number) => {
      const idx = Math.ceil((pct / 100) * arr.length) - 1;
      return arr[Math.max(0, idx)];
    };

    await db.platform_metric_summaries.createMany({
      skipDuplicates: true,
      data: [
        { period: "hourly", periodStart: twoHoursAgo, periodEnd: oneHourAgo, metricType: "RESPONSE_TIME_P50", value: p(durations, 50), sampleCount: durations.length },
        { period: "hourly", periodStart: twoHoursAgo, periodEnd: oneHourAgo, metricType: "RESPONSE_TIME_P95", value: p(durations, 95), sampleCount: durations.length },
        { period: "hourly", periodStart: twoHoursAgo, periodEnd: oneHourAgo, metricType: "RESPONSE_TIME_P99", value: p(durations, 99), sampleCount: durations.length },
        { period: "hourly", periodStart: twoHoursAgo, periodEnd: oneHourAgo, metricType: "ERROR_RATE", value: (errorCount / hourlyMetrics.length) * 100, sampleCount: hourlyMetrics.length },
        { period: "hourly", periodStart: twoHoursAgo, periodEnd: oneHourAgo, metricType: "THROUGHPUT_RPS", value: hourlyMetrics.length / 3600, sampleCount: hourlyMetrics.length },
      ],
    });

    return NextResponse.json({ ok: true, samplesProcessed: hourlyMetrics.length });
  } catch (err) {
    return NextResponse.json({ ok: false, error: String(err) }, { status: 500 });
  }
}

// ── ROUTE 4: SLA Calculation ──────────────────────────────────
// FILE: app/api/cron/sla-calculation/route.ts
// Runs daily at midnight.

import { calculateMonthlySLA } from "@/lib/agents/sre-engineer";

export async function GET_SLA_CALC(req: NextRequest) {
  const authHeader = req.headers.get("authorization");
  if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const now = new Date();
  const month = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;

  try {
    await calculateMonthlySLA(month);
    return NextResponse.json({ ok: true, month, timestamp: new Date().toISOString() });
  } catch (err) {
    return NextResponse.json({ ok: false, error: String(err) }, { status: 500 });
  }
}

// ── ROUTE 5: Data Retention Cleanup ──────────────────────────
// FILE: app/api/cron/data-retention/route.ts
// Runs daily at 3am — purges old raw metrics per retention policy.

import { runDataRetentionCleanup } from "@/lib/agents/sre-engineer";

export async function GET_DATA_RETENTION(req: NextRequest) {
  const authHeader = req.headers.get("authorization");
  if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const result = await runDataRetentionCleanup();
    console.log("[CRON/DATA-RETENTION]", result);
    return NextResponse.json({ ok: true, ...result });
  } catch (err) {
    return NextResponse.json({ ok: false, error: String(err) }, { status: 500 });
  }
}

// ================================================================
// vercel.json CRON CONFIGURATION
// Add these to your existing crons array in vercel.json
// ================================================================

/*
{
  "crons": [
    // ... existing crons from Agents 1-12 ...

    // Agent 14: SRE — every 60 seconds (Vercel minimum is 1 minute)
    { "path": "/api/cron/sre-health-check", "schedule": "* * * * *" },

    // Agent 13: Performance — every 5 minutes
    { "path": "/api/cron/performance-collect", "schedule": "*/5 * * * *" },

    // Metric rollup — every hour
    { "path": "/api/cron/metrics-rollup", "schedule": "0 * * * *" },

    // SLA calculation — daily at midnight
    { "path": "/api/cron/sla-calculation", "schedule": "0 0 * * *" },

    // Data retention cleanup — daily at 3am
    { "path": "/api/cron/data-retention", "schedule": "0 3 * * *" }
  ]
}
*/
