# Khesed-Tek CMS — Agents 13 & 14
## Web Performance Engineer + SRE Engineer
## Complete Installation Guide

**SLA Target:** 99.9% uptime (≤ 8.76 hours downtime/year)
**Alert channels:** In-app → WhatsApp → Email → SMS (P1 only)
**Data retention:** 30 days raw · 90 days incidents · 1 year summaries
**Platform access:** SUPER_ADMIN only · `/platform/agents/performance` · `/platform/agents/sre`

---

## What's in this package

```
schema/
  monitoring-schema-additions.prisma   → Add to bottom of prisma/schema.prisma

middleware/
  monitoring.ts                        → API performance capture middleware

lib/
  monitoring/
    health-check-engine.ts             → Checks DB, Redis, all 11 integrations
  agents/
    performance-engineer.ts            → Agent 13 core service
    sre-engineer.ts                    → Agent 14 core service
  alerts/
    alert-cascade.ts                   → WhatsApp + Email + SMS + in-app alerts

api/
  monitoring-collect-route.ts          → app/api/monitoring/collect/route.ts
  all-agent-routes.ts                  → All /api/platform/agents/* routes
  health-route.ts                      → app/api/health/route.ts (public)

cron/
  all-cron-routes.ts                   → All 5 cron job routes

app/platform/agents/
  sre/sre-dashboard.tsx                → SRE Mission Control UI
  performance/performance-dashboard.tsx → Performance Engineer UI
```

---

## STEP 1 — Add Database Schema

Open `prisma/schema.prisma` and paste the entire contents of
`schema/monitoring-schema-additions.prisma` at the bottom.

Then run:
```bash
npx prisma migrate dev --name add_monitoring_infrastructure
```

Expected output:
```
✅ Generated migration: add_monitoring_infrastructure
✅ Prisma Client regenerated
```

Verify the 8 new tables exist:
```bash
npx prisma studio
# Check for: api_request_metrics, platform_health_checks, platform_incidents,
# incident_timeline_events, incident_alerts, platform_metric_summaries,
# performance_recommendations, platform_sla_records
```

---

## STEP 2 — Add the Monitoring Middleware

### Create the metric collector endpoint first:

Create `app/api/monitoring/collect/route.ts`:
```tsx
// Copy from: api/monitoring-collect-route.ts
```

### Add to your existing `middleware.ts`:

If you already have a `middleware.ts` at the project root:
```tsx
import { monitoringMiddleware } from './middleware/monitoring';

export function middleware(request: NextRequest) {
  // Your existing middleware logic...

  // Add monitoring (wraps your existing handler):
  return monitoringMiddleware(request, () => NextResponse.next());
}

export const config = {
  matcher: ['/api/:path*'],
};
```

If you don't have a `middleware.ts` yet, create one:
```tsx
import { NextRequest, NextResponse } from 'next/server';
import { monitoringMiddleware } from './middleware/monitoring';

export function middleware(request: NextRequest) {
  return monitoringMiddleware(request, () => NextResponse.next());
}

export const config = {
  matcher: ['/api/:path*'],
};
```

---

## STEP 3 — Add Agent Service Files

Copy the service files to your lib directory:
```bash
cp lib/monitoring/health-check-engine.ts  [project]/lib/monitoring/health-check-engine.ts
cp lib/agents/performance-engineer.ts     [project]/lib/agents/performance-engineer.ts
cp lib/agents/sre-engineer.ts             [project]/lib/agents/sre-engineer.ts
cp lib/alerts/alert-cascade.ts            [project]/lib/alerts/alert-cascade.ts
```

Create the directories if needed:
```bash
mkdir -p lib/monitoring lib/agents lib/alerts
```

---

## STEP 4 — Create All API Routes

For each route template in `api/all-agent-routes.ts`, create the file:

```bash
# SRE routes
mkdir -p app/api/platform/agents/sre/{health,incidents,sla,run-check}
mkdir -p "app/api/platform/agents/sre/incidents/[id]"/{acknowledge,resolve}

# Performance routes
mkdir -p app/api/platform/agents/performance/{metrics,snapshot,routes,recommendations,analyze}
mkdir -p "app/api/platform/agents/performance/recommendations/[id]"

# Monitoring
mkdir -p app/api/monitoring/collect

# Public health check
mkdir -p app/api/health
```

Each file exports a single `GET` or `POST` function — copy from the corresponding
function in `api/all-agent-routes.ts` and rename it to the standard `GET`/`POST`.

Example — `app/api/platform/agents/sre/health/route.ts`:
```tsx
import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.isSuperAdmin) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const checks = await db.$queryRaw`
    SELECT DISTINCT ON (service)
      id, service, status, "responseTimeMs", "errorMessage", metadata, "checkedAt"
    FROM platform_health_checks
    ORDER BY service, "checkedAt" DESC
  `;

  return NextResponse.json({ checks });
}
```

---

## STEP 5 — Add Dashboard Pages

Create the Super_Admin page routes:

```tsx
// app/(platform)/agents/sre/page.tsx
import { CosmosSREDashboard } from './sre-dashboard';
export default function SREPage() {
  return <CosmosSREDashboard />;
}

// app/(platform)/agents/performance/page.tsx
import { CosmosPerformanceDashboard } from './performance-dashboard';
export default function PerformancePage() {
  return <CosmosPerformanceDashboard />;
}
```

Copy the dashboard component files:
```bash
cp app/platform/agents/sre/sre-dashboard.tsx [project]/app/(platform)/agents/sre/sre-dashboard.tsx
cp app/platform/agents/performance/performance-dashboard.tsx [project]/app/(platform)/agents/performance/performance-dashboard.tsx
```

Add the routes to your platform sidebar navigation so SUPER_ADMIN can access them.

---

## STEP 6 — Create Cron Job Files

Create each cron route file from `cron/all-cron-routes.ts`:

```bash
mkdir -p app/api/cron/{sre-health-check,performance-collect,metrics-rollup,sla-calculation,data-retention}
```

For each route, create a `route.ts` with the appropriate `GET` function.

Example — `app/api/cron/sre-health-check/route.ts`:
```tsx
import { NextRequest, NextResponse } from "next/server";
import { runSRECycle } from "@/lib/agents/sre-engineer";

export async function GET(req: NextRequest) {
  const authHeader = req.headers.get("authorization");
  if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const result = await runSRECycle();
  return NextResponse.json({ ok: true, ...result });
}
```

Update `vercel.json` with the new crons:
```json
{
  "crons": [
    // ... existing crons from Agents 1-12 ...
    { "path": "/api/cron/sre-health-check",    "schedule": "* * * * *"    },
    { "path": "/api/cron/performance-collect", "schedule": "*/5 * * * *"  },
    { "path": "/api/cron/metrics-rollup",      "schedule": "0 * * * *"    },
    { "path": "/api/cron/sla-calculation",     "schedule": "0 0 * * *"    },
    { "path": "/api/cron/data-retention",      "schedule": "0 3 * * *"    }
  ]
}
```

---

## STEP 7 — Environment Variables

Add to `.env.local` AND to Vercel dashboard:

```bash
# ── MONITORING FOUNDATION ──────────────────────────────────────
# Internal key for middleware → collector communication (generate: openssl rand -hex 32)
MONITORING_INTERNAL_KEY=your-32-char-secret-here

# ── AGENT 14: SRE ALERT DESTINATIONS ──────────────────────────
# Your personal WhatsApp for P1/P2 alerts (with country code)
SRE_ADMIN_WHATSAPP=+573001234567

# Your email for P2/P3 alerts
SRE_ADMIN_EMAIL=nelson@khesed-tek-systems.org

# Your personal phone for P1 SMS alerts (Twilio)
SRE_ADMIN_PHONE=+573001234567

# ── AGENT 13 & 14: FEATURE FLAGS ───────────────────────────────
ENABLE_PERFORMANCE_ENGINEER=false   # Start disabled, enable after testing
ENABLE_SRE_ENGINEER=false           # Start disabled, enable after testing
```

In Vercel, also verify these are set (should already be from your existing integrations):
- `WHATSAPP_ACCESS_TOKEN` ✓
- `WHATSAPP_PHONE_NUMBER_ID` ✓
- `TWILIO_ACCOUNT_SID` ✓
- `TWILIO_AUTH_TOKEN` ✓
- `TWILIO_PHONE_NUMBER` ✓
- `MAILGUN_API_KEY` ✓
- `MAILGUN_DOMAIN` ✓
- `UPSTASH_REDIS_REST_URL` ✓
- `UPSTASH_REDIS_REST_TOKEN` ✓
- `ANTHROPIC_API_KEY` ✓ (from Agents 1-12)
- `CRON_SECRET` ✓ (from Agents 1-12)

---

## STEP 8 — Deploy and Test

```bash
git add .
git commit -m "feat: add Agents 13 & 14 — Web Performance Engineer + SRE Engineer"
git push origin main
```

Run production migration:
```bash
DATABASE_URL=your-production-url npx prisma migrate deploy
```

---

## STEP 9 — Enable and Verify

### Test the health check endpoint first:
```bash
curl https://your-app.vercel.app/api/health
# Expected: {"status":"ok","db":true,...}
```

### Manually trigger the SRE cycle:
```bash
curl -X POST https://your-app.vercel.app/api/platform/agents/sre/run-check \
  -H "Cookie: [your SUPER_ADMIN session cookie]"
```

Check Supabase → `platform_health_checks` table. You should see 8 new rows.

### Enable agents one at a time:

**Week 1:** Enable monitoring foundation only (no alerts yet)
```
MONITORING_INTERNAL_KEY=your-key  ← must be set for middleware to work
```
Wait 24 hours. Check that `api_request_metrics` is filling up.

**Week 2:** Enable SRE (read-only — no alerts)
```
ENABLE_SRE_ENGINEER=true
```
Go to `/platform/agents/sre` and verify health checks appear.

**Week 3:** Add alert destinations and enable alerts
```
SRE_ADMIN_WHATSAPP=+573001234567
SRE_ADMIN_EMAIL=your@email.com
SRE_ADMIN_PHONE=+573001234567
```
Manually trigger a test incident to verify alert delivery.

**Week 4:** Enable Performance Engineer
```
ENABLE_PERFORMANCE_ENGINEER=true
```
Go to `/platform/agents/performance` and verify metrics appear.

---

## STEP 10 — Add Platform Sidebar Links

Add to your platform navigation (in whatever component manages the `/platform/*` sidebar):

```tsx
{ href: "/platform/agents/sre",         label: "SRE — Uptime 24/7",        icon: <Shield /> },
{ href: "/platform/agents/performance", label: "Rendimiento Web",           icon: <Zap /> },
```

Both routes require `isSuperAdmin: true` on the session — they are already protected
by the `requireSuperAdmin()` guard in every API route.

---

## What You Now Have

| System | Coverage |
|---|---|
| **Monitoring foundation** | Every API request captured (response time, status, errors, cold starts) |
| **Health checks** | DB, Redis, Production URL, Stripe, WhatsApp, Mailgun, Twilio, AbacusAI |
| **Incident detection** | 8 automated rules covering P1 through P4 |
| **Alert cascade** | In-app → WhatsApp → Email → SMS (P1 only) |
| **SLA tracking** | 99.9% target, calculated monthly per plan tier |
| **Post-mortems** | Auto-generated by Claude API on incident resolution |
| **Performance metrics** | P50/P95/P99 latency, error rate, cache hit rate, cold starts |
| **AI recommendations** | Claude-generated fix suggestions with code snippets |
| **Data retention** | 30 days raw · 90 days incidents · 1 year summaries |

---

## Incident Response Playbook

### P1 — Full Outage
1. WhatsApp + Email + SMS fires within 60 seconds of detection
2. Go to `/platform/agents/sre/incidents/[id]`
3. Click "Reconocer" to start MTTA clock
4. Diagnose using the timeline + health check data
5. Fix the root cause
6. Click "Resolver" with resolution description
7. Post-mortem generated automatically

### P2 — Partial Outage
1. WhatsApp + Email fires within 60 seconds
2. Same flow as P1, minus the SMS

### P3/P4 — Degradation
1. In-app notification (P3 also emails)
2. Non-urgent — resolve within business hours

---

## Estimated Monthly Cost Impact

| Component | Cost |
|---|---|
| Anthropic API (performance recommendations) | ~$0.02/day |
| Anthropic API (post-mortems — rare) | ~$0.05/incident |
| Redis reads (health check caching) | Negligible |
| WhatsApp alert messages | ~$0.015/incident |
| Twilio SMS (P1 only — rare) | ~$0.05/incident |
| **Total estimate/month** | **< $1.00** |

The monitoring infrastructure itself costs less than one WhatsApp message per day.

---

*Khesed-Tek CMS · Agents 13 & 14 · v1.0.0*
*"Sé diligente en conocer el estado de tus ovejas." — Proverbios 27:23*
*Infrastructure Edition — Your platform never sleeps.*
