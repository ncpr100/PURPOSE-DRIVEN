// ================================================================
// AGENT API ROUTES — Agents 13 & 14
// All routes are SUPER_ADMIN protected.
// File shows all routes as TypeScript templates.
// Create each as a separate file at the path shown in the comment.
// ================================================================

import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";

// ── GUARD: SUPER_ADMIN only ───────────────────────────────────
async function requireSuperAdmin() {
  const session = await getServerSession(authOptions);
  if (!session?.user?.isSuperAdmin) {
    return { error: true, response: NextResponse.json({ error: "Forbidden" }, { status: 403 }) };
  }
  return { error: false, session };
}

// ================================================================
// SRE ROUTES
// ================================================================

// FILE: app/api/platform/agents/sre/health/route.ts
// GET latest health check results for all services
export async function GET_SRE_HEALTH(req: NextRequest) {
  const guard = await requireSuperAdmin();
  if (guard.error) return guard.response;

  // Get most recent check per service
  const checks = await db.$queryRaw<Array<any>>`
    SELECT DISTINCT ON (service)
      id, service, status, "responseTimeMs", "errorMessage", metadata, "checkedAt"
    FROM platform_health_checks
    ORDER BY service, "checkedAt" DESC
  `;

  return NextResponse.json({ checks });
}

// FILE: app/api/platform/agents/sre/incidents/route.ts
// GET incident list with pagination
export async function GET_SRE_INCIDENTS(req: NextRequest) {
  const guard = await requireSuperAdmin();
  if (guard.error) return guard.response;

  const url = new URL(req.url);
  const limit = parseInt(url.searchParams.get("limit") || "20");
  const status = url.searchParams.get("status"); // filter by status

  const where = status ? { status: status as any } : undefined;

  const incidents = await db.platform_incidents.findMany({
    where,
    orderBy: { detectedAt: "desc" },
    take: limit,
    include: {
      timeline: { orderBy: { createdAt: "asc" }, take: 5 },
    },
  });

  return NextResponse.json({ incidents });
}

// FILE: app/api/platform/agents/sre/incidents/[id]/route.ts
// GET single incident with full timeline
export async function GET_SRE_INCIDENT_DETAIL(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const guard = await requireSuperAdmin();
  if (guard.error) return guard.response;

  const incident = await db.platform_incidents.findUnique({
    where: { id: params.id },
    include: {
      timeline: { orderBy: { createdAt: "asc" } },
      alerts: { orderBy: { createdAt: "asc" } },
    },
  });

  if (!incident) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json({ incident });
}

// FILE: app/api/platform/agents/sre/incidents/[id]/acknowledge/route.ts
// POST acknowledge an incident
export async function POST_ACKNOWLEDGE_INCIDENT(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const guard = await requireSuperAdmin();
  if (guard.error) return guard.response;

  const now = new Date();
  const incident = await db.platform_incidents.findUnique({ where: { id: params.id }, select: { detectedAt: true } });
  if (!incident) return NextResponse.json({ error: "Not found" }, { status: 404 });

  await db.platform_incidents.update({
    where: { id: params.id },
    data: {
      status: "ACKNOWLEDGED",
      acknowledgedAt: now,
      acknowledgedBy: (guard as any).session.user.id,
      timeToAcknowledgeMs: now.getTime() - new Date(incident.detectedAt).getTime(),
    },
  });

  await db.incident_timeline_events.create({
    data: {
      incidentId: params.id,
      event: "ACKNOWLEDGED",
      description: "Incidente reconocido por el administrador de plataforma.",
      author: (guard as any).session.user.name || "SUPER_ADMIN",
    },
  });

  return NextResponse.json({ ok: true });
}

// FILE: app/api/platform/agents/sre/incidents/[id]/resolve/route.ts
// POST manually resolve an incident
export async function POST_RESOLVE_INCIDENT(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const guard = await requireSuperAdmin();
  if (guard.error) return guard.response;

  const body = await req.json();
  const { resolution, rootCause } = body;

  const incident = await db.platform_incidents.findUnique({ where: { id: params.id }, select: { detectedAt: true } });
  if (!incident) return NextResponse.json({ error: "Not found" }, { status: 404 });

  const now = new Date();

  await db.platform_incidents.update({
    where: { id: params.id },
    data: {
      status: "POST_MORTEM_PENDING",
      resolvedAt: now,
      resolvedBy: (guard as any).session.user.id,
      resolution,
      rootCause,
      timeToResolveMs: now.getTime() - new Date(incident.detectedAt).getTime(),
    },
  });

  await db.incident_timeline_events.create({
    data: {
      incidentId: params.id,
      event: "RESOLVED",
      description: `Incidente resuelto manualmente. Resolución: ${resolution}`,
      author: (guard as any).session.user.name || "SUPER_ADMIN",
    },
  });

  // Trigger post-mortem generation async
  const { generatePostMortem } = await import("@/lib/agents/sre-engineer");
  generatePostMortem(params.id, "", now.getTime() - new Date(incident.detectedAt).getTime())
    .catch(console.error);

  return NextResponse.json({ ok: true });
}

// FILE: app/api/platform/agents/sre/sla/route.ts
// GET SLA records
export async function GET_SLA_RECORDS(req: NextRequest) {
  const guard = await requireSuperAdmin();
  if (guard.error) return guard.response;

  const records = await db.platform_sla_records.findMany({
    orderBy: [{ month: "desc" }, { tier: "asc" }],
    take: 24,
  });

  return NextResponse.json({ records });
}

// FILE: app/api/platform/agents/sre/run-check/route.ts
// POST manually trigger a health check cycle
export async function POST_RUN_CHECK(req: NextRequest) {
  const guard = await requireSuperAdmin();
  if (guard.error) return guard.response;

  const { runSRECycle } = await import("@/lib/agents/sre-engineer");
  const result = await runSRECycle();
  return NextResponse.json({ ok: true, ...result });
}

// ================================================================
// PERFORMANCE ROUTES
// ================================================================

// FILE: app/api/platform/agents/performance/metrics/route.ts
// GET metric summaries (hourly/daily aggregates)
export async function GET_PERF_METRICS(req: NextRequest) {
  const guard = await requireSuperAdmin();
  if (guard.error) return guard.response;

  const url = new URL(req.url);
  const period = url.searchParams.get("period") || "hourly";
  const limit = parseInt(url.searchParams.get("limit") || "24");
  const route = url.searchParams.get("route");

  const summaries = await db.platform_metric_summaries.findMany({
    where: {
      period,
      route: route || null,
    },
    orderBy: { periodStart: "desc" },
    take: limit * 5, // Get all metric types for the period
  });

  // Pivot: group by periodStart, one row per period with all metrics
  const pivoted = new Map<string, Record<string, number>>();
  for (const s of summaries) {
    const key = s.periodStart.toISOString();
    if (!pivoted.has(key)) pivoted.set(key, { periodStart: s.periodStart.getTime() });
    const metricKey =
      s.metricType === "RESPONSE_TIME_P50" ? "p50Ms" :
      s.metricType === "RESPONSE_TIME_P95" ? "p95Ms" :
      s.metricType === "RESPONSE_TIME_P99" ? "p99Ms" :
      s.metricType === "ERROR_RATE" ? "errorRate" :
      s.metricType === "THROUGHPUT_RPS" ? "throughput" :
      s.metricType.toLowerCase();
    pivoted.get(key)![metricKey] = s.value;
  }

  const metrics = Array.from(pivoted.values())
    .sort((a, b) => a.periodStart - b.periodStart)
    .slice(-limit);

  return NextResponse.json({ metrics });
}

// FILE: app/api/platform/agents/performance/snapshot/route.ts
// GET current 5-minute performance snapshot
export async function GET_PERF_SNAPSHOT(req: NextRequest) {
  const guard = await requireSuperAdmin();
  if (guard.error) return guard.response;

  const { collectPerformanceSnapshot, detectPerformanceAnomalies } = await import("@/lib/agents/performance-engineer");
  const snapshot = await collectPerformanceSnapshot(5);
  const anomalies = detectPerformanceAnomalies(snapshot);

  return NextResponse.json({ snapshot, anomalies });
}

// FILE: app/api/platform/agents/performance/routes/route.ts
// GET slowest and most errored routes
export async function GET_PERF_ROUTES(req: NextRequest) {
  const guard = await requireSuperAdmin();
  if (guard.error) return guard.response;

  const { collectPerformanceSnapshot } = await import("@/lib/agents/performance-engineer");
  const snapshot = await collectPerformanceSnapshot(60); // last hour

  return NextResponse.json({
    slowest: snapshot.slowestRoutes,
    mostErrored: snapshot.mostErroredRoutes,
  });
}

// FILE: app/api/platform/agents/performance/recommendations/route.ts
// GET active recommendations
export async function GET_RECOMMENDATIONS(req: NextRequest) {
  const guard = await requireSuperAdmin();
  if (guard.error) return guard.response;

  const recommendations = await db.performance_recommendations.findMany({
    where: { isActioned: false, expiresAt: { gt: new Date() } },
    orderBy: [{ impact: "asc" }, { generatedAt: "desc" }],
    take: 20,
  });

  return NextResponse.json({ recommendations });
}

// FILE: app/api/platform/agents/performance/recommendations/[id]/route.ts
// PATCH mark a recommendation as actioned
export async function PATCH_RECOMMENDATION(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const guard = await requireSuperAdmin();
  if (guard.error) return guard.response;

  await db.performance_recommendations.update({
    where: { id: params.id },
    data: {
      isActioned: true,
      actionedBy: (guard as any).session.user.id,
      actionedAt: new Date(),
    },
  });

  return NextResponse.json({ ok: true });
}

// FILE: app/api/platform/agents/performance/analyze/route.ts
// POST trigger immediate performance analysis
export async function POST_ANALYZE(req: NextRequest) {
  const guard = await requireSuperAdmin();
  if (guard.error) return guard.response;

  const { collectPerformanceSnapshot, detectPerformanceAnomalies, generatePerformanceRecommendations } =
    await import("@/lib/agents/performance-engineer");

  const snapshot = await collectPerformanceSnapshot(60);
  const anomalies = detectPerformanceAnomalies(snapshot);
  await generatePerformanceRecommendations(snapshot, anomalies);

  return NextResponse.json({ ok: true, anomalyCount: anomalies.length });
}

// FILE: app/api/health/route.ts
// Public health endpoint — used by SRE agent's production URL check
// This route should be publicly accessible (no auth)
export async function GET_HEALTH_PUBLIC(req: NextRequest) {
  let dbOk = false;
  try {
    await db.$queryRaw`SELECT 1`;
    dbOk = true;
  } catch {}

  const status = dbOk ? 200 : 503;
  return NextResponse.json(
    {
      status: dbOk ? "ok" : "degraded",
      version: process.env.npm_package_version || "1.1.0",
      timestamp: new Date().toISOString(),
      db: dbOk,
    },
    { status }
  );
}
