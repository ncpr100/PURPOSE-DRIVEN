
# AbacusAI Support Request: Development Environment Variable Override

## TICKET INFORMATION
**Date:** September 8, 2025
**Priority:** Medium - Development Blocker
**Category:** Platform Configuration / Development Environment
**Project:** Kḥesed-tek Church Management System
**Platform:** AbacusAI ChatLLM Teams / DeepAgent

---

## PROBLEM SUMMARY

**Issue:** Local development testing is completely blocked due to platform-level environment variable injection that overrides local development settings.

**Specific Behavior:** 
- AbacusAI platform automatically injects `NEXTAUTH_URL=https://khesed-tek.abacusai.app` at the process level
- This injection completely ignores and overrides local `.env` file configurations
- Results in authentication-dependent features failing during local development
- Forces all API requests to production endpoints instead of local development server

---

## BUSINESS IMPACT

### Development Workflow Disruption
- **Unable to test locally:** Authentication features cannot be tested in development environment
- **Production dependency:** Every change requires production deployment for testing
- **Increased cycle time:** Development feedback loop extended from minutes to hours
- **Risk increase:** Higher probability of production bugs due to limited local testing

### Resource Impact  
- **Developer productivity:** Significant reduction in development efficiency
- **Infrastructure costs:** Increased production deployments for testing
- **Quality assurance:** Reduced confidence in code changes before production

---

## TECHNICAL EVIDENCE

### Platform Process Injection Detection
During comprehensive diagnostic analysis, we identified the exact source of the override:

```bash
# Command: ps aux | grep -E "(next|node)" 
# Result showing platform injection:
NEXTAUTH_URL=https://khesed-tek.abacusai.app
```

### Local Configuration Being Ignored
```bash
# File: /home/ubuntu/khesed_tek_church_systems/app/.env
NEXTAUTH_URL="http://localhost:3000"
```

### API Endpoint Behavior
- **Expected:** `PUT http://localhost:3000/api/support-contact` → Works (confirmed via curl)
- **Actual Browser:** `PUT https://khesed-tek.abacusai.app/api/support-contact` → 405 Method Not Allowed

---

## DIAGNOSTIC METHODOLOGY

### High-Reliability Mode (HRM) Protocol Execution
We conducted a systematic 22-step diagnostic protocol to eliminate all possible causes:

**Confirmed Working Components:**
- ✅ Local API endpoints respond correctly (HRM-1, HRM-10)  
- ✅ Database persistence functions properly
- ✅ Frontend code makes correct API calls (HRM-6)
- ✅ Authentication logic is sound
- ✅ Next.js configuration is clean (HRM-21)
- ✅ No service worker interference (HRM-20)
- ✅ No hard-coded URL overrides (HRM-16)

**Definitive Root Cause:**
- ❌ Platform environment variable injection overrides local settings (HRM-22)

---

## REQUESTED SOLUTION

### Primary Request: Development Mode Toggle
**Feature:** Ability to disable production environment variable injection during local development

**Implementation Options:**
1. **Environment Flag:** `ABACUS_DEV_MODE=true` to prioritize local .env files
2. **CLI Parameter:** Command-line flag to enable local development mode
3. **Dashboard Toggle:** UI setting in AbacusAI dashboard to enable/disable production overrides

### Secondary Request: Override Priority Configuration
**Feature:** Configurable precedence for environment variable sources

**Priority Order (Requested):**
1. Local `.env` files (highest priority in dev mode)
2. Platform injected variables
3. System defaults

### Tertiary Request: Environment Detection
**Feature:** Automatic detection of local vs production deployment context

**Behavior:**
- Detect localhost/development environment automatically
- Disable production overrides for local development
- Maintain current behavior for production deployments

---

## REPRODUCTION STEPS

### Current Problematic Behavior
1. Create Next.js application with authentication features
2. Set `NEXTAUTH_URL="http://localhost:3000"` in `.env` file
3. Start development server with `yarn dev`
4. Make authenticated API request from browser
5. **Observe:** Request goes to production URL instead of localhost

### Expected Behavior
1. Local `.env` settings should take precedence in development environment
2. Browser requests should target `http://localhost:3000`
3. Local development and testing should function independently of production

---

## PROPOSED WORKAROUNDS (INTERIM)

While awaiting platform enhancement:

### Option A: Conditional Environment Logic
```javascript
const baseUrl = process.env.NODE_ENV === 'development' 
  ? 'http://localhost:3000' 
  : process.env.NEXTAUTH_URL;
```

### Option B: Development Proxy
- Configure local proxy to intercept production URLs
- Redirect to localhost during development

### Option C: Mock Authentication Mode
- Implement development-only authentication bypass
- Enable local testing without production dependencies

---

## SIMILAR PLATFORM COMPARISONS

### Industry Standards
- **Vercel:** Respects local .env in development mode
- **Netlify:** Provides environment-specific variable precedence
- **Railway:** Offers development/production environment separation
- **Heroku:** Local development independent of production config

---

## TECHNICAL SPECIFICATIONS

### Current Environment
- **Platform:** AbacusAI ChatLLM Teams
- **Framework:** Next.js 14.2.28
- **Authentication:** NextAuth.js with JWT strategy
- **Database:** PostgreSQL with Prisma ORM
- **Deployment:** AbacusAI hosted environment

### Requirements
- **Backward Compatibility:** Maintain current production behavior
- **Security:** No compromise to production environment isolation
- **Simplicity:** Minimal configuration required from developers

---

## URGENCY JUSTIFICATION

### Development Impact
- **Current Status:** Development workflow severely impacted
- **Timeline:** Every development cycle requires production deployment
- **Scaling:** Issue affects all authentication-dependent features

### Business Continuity
- **Short-term:** Workarounds possible but inefficient
- **Long-term:** Platform limitation affects developer experience and adoption
- **Competitive:** Standard feature expected in modern development platforms

---

## CONTACT INFORMATION

**Project:** Kḥesed-tek Church Management System  
**Developer:** [Your contact information]  
**Conversation Thread:** [Reference this conversation if available]  
**Diagnostic Reference:** HRM-22 Protocol Completion - Platform Environment Variable Injection Confirmed

---

## ATTACHMENTS

1. HRM Diagnostic Protocol Results
2. Browser Console Screenshots (showing production URL requests)
3. Process Command Line Evidence
4. Local Configuration Files

---

## EXPECTED RESPONSE

### Immediate (24-48 hours)
- Acknowledgment of ticket
- Initial assessment of feasibility
- Timeline estimate for implementation

### Resolution (3-5 business days)
- Platform configuration update, OR
- Alternative solution proposal, OR
- Technical workaround guidance

---

**Thank you for your attention to this development environment enhancement request. This feature would significantly improve the developer experience on the AbacusAI platform.**
