--
-- PostgreSQL database dump
--

\restrict eCvEe4fwoi3QBaFrY1XnJWVjEa7W3D4S1SSgNwJdyIHkPmrdkmmo8giU22BfHxb

-- Dumped from database version 17.4 (Ubuntu 17.4-1.pgdg24.04+2)
-- Dumped by pg_dump version 17.6 (Ubuntu 17.6-1.pgdg22.04+1)

-- Started on 2025-09-13 15:19:41 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.websites DROP CONSTRAINT IF EXISTS "websites_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.website_requests DROP CONSTRAINT IF EXISTS "website_requests_resultingWebsiteId_fkey";
ALTER TABLE IF EXISTS ONLY public.website_requests DROP CONSTRAINT IF EXISTS "website_requests_existingWebsiteId_fkey";
ALTER TABLE IF EXISTS ONLY public.website_requests DROP CONSTRAINT IF EXISTS "website_requests_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.website_requests DROP CONSTRAINT IF EXISTS "website_requests_assignedTo_fkey";
ALTER TABLE IF EXISTS ONLY public.website_analytics DROP CONSTRAINT IF EXISTS "website_analytics_websiteId_fkey";
ALTER TABLE IF EXISTS ONLY public.web_pages DROP CONSTRAINT IF EXISTS "web_pages_websiteId_fkey";
ALTER TABLE IF EXISTS ONLY public.web_page_sections DROP CONSTRAINT IF EXISTS "web_page_sections_pageId_fkey";
ALTER TABLE IF EXISTS ONLY public.volunteers DROP CONSTRAINT IF EXISTS "volunteers_ministryId_fkey";
ALTER TABLE IF EXISTS ONLY public.volunteers DROP CONSTRAINT IF EXISTS "volunteers_memberId_fkey";
ALTER TABLE IF EXISTS ONLY public.volunteers DROP CONSTRAINT IF EXISTS "volunteers_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.volunteer_recommendations DROP CONSTRAINT IF EXISTS "volunteer_recommendations_ministryId_fkey";
ALTER TABLE IF EXISTS ONLY public.volunteer_recommendations DROP CONSTRAINT IF EXISTS "volunteer_recommendations_memberId_fkey";
ALTER TABLE IF EXISTS ONLY public.volunteer_recommendations DROP CONSTRAINT IF EXISTS "volunteer_recommendations_eventId_fkey";
ALTER TABLE IF EXISTS ONLY public.volunteer_engagement_scores DROP CONSTRAINT IF EXISTS "volunteer_engagement_scores_volunteerId_fkey";
ALTER TABLE IF EXISTS ONLY public.volunteer_assignments DROP CONSTRAINT IF EXISTS "volunteer_assignments_volunteerId_fkey";
ALTER TABLE IF EXISTS ONLY public.volunteer_assignments DROP CONSTRAINT IF EXISTS "volunteer_assignments_eventId_fkey";
ALTER TABLE IF EXISTS ONLY public.visitor_follow_ups DROP CONSTRAINT IF EXISTS "visitor_follow_ups_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.visitor_follow_ups DROP CONSTRAINT IF EXISTS "visitor_follow_ups_checkInId_fkey";
ALTER TABLE IF EXISTS ONLY public.visitor_follow_ups DROP CONSTRAINT IF EXISTS "visitor_follow_ups_assignedTo_fkey";
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS "users_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.user_theme_preferences DROP CONSTRAINT IF EXISTS "user_theme_preferences_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.user_theme_preferences DROP CONSTRAINT IF EXISTS "user_theme_preferences_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.user_roles_advanced DROP CONSTRAINT IF EXISTS "user_roles_advanced_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.user_roles_advanced DROP CONSTRAINT IF EXISTS "user_roles_advanced_roleId_fkey";
ALTER TABLE IF EXISTS ONLY public.user_permissions DROP CONSTRAINT IF EXISTS "user_permissions_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.user_permissions DROP CONSTRAINT IF EXISTS "user_permissions_permissionId_fkey";
ALTER TABLE IF EXISTS ONLY public.testimony_qr_codes DROP CONSTRAINT IF EXISTS "testimony_qr_codes_formId_fkey";
ALTER TABLE IF EXISTS ONLY public.testimony_qr_codes DROP CONSTRAINT IF EXISTS "testimony_qr_codes_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.testimony_forms DROP CONSTRAINT IF EXISTS "testimony_forms_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.tenant_credentials DROP CONSTRAINT IF EXISTS "tenant_credentials_createdBy_fkey";
ALTER TABLE IF EXISTS ONLY public.tenant_credentials DROP CONSTRAINT IF EXISTS "tenant_credentials_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.social_media_posts DROP CONSTRAINT IF EXISTS "social_media_posts_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.social_media_posts DROP CONSTRAINT IF EXISTS "social_media_posts_campaignId_fkey";
ALTER TABLE IF EXISTS ONLY public.social_media_metrics DROP CONSTRAINT IF EXISTS "social_media_metrics_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.social_media_metrics DROP CONSTRAINT IF EXISTS "social_media_metrics_accountId_fkey";
ALTER TABLE IF EXISTS ONLY public.social_media_accounts DROP CONSTRAINT IF EXISTS "social_media_accounts_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.sessions DROP CONSTRAINT IF EXISTS "sessions_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.sermons DROP CONSTRAINT IF EXISTS "sermons_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.roles DROP CONSTRAINT IF EXISTS "roles_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.role_permissions DROP CONSTRAINT IF EXISTS "role_permissions_roleId_fkey";
ALTER TABLE IF EXISTS ONLY public.role_permissions DROP CONSTRAINT IF EXISTS "role_permissions_permissionId_fkey";
ALTER TABLE IF EXISTS ONLY public.report_schedules DROP CONSTRAINT IF EXISTS "report_schedules_reportId_fkey";
ALTER TABLE IF EXISTS ONLY public.report_schedules DROP CONSTRAINT IF EXISTS "report_schedules_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.report_executions DROP CONSTRAINT IF EXISTS "report_executions_reportId_fkey";
ALTER TABLE IF EXISTS ONLY public.report_executions DROP CONSTRAINT IF EXISTS "report_executions_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.push_subscriptions DROP CONSTRAINT IF EXISTS "push_subscriptions_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.push_subscriptions DROP CONSTRAINT IF EXISTS "push_subscriptions_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.push_notification_logs DROP CONSTRAINT IF EXISTS "push_notification_logs_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.push_notification_logs DROP CONSTRAINT IF EXISTS "push_notification_logs_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.prayer_testimonies DROP CONSTRAINT IF EXISTS "prayer_testimonies_prayerRequestId_fkey";
ALTER TABLE IF EXISTS ONLY public.prayer_testimonies DROP CONSTRAINT IF EXISTS "prayer_testimonies_contactId_fkey";
ALTER TABLE IF EXISTS ONLY public.prayer_testimonies DROP CONSTRAINT IF EXISTS "prayer_testimonies_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.prayer_testimonies DROP CONSTRAINT IF EXISTS "prayer_testimonies_approvedBy_fkey";
ALTER TABLE IF EXISTS ONLY public.prayer_response_templates DROP CONSTRAINT IF EXISTS "prayer_response_templates_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.prayer_response_templates DROP CONSTRAINT IF EXISTS "prayer_response_templates_categoryId_fkey";
ALTER TABLE IF EXISTS ONLY public.prayer_requests DROP CONSTRAINT IF EXISTS "prayer_requests_contactId_fkey";
ALTER TABLE IF EXISTS ONLY public.prayer_requests DROP CONSTRAINT IF EXISTS "prayer_requests_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.prayer_requests DROP CONSTRAINT IF EXISTS "prayer_requests_categoryId_fkey";
ALTER TABLE IF EXISTS ONLY public.prayer_qr_codes DROP CONSTRAINT IF EXISTS "prayer_qr_codes_formId_fkey";
ALTER TABLE IF EXISTS ONLY public.prayer_qr_codes DROP CONSTRAINT IF EXISTS "prayer_qr_codes_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.prayer_forms DROP CONSTRAINT IF EXISTS "prayer_forms_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.prayer_contacts DROP CONSTRAINT IF EXISTS "prayer_contacts_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.prayer_categories DROP CONSTRAINT IF EXISTS "prayer_categories_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.prayer_approvals DROP CONSTRAINT IF EXISTS "prayer_approvals_requestId_fkey";
ALTER TABLE IF EXISTS ONLY public.prayer_approvals DROP CONSTRAINT IF EXISTS "prayer_approvals_contactId_fkey";
ALTER TABLE IF EXISTS ONLY public.prayer_approvals DROP CONSTRAINT IF EXISTS "prayer_approvals_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.prayer_approvals DROP CONSTRAINT IF EXISTS "prayer_approvals_approvedBy_fkey";
ALTER TABLE IF EXISTS ONLY public.payment_methods DROP CONSTRAINT IF EXISTS "payment_methods_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.payment_gateway_configs DROP CONSTRAINT IF EXISTS "payment_gateway_configs_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.online_payments DROP CONSTRAINT IF EXISTS "online_payments_donationId_fkey";
ALTER TABLE IF EXISTS ONLY public.online_payments DROP CONSTRAINT IF EXISTS "online_payments_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.online_payments DROP CONSTRAINT IF EXISTS "online_payments_categoryId_fkey";
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS "notifications_createdBy_fkey";
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS "notifications_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.notification_templates DROP CONSTRAINT IF EXISTS "notification_templates_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.notification_preferences DROP CONSTRAINT IF EXISTS "notification_preferences_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.ministry_gap_analyses DROP CONSTRAINT IF EXISTS "ministry_gap_analyses_ministryId_fkey";
ALTER TABLE IF EXISTS ONLY public.ministry_gap_analyses DROP CONSTRAINT IF EXISTS "ministry_gap_analyses_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.ministries DROP CONSTRAINT IF EXISTS "ministries_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.members DROP CONSTRAINT IF EXISTS "members_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.members DROP CONSTRAINT IF EXISTS "members_ministryId_fkey";
ALTER TABLE IF EXISTS ONLY public.members DROP CONSTRAINT IF EXISTS "members_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.member_spiritual_profiles DROP CONSTRAINT IF EXISTS "member_spiritual_profiles_memberId_fkey";
ALTER TABLE IF EXISTS ONLY public.marketing_campaigns DROP CONSTRAINT IF EXISTS "marketing_campaigns_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.marketing_campaign_posts DROP CONSTRAINT IF EXISTS "marketing_campaign_posts_postId_fkey";
ALTER TABLE IF EXISTS ONLY public.marketing_campaign_posts DROP CONSTRAINT IF EXISTS "marketing_campaign_posts_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.marketing_campaign_posts DROP CONSTRAINT IF EXISTS "marketing_campaign_posts_campaignId_fkey";
ALTER TABLE IF EXISTS ONLY public.marketing_campaign_posts DROP CONSTRAINT IF EXISTS "marketing_campaign_posts_accountId_fkey";
ALTER TABLE IF EXISTS ONLY public.kpi_metrics DROP CONSTRAINT IF EXISTS "kpi_metrics_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.invoices DROP CONSTRAINT IF EXISTS "invoices_subscriptionId_fkey";
ALTER TABLE IF EXISTS ONLY public.invoices DROP CONSTRAINT IF EXISTS "invoices_createdBy_fkey";
ALTER TABLE IF EXISTS ONLY public.invoices DROP CONSTRAINT IF EXISTS "invoices_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.invoice_payments DROP CONSTRAINT IF EXISTS "invoice_payments_verifiedBy_fkey";
ALTER TABLE IF EXISTS ONLY public.invoice_payments DROP CONSTRAINT IF EXISTS "invoice_payments_invoiceId_fkey";
ALTER TABLE IF EXISTS ONLY public.invoice_line_items DROP CONSTRAINT IF EXISTS "invoice_line_items_invoiceId_fkey";
ALTER TABLE IF EXISTS ONLY public.invoice_communications DROP CONSTRAINT IF EXISTS "invoice_communications_sentBy_fkey";
ALTER TABLE IF EXISTS ONLY public.invoice_communications DROP CONSTRAINT IF EXISTS "invoice_communications_invoiceId_fkey";
ALTER TABLE IF EXISTS ONLY public.integration_configs DROP CONSTRAINT IF EXISTS "integration_configs_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.funnels DROP CONSTRAINT IF EXISTS "funnels_websiteId_fkey";
ALTER TABLE IF EXISTS ONLY public.funnel_steps DROP CONSTRAINT IF EXISTS "funnel_steps_funnelId_fkey";
ALTER TABLE IF EXISTS ONLY public.funnel_conversions DROP CONSTRAINT IF EXISTS "funnel_conversions_stepId_fkey";
ALTER TABLE IF EXISTS ONLY public.funnel_conversions DROP CONSTRAINT IF EXISTS "funnel_conversions_funnelId_fkey";
ALTER TABLE IF EXISTS ONLY public.events DROP CONSTRAINT IF EXISTS "events_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.event_resources DROP CONSTRAINT IF EXISTS "event_resources_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.event_resource_reservations DROP CONSTRAINT IF EXISTS "event_resource_reservations_resourceId_fkey";
ALTER TABLE IF EXISTS ONLY public.event_resource_reservations DROP CONSTRAINT IF EXISTS "event_resource_reservations_eventId_fkey";
ALTER TABLE IF EXISTS ONLY public.event_resource_reservations DROP CONSTRAINT IF EXISTS "event_resource_reservations_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.donations DROP CONSTRAINT IF EXISTS "donations_paymentMethodId_fkey";
ALTER TABLE IF EXISTS ONLY public.donations DROP CONSTRAINT IF EXISTS "donations_memberId_fkey";
ALTER TABLE IF EXISTS ONLY public.donations DROP CONSTRAINT IF EXISTS "donations_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.donations DROP CONSTRAINT IF EXISTS "donations_categoryId_fkey";
ALTER TABLE IF EXISTS ONLY public.donations DROP CONSTRAINT IF EXISTS "donations_campaignId_fkey";
ALTER TABLE IF EXISTS ONLY public.donation_categories DROP CONSTRAINT IF EXISTS "donation_categories_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.donation_campaigns DROP CONSTRAINT IF EXISTS "donation_campaigns_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.donation_campaigns DROP CONSTRAINT IF EXISTS "donation_campaigns_categoryId_fkey";
ALTER TABLE IF EXISTS ONLY public.dashboard_widgets DROP CONSTRAINT IF EXISTS "dashboard_widgets_dashboardId_fkey";
ALTER TABLE IF EXISTS ONLY public.dashboard_widgets DROP CONSTRAINT IF EXISTS "dashboard_widgets_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.custom_reports DROP CONSTRAINT IF EXISTS "custom_reports_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.communications DROP CONSTRAINT IF EXISTS "communications_templateId_fkey";
ALTER TABLE IF EXISTS ONLY public.communications DROP CONSTRAINT IF EXISTS "communications_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.communication_templates DROP CONSTRAINT IF EXISTS "communication_templates_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.church_themes DROP CONSTRAINT IF EXISTS "church_themes_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.church_subscriptions DROP CONSTRAINT IF EXISTS "church_subscriptions_planId_fkey";
ALTER TABLE IF EXISTS ONLY public.church_subscriptions DROP CONSTRAINT IF EXISTS "church_subscriptions_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.church_subscription_addons DROP CONSTRAINT IF EXISTS "church_subscription_addons_subscriptionId_fkey";
ALTER TABLE IF EXISTS ONLY public.church_subscription_addons DROP CONSTRAINT IF EXISTS "church_subscription_addons_addonId_fkey";
ALTER TABLE IF EXISTS ONLY public.church_qualification_settings DROP CONSTRAINT IF EXISTS "church_qualification_settings_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.children_check_ins DROP CONSTRAINT IF EXISTS "children_check_ins_eventId_fkey";
ALTER TABLE IF EXISTS ONLY public.children_check_ins DROP CONSTRAINT IF EXISTS "children_check_ins_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.check_ins DROP CONSTRAINT IF EXISTS "check_ins_eventId_fkey";
ALTER TABLE IF EXISTS ONLY public.check_ins DROP CONSTRAINT IF EXISTS "check_ins_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.availability_matrices DROP CONSTRAINT IF EXISTS "availability_matrices_memberId_fkey";
ALTER TABLE IF EXISTS ONLY public.automations DROP CONSTRAINT IF EXISTS "automations_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.automation_triggers DROP CONSTRAINT IF EXISTS "automation_triggers_ruleId_fkey";
ALTER TABLE IF EXISTS ONLY public.automation_templates DROP CONSTRAINT IF EXISTS "automation_templates_createdBy_fkey";
ALTER TABLE IF EXISTS ONLY public.automation_rules DROP CONSTRAINT IF EXISTS "automation_rules_createdBy_fkey";
ALTER TABLE IF EXISTS ONLY public.automation_rules DROP CONSTRAINT IF EXISTS "automation_rules_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.automation_rule_executions DROP CONSTRAINT IF EXISTS "automation_rule_executions_ruleId_fkey";
ALTER TABLE IF EXISTS ONLY public.automation_executions DROP CONSTRAINT IF EXISTS "automation_executions_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.automation_executions DROP CONSTRAINT IF EXISTS "automation_executions_automationId_fkey";
ALTER TABLE IF EXISTS ONLY public.automation_conditions DROP CONSTRAINT IF EXISTS "automation_conditions_ruleId_fkey";
ALTER TABLE IF EXISTS ONLY public.automation_actions DROP CONSTRAINT IF EXISTS "automation_actions_ruleId_fkey";
ALTER TABLE IF EXISTS ONLY public.analytics_dashboards DROP CONSTRAINT IF EXISTS "analytics_dashboards_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.analytics_cache DROP CONSTRAINT IF EXISTS "analytics_cache_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.accounts DROP CONSTRAINT IF EXISTS "accounts_userId_fkey";
DROP INDEX IF EXISTS public.websites_slug_key;
DROP INDEX IF EXISTS public."web_pages_websiteId_slug_key";
DROP INDEX IF EXISTS public."volunteer_engagement_scores_volunteerId_key";
DROP INDEX IF EXISTS public.verification_tokens_token_key;
DROP INDEX IF EXISTS public.verification_tokens_identifier_token_key;
DROP INDEX IF EXISTS public.users_email_key;
DROP INDEX IF EXISTS public."user_theme_preferences_userId_key";
DROP INDEX IF EXISTS public."user_roles_advanced_userId_roleId_key";
DROP INDEX IF EXISTS public."user_permissions_userId_permissionId_key";
DROP INDEX IF EXISTS public.testimony_qr_codes_code_key;
DROP INDEX IF EXISTS public.testimony_forms_slug_key;
DROP INDEX IF EXISTS public."tenant_credentials_churchId_key";
DROP INDEX IF EXISTS public.subscription_plans_name_key;
DROP INDEX IF EXISTS public.subscription_addons_key_key;
DROP INDEX IF EXISTS public.spiritual_gifts_name_key;
DROP INDEX IF EXISTS public."social_media_metrics_accountId_postId_metricType_date_perio_key";
DROP INDEX IF EXISTS public."social_media_accounts_platform_accountId_churchId_key";
DROP INDEX IF EXISTS public."sessions_sessionToken_key";
DROP INDEX IF EXISTS public."roles_name_churchId_key";
DROP INDEX IF EXISTS public."role_permissions_roleId_permissionId_key";
DROP INDEX IF EXISTS public."push_subscriptions_userId_idx";
DROP INDEX IF EXISTS public."push_subscriptions_userId_endpoint_key";
DROP INDEX IF EXISTS public."push_subscriptions_isActive_idx";
DROP INDEX IF EXISTS public."push_subscriptions_churchId_idx";
DROP INDEX IF EXISTS public."push_notification_logs_userId_idx";
DROP INDEX IF EXISTS public.push_notification_logs_status_idx;
DROP INDEX IF EXISTS public."push_notification_logs_createdAt_idx";
DROP INDEX IF EXISTS public."push_notification_logs_churchId_idx";
DROP INDEX IF EXISTS public.prayer_qr_codes_code_key;
DROP INDEX IF EXISTS public.prayer_forms_slug_key;
DROP INDEX IF EXISTS public."prayer_contacts_churchId_phone_key";
DROP INDEX IF EXISTS public."prayer_contacts_churchId_email_key";
DROP INDEX IF EXISTS public."prayer_categories_churchId_name_key";
DROP INDEX IF EXISTS public."prayer_approvals_requestId_key";
DROP INDEX IF EXISTS public.plan_features_key_key;
DROP INDEX IF EXISTS public.permissions_resource_action_key;
DROP INDEX IF EXISTS public.permissions_name_key;
DROP INDEX IF EXISTS public."payment_gateway_configs_churchId_gatewayType_key";
DROP INDEX IF EXISTS public.online_payments_status_idx;
DROP INDEX IF EXISTS public."online_payments_paymentId_key";
DROP INDEX IF EXISTS public."online_payments_paymentId_idx";
DROP INDEX IF EXISTS public."online_payments_donationId_key";
DROP INDEX IF EXISTS public."online_payments_churchId_idx";
DROP INDEX IF EXISTS public."notification_templates_name_churchId_key";
DROP INDEX IF EXISTS public."notification_preferences_userId_key";
DROP INDEX IF EXISTS public."members_userId_key";
DROP INDEX IF EXISTS public."member_spiritual_profiles_memberId_key";
DROP INDEX IF EXISTS public."marketing_campaign_posts_campaignId_postId_accountId_key";
DROP INDEX IF EXISTS public.invoices_status_idx;
DROP INDEX IF EXISTS public."invoices_invoiceNumber_key";
DROP INDEX IF EXISTS public."invoices_invoiceNumber_idx";
DROP INDEX IF EXISTS public."invoices_dueDate_idx";
DROP INDEX IF EXISTS public."invoices_churchId_idx";
DROP INDEX IF EXISTS public."invoice_payments_invoiceId_idx";
DROP INDEX IF EXISTS public.invoice_communications_type_idx;
DROP INDEX IF EXISTS public."invoice_communications_invoiceId_idx";
DROP INDEX IF EXISTS public."funnels_websiteId_slug_key";
DROP INDEX IF EXISTS public."funnel_steps_funnelId_slug_key";
DROP INDEX IF EXISTS public.donation_campaigns_slug_key;
DROP INDEX IF EXISTS public."church_themes_churchId_key";
DROP INDEX IF EXISTS public.church_subscriptions_status_idx;
DROP INDEX IF EXISTS public."church_subscriptions_planId_idx";
DROP INDEX IF EXISTS public."church_subscriptions_churchId_key";
DROP INDEX IF EXISTS public."church_subscriptions_churchId_idx";
DROP INDEX IF EXISTS public."church_subscription_addons_subscriptionId_addonId_key";
DROP INDEX IF EXISTS public."church_qualification_settings_churchId_key";
DROP INDEX IF EXISTS public."children_check_ins_qrCode_key";
DROP INDEX IF EXISTS public."check_ins_qrCode_key";
DROP INDEX IF EXISTS public."availability_matrices_memberId_key";
DROP INDEX IF EXISTS public.automation_triggers_type_idx;
DROP INDEX IF EXISTS public."automation_triggers_ruleId_idx";
DROP INDEX IF EXISTS public."automation_triggers_isActive_idx";
DROP INDEX IF EXISTS public."automation_templates_isActive_idx";
DROP INDEX IF EXISTS public.automation_templates_category_idx;
DROP INDEX IF EXISTS public.automation_rules_priority_idx;
DROP INDEX IF EXISTS public."automation_rules_isActive_idx";
DROP INDEX IF EXISTS public."automation_rules_churchId_idx";
DROP INDEX IF EXISTS public.automation_rule_executions_status_idx;
DROP INDEX IF EXISTS public."automation_rule_executions_ruleId_idx";
DROP INDEX IF EXISTS public."automation_rule_executions_createdAt_idx";
DROP INDEX IF EXISTS public.automation_conditions_type_idx;
DROP INDEX IF EXISTS public."automation_conditions_ruleId_idx";
DROP INDEX IF EXISTS public."automation_conditions_groupId_idx";
DROP INDEX IF EXISTS public.automation_actions_type_idx;
DROP INDEX IF EXISTS public."automation_actions_ruleId_idx";
DROP INDEX IF EXISTS public."automation_actions_orderIndex_idx";
DROP INDEX IF EXISTS public."analytics_cache_cacheKey_churchId_key";
DROP INDEX IF EXISTS public."accounts_provider_providerAccountId_key";
ALTER TABLE IF EXISTS ONLY public.websites DROP CONSTRAINT IF EXISTS websites_pkey;
ALTER TABLE IF EXISTS ONLY public.website_requests DROP CONSTRAINT IF EXISTS website_requests_pkey;
ALTER TABLE IF EXISTS ONLY public.website_analytics DROP CONSTRAINT IF EXISTS website_analytics_pkey;
ALTER TABLE IF EXISTS ONLY public.web_pages DROP CONSTRAINT IF EXISTS web_pages_pkey;
ALTER TABLE IF EXISTS ONLY public.web_page_sections DROP CONSTRAINT IF EXISTS web_page_sections_pkey;
ALTER TABLE IF EXISTS ONLY public.volunteers DROP CONSTRAINT IF EXISTS volunteers_pkey;
ALTER TABLE IF EXISTS ONLY public.volunteer_recommendations DROP CONSTRAINT IF EXISTS volunteer_recommendations_pkey;
ALTER TABLE IF EXISTS ONLY public.volunteer_engagement_scores DROP CONSTRAINT IF EXISTS volunteer_engagement_scores_pkey;
ALTER TABLE IF EXISTS ONLY public.volunteer_assignments DROP CONSTRAINT IF EXISTS volunteer_assignments_pkey;
ALTER TABLE IF EXISTS ONLY public.visitor_follow_ups DROP CONSTRAINT IF EXISTS visitor_follow_ups_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.user_theme_preferences DROP CONSTRAINT IF EXISTS user_theme_preferences_pkey;
ALTER TABLE IF EXISTS ONLY public.user_roles_advanced DROP CONSTRAINT IF EXISTS user_roles_advanced_pkey;
ALTER TABLE IF EXISTS ONLY public.user_permissions DROP CONSTRAINT IF EXISTS user_permissions_pkey;
ALTER TABLE IF EXISTS ONLY public.testimony_qr_codes DROP CONSTRAINT IF EXISTS testimony_qr_codes_pkey;
ALTER TABLE IF EXISTS ONLY public.testimony_forms DROP CONSTRAINT IF EXISTS testimony_forms_pkey;
ALTER TABLE IF EXISTS ONLY public.tenant_credentials DROP CONSTRAINT IF EXISTS tenant_credentials_pkey;
ALTER TABLE IF EXISTS ONLY public.support_contact_info DROP CONSTRAINT IF EXISTS support_contact_info_pkey;
ALTER TABLE IF EXISTS ONLY public.subscription_plans DROP CONSTRAINT IF EXISTS subscription_plans_pkey;
ALTER TABLE IF EXISTS ONLY public.subscription_addons DROP CONSTRAINT IF EXISTS subscription_addons_pkey;
ALTER TABLE IF EXISTS ONLY public.spiritual_gifts DROP CONSTRAINT IF EXISTS spiritual_gifts_pkey;
ALTER TABLE IF EXISTS ONLY public.social_media_posts DROP CONSTRAINT IF EXISTS social_media_posts_pkey;
ALTER TABLE IF EXISTS ONLY public.social_media_metrics DROP CONSTRAINT IF EXISTS social_media_metrics_pkey;
ALTER TABLE IF EXISTS ONLY public.social_media_accounts DROP CONSTRAINT IF EXISTS social_media_accounts_pkey;
ALTER TABLE IF EXISTS ONLY public.sessions DROP CONSTRAINT IF EXISTS sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.sermons DROP CONSTRAINT IF EXISTS sermons_pkey;
ALTER TABLE IF EXISTS ONLY public.roles DROP CONSTRAINT IF EXISTS roles_pkey;
ALTER TABLE IF EXISTS ONLY public.role_permissions DROP CONSTRAINT IF EXISTS role_permissions_pkey;
ALTER TABLE IF EXISTS ONLY public.report_schedules DROP CONSTRAINT IF EXISTS report_schedules_pkey;
ALTER TABLE IF EXISTS ONLY public.report_executions DROP CONSTRAINT IF EXISTS report_executions_pkey;
ALTER TABLE IF EXISTS ONLY public.push_subscriptions DROP CONSTRAINT IF EXISTS push_subscriptions_pkey;
ALTER TABLE IF EXISTS ONLY public.push_notification_logs DROP CONSTRAINT IF EXISTS push_notification_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.prayer_testimonies DROP CONSTRAINT IF EXISTS prayer_testimonies_pkey;
ALTER TABLE IF EXISTS ONLY public.prayer_response_templates DROP CONSTRAINT IF EXISTS prayer_response_templates_pkey;
ALTER TABLE IF EXISTS ONLY public.prayer_requests DROP CONSTRAINT IF EXISTS prayer_requests_pkey;
ALTER TABLE IF EXISTS ONLY public.prayer_qr_codes DROP CONSTRAINT IF EXISTS prayer_qr_codes_pkey;
ALTER TABLE IF EXISTS ONLY public.prayer_forms DROP CONSTRAINT IF EXISTS prayer_forms_pkey;
ALTER TABLE IF EXISTS ONLY public.prayer_contacts DROP CONSTRAINT IF EXISTS prayer_contacts_pkey;
ALTER TABLE IF EXISTS ONLY public.prayer_categories DROP CONSTRAINT IF EXISTS prayer_categories_pkey;
ALTER TABLE IF EXISTS ONLY public.prayer_approvals DROP CONSTRAINT IF EXISTS prayer_approvals_pkey;
ALTER TABLE IF EXISTS ONLY public.platform_settings DROP CONSTRAINT IF EXISTS platform_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.plan_features DROP CONSTRAINT IF EXISTS plan_features_pkey;
ALTER TABLE IF EXISTS ONLY public.permissions DROP CONSTRAINT IF EXISTS permissions_pkey;
ALTER TABLE IF EXISTS ONLY public.payment_methods DROP CONSTRAINT IF EXISTS payment_methods_pkey;
ALTER TABLE IF EXISTS ONLY public.payment_gateway_configs DROP CONSTRAINT IF EXISTS payment_gateway_configs_pkey;
ALTER TABLE IF EXISTS ONLY public.online_payments DROP CONSTRAINT IF EXISTS online_payments_pkey;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_pkey;
ALTER TABLE IF EXISTS ONLY public.notification_templates DROP CONSTRAINT IF EXISTS notification_templates_pkey;
ALTER TABLE IF EXISTS ONLY public.notification_preferences DROP CONSTRAINT IF EXISTS notification_preferences_pkey;
ALTER TABLE IF EXISTS ONLY public.ministry_gap_analyses DROP CONSTRAINT IF EXISTS ministry_gap_analyses_pkey;
ALTER TABLE IF EXISTS ONLY public.ministries DROP CONSTRAINT IF EXISTS ministries_pkey;
ALTER TABLE IF EXISTS ONLY public.members DROP CONSTRAINT IF EXISTS members_pkey;
ALTER TABLE IF EXISTS ONLY public.member_spiritual_profiles DROP CONSTRAINT IF EXISTS member_spiritual_profiles_pkey;
ALTER TABLE IF EXISTS ONLY public.marketing_campaigns DROP CONSTRAINT IF EXISTS marketing_campaigns_pkey;
ALTER TABLE IF EXISTS ONLY public.marketing_campaign_posts DROP CONSTRAINT IF EXISTS marketing_campaign_posts_pkey;
ALTER TABLE IF EXISTS ONLY public.kpi_metrics DROP CONSTRAINT IF EXISTS kpi_metrics_pkey;
ALTER TABLE IF EXISTS ONLY public.invoices DROP CONSTRAINT IF EXISTS invoices_pkey;
ALTER TABLE IF EXISTS ONLY public.invoice_payments DROP CONSTRAINT IF EXISTS invoice_payments_pkey;
ALTER TABLE IF EXISTS ONLY public.invoice_line_items DROP CONSTRAINT IF EXISTS invoice_line_items_pkey;
ALTER TABLE IF EXISTS ONLY public.invoice_communications DROP CONSTRAINT IF EXISTS invoice_communications_pkey;
ALTER TABLE IF EXISTS ONLY public.integration_configs DROP CONSTRAINT IF EXISTS integration_configs_pkey;
ALTER TABLE IF EXISTS ONLY public.funnels DROP CONSTRAINT IF EXISTS funnels_pkey;
ALTER TABLE IF EXISTS ONLY public.funnel_steps DROP CONSTRAINT IF EXISTS funnel_steps_pkey;
ALTER TABLE IF EXISTS ONLY public.funnel_conversions DROP CONSTRAINT IF EXISTS funnel_conversions_pkey;
ALTER TABLE IF EXISTS ONLY public.events DROP CONSTRAINT IF EXISTS events_pkey;
ALTER TABLE IF EXISTS ONLY public.event_resources DROP CONSTRAINT IF EXISTS event_resources_pkey;
ALTER TABLE IF EXISTS ONLY public.event_resource_reservations DROP CONSTRAINT IF EXISTS event_resource_reservations_pkey;
ALTER TABLE IF EXISTS ONLY public.donations DROP CONSTRAINT IF EXISTS donations_pkey;
ALTER TABLE IF EXISTS ONLY public.donation_categories DROP CONSTRAINT IF EXISTS donation_categories_pkey;
ALTER TABLE IF EXISTS ONLY public.donation_campaigns DROP CONSTRAINT IF EXISTS donation_campaigns_pkey;
ALTER TABLE IF EXISTS ONLY public.dashboard_widgets DROP CONSTRAINT IF EXISTS dashboard_widgets_pkey;
ALTER TABLE IF EXISTS ONLY public.custom_reports DROP CONSTRAINT IF EXISTS custom_reports_pkey;
ALTER TABLE IF EXISTS ONLY public.communications DROP CONSTRAINT IF EXISTS communications_pkey;
ALTER TABLE IF EXISTS ONLY public.communication_templates DROP CONSTRAINT IF EXISTS communication_templates_pkey;
ALTER TABLE IF EXISTS ONLY public.churches DROP CONSTRAINT IF EXISTS churches_pkey;
ALTER TABLE IF EXISTS ONLY public.church_themes DROP CONSTRAINT IF EXISTS church_themes_pkey;
ALTER TABLE IF EXISTS ONLY public.church_subscriptions DROP CONSTRAINT IF EXISTS church_subscriptions_pkey;
ALTER TABLE IF EXISTS ONLY public.church_subscription_addons DROP CONSTRAINT IF EXISTS church_subscription_addons_pkey;
ALTER TABLE IF EXISTS ONLY public.church_qualification_settings DROP CONSTRAINT IF EXISTS church_qualification_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.children_check_ins DROP CONSTRAINT IF EXISTS children_check_ins_pkey;
ALTER TABLE IF EXISTS ONLY public.check_ins DROP CONSTRAINT IF EXISTS check_ins_pkey;
ALTER TABLE IF EXISTS ONLY public.availability_matrices DROP CONSTRAINT IF EXISTS availability_matrices_pkey;
ALTER TABLE IF EXISTS ONLY public.automations DROP CONSTRAINT IF EXISTS automations_pkey;
ALTER TABLE IF EXISTS ONLY public.automation_triggers DROP CONSTRAINT IF EXISTS automation_triggers_pkey;
ALTER TABLE IF EXISTS ONLY public.automation_templates DROP CONSTRAINT IF EXISTS automation_templates_pkey;
ALTER TABLE IF EXISTS ONLY public.automation_rules DROP CONSTRAINT IF EXISTS automation_rules_pkey;
ALTER TABLE IF EXISTS ONLY public.automation_rule_executions DROP CONSTRAINT IF EXISTS automation_rule_executions_pkey;
ALTER TABLE IF EXISTS ONLY public.automation_executions DROP CONSTRAINT IF EXISTS automation_executions_pkey;
ALTER TABLE IF EXISTS ONLY public.automation_conditions DROP CONSTRAINT IF EXISTS automation_conditions_pkey;
ALTER TABLE IF EXISTS ONLY public.automation_actions DROP CONSTRAINT IF EXISTS automation_actions_pkey;
ALTER TABLE IF EXISTS ONLY public.analytics_dashboards DROP CONSTRAINT IF EXISTS analytics_dashboards_pkey;
ALTER TABLE IF EXISTS ONLY public.analytics_cache DROP CONSTRAINT IF EXISTS analytics_cache_pkey;
ALTER TABLE IF EXISTS ONLY public.accounts DROP CONSTRAINT IF EXISTS accounts_pkey;
DROP TABLE IF EXISTS public.websites;
DROP TABLE IF EXISTS public.website_requests;
DROP TABLE IF EXISTS public.website_analytics;
DROP TABLE IF EXISTS public.web_pages;
DROP TABLE IF EXISTS public.web_page_sections;
DROP TABLE IF EXISTS public.volunteers;
DROP TABLE IF EXISTS public.volunteer_recommendations;
DROP TABLE IF EXISTS public.volunteer_engagement_scores;
DROP TABLE IF EXISTS public.volunteer_assignments;
DROP TABLE IF EXISTS public.visitor_follow_ups;
DROP TABLE IF EXISTS public.verification_tokens;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.user_theme_preferences;
DROP TABLE IF EXISTS public.user_roles_advanced;
DROP TABLE IF EXISTS public.user_permissions;
DROP TABLE IF EXISTS public.testimony_qr_codes;
DROP TABLE IF EXISTS public.testimony_forms;
DROP TABLE IF EXISTS public.tenant_credentials;
DROP TABLE IF EXISTS public.support_contact_info;
DROP TABLE IF EXISTS public.subscription_plans;
DROP TABLE IF EXISTS public.subscription_addons;
DROP TABLE IF EXISTS public.spiritual_gifts;
DROP TABLE IF EXISTS public.social_media_posts;
DROP TABLE IF EXISTS public.social_media_metrics;
DROP TABLE IF EXISTS public.social_media_accounts;
DROP TABLE IF EXISTS public.sessions;
DROP TABLE IF EXISTS public.sermons;
DROP TABLE IF EXISTS public.roles;
DROP TABLE IF EXISTS public.role_permissions;
DROP TABLE IF EXISTS public.report_schedules;
DROP TABLE IF EXISTS public.report_executions;
DROP TABLE IF EXISTS public.push_subscriptions;
DROP TABLE IF EXISTS public.push_notification_logs;
DROP TABLE IF EXISTS public.prayer_testimonies;
DROP TABLE IF EXISTS public.prayer_response_templates;
DROP TABLE IF EXISTS public.prayer_requests;
DROP TABLE IF EXISTS public.prayer_qr_codes;
DROP TABLE IF EXISTS public.prayer_forms;
DROP TABLE IF EXISTS public.prayer_contacts;
DROP TABLE IF EXISTS public.prayer_categories;
DROP TABLE IF EXISTS public.prayer_approvals;
DROP TABLE IF EXISTS public.platform_settings;
DROP TABLE IF EXISTS public.plan_features;
DROP TABLE IF EXISTS public.permissions;
DROP TABLE IF EXISTS public.payment_methods;
DROP TABLE IF EXISTS public.payment_gateway_configs;
DROP TABLE IF EXISTS public.online_payments;
DROP TABLE IF EXISTS public.notifications;
DROP TABLE IF EXISTS public.notification_templates;
DROP TABLE IF EXISTS public.notification_preferences;
DROP TABLE IF EXISTS public.ministry_gap_analyses;
DROP TABLE IF EXISTS public.ministries;
DROP TABLE IF EXISTS public.members;
DROP TABLE IF EXISTS public.member_spiritual_profiles;
DROP TABLE IF EXISTS public.marketing_campaigns;
DROP TABLE IF EXISTS public.marketing_campaign_posts;
DROP TABLE IF EXISTS public.kpi_metrics;
DROP TABLE IF EXISTS public.invoices;
DROP TABLE IF EXISTS public.invoice_payments;
DROP TABLE IF EXISTS public.invoice_line_items;
DROP TABLE IF EXISTS public.invoice_communications;
DROP TABLE IF EXISTS public.integration_configs;
DROP TABLE IF EXISTS public.funnels;
DROP TABLE IF EXISTS public.funnel_steps;
DROP TABLE IF EXISTS public.funnel_conversions;
DROP TABLE IF EXISTS public.events;
DROP TABLE IF EXISTS public.event_resources;
DROP TABLE IF EXISTS public.event_resource_reservations;
DROP TABLE IF EXISTS public.donations;
DROP TABLE IF EXISTS public.donation_categories;
DROP TABLE IF EXISTS public.donation_campaigns;
DROP TABLE IF EXISTS public.dashboard_widgets;
DROP TABLE IF EXISTS public.custom_reports;
DROP TABLE IF EXISTS public.communications;
DROP TABLE IF EXISTS public.communication_templates;
DROP TABLE IF EXISTS public.churches;
DROP TABLE IF EXISTS public.church_themes;
DROP TABLE IF EXISTS public.church_subscriptions;
DROP TABLE IF EXISTS public.church_subscription_addons;
DROP TABLE IF EXISTS public.church_qualification_settings;
DROP TABLE IF EXISTS public.children_check_ins;
DROP TABLE IF EXISTS public.check_ins;
DROP TABLE IF EXISTS public.availability_matrices;
DROP TABLE IF EXISTS public.automations;
DROP TABLE IF EXISTS public.automation_triggers;
DROP TABLE IF EXISTS public.automation_templates;
DROP TABLE IF EXISTS public.automation_rules;
DROP TABLE IF EXISTS public.automation_rule_executions;
DROP TABLE IF EXISTS public.automation_executions;
DROP TABLE IF EXISTS public.automation_conditions;
DROP TABLE IF EXISTS public.automation_actions;
DROP TABLE IF EXISTS public.analytics_dashboards;
DROP TABLE IF EXISTS public.analytics_cache;
DROP TABLE IF EXISTS public.accounts;
DROP TYPE IF EXISTS public."UserRole";
DROP TYPE IF EXISTS public."FunnelType";
DROP TYPE IF EXISTS public."FunnelStepType";
DROP TYPE IF EXISTS public."AutomationTriggerType";
DROP TYPE IF EXISTS public."AutomationConditionType";
DROP TYPE IF EXISTS public."AutomationActionType";
-- *not* dropping schema, since initdb creates it
--
-- TOC entry 5 (class 2615 OID 9479856)
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


--
-- TOC entry 4672 (class 0 OID 0)
-- Dependencies: 5
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS '';


--
-- TOC entry 954 (class 1247 OID 9479958)
-- Name: AutomationActionType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AutomationActionType" AS ENUM (
    'SEND_NOTIFICATION',
    'SEND_EMAIL',
    'SEND_PUSH',
    'SEND_SMS',
    'CREATE_FOLLOW_UP',
    'ASSIGN_VOLUNTEER',
    'UPDATE_MEMBER',
    'CREATE_EVENT',
    'CUSTOM_WEBHOOK'
);


--
-- TOC entry 951 (class 1247 OID 9479924)
-- Name: AutomationConditionType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AutomationConditionType" AS ENUM (
    'EQUALS',
    'NOT_EQUALS',
    'GREATER_THAN',
    'LESS_THAN',
    'CONTAINS',
    'NOT_CONTAINS',
    'IN',
    'NOT_IN',
    'EXISTS',
    'NOT_EXISTS',
    'DATE_BEFORE',
    'DATE_AFTER',
    'DATE_BETWEEN',
    'TIME_BEFORE',
    'TIME_AFTER',
    'CUSTOM'
);


--
-- TOC entry 948 (class 1247 OID 9479898)
-- Name: AutomationTriggerType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AutomationTriggerType" AS ENUM (
    'MEMBER_JOINED',
    'DONATION_RECEIVED',
    'EVENT_CREATED',
    'EVENT_UPDATED',
    'ATTENDANCE_RECORDED',
    'VOLUNTEER_ASSIGNED',
    'BIRTHDAY',
    'ANNIVERSARY',
    'SERMON_PUBLISHED',
    'COMMUNICATION_SENT',
    'FOLLOW_UP_DUE',
    'CUSTOM_EVENT'
);


--
-- TOC entry 945 (class 1247 OID 9479882)
-- Name: FunnelStepType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."FunnelStepType" AS ENUM (
    'LANDING_PAGE',
    'OPT_IN',
    'THANK_YOU',
    'SALES_PAGE',
    'CHECKOUT',
    'CONFIRMATION',
    'CUSTOM'
);


--
-- TOC entry 942 (class 1247 OID 9479870)
-- Name: FunnelType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."FunnelType" AS ENUM (
    'LEAD_GENERATION',
    'EVENT_REGISTRATION',
    'DONATION',
    'NEWSLETTER',
    'CUSTOM'
);


--
-- TOC entry 939 (class 1247 OID 9479858)
-- Name: UserRole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."UserRole" AS ENUM (
    'SUPER_ADMIN',
    'ADMIN_IGLESIA',
    'PASTOR',
    'LIDER',
    'MIEMBRO'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 258 (class 1259 OID 9480401)
-- Name: accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.accounts (
    id text NOT NULL,
    "userId" text NOT NULL,
    type text NOT NULL,
    provider text NOT NULL,
    "providerAccountId" text NOT NULL,
    refresh_token text,
    access_token text,
    expires_at integer,
    token_type text,
    scope text,
    id_token text,
    session_state text
);


--
-- TOC entry 257 (class 1259 OID 9480393)
-- Name: analytics_cache; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.analytics_cache (
    id text NOT NULL,
    "cacheKey" text NOT NULL,
    "dataType" text NOT NULL,
    data text NOT NULL,
    parameters text,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 254 (class 1259 OID 9480361)
-- Name: analytics_dashboards; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.analytics_dashboards (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    layout text NOT NULL,
    "isDefault" boolean DEFAULT false NOT NULL,
    "isPublic" boolean DEFAULT false NOT NULL,
    "userRole" text,
    "createdBy" text NOT NULL,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 273 (class 1259 OID 9480559)
-- Name: automation_actions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.automation_actions (
    id text NOT NULL,
    "ruleId" text NOT NULL,
    type public."AutomationActionType" NOT NULL,
    configuration jsonb DEFAULT '{}'::jsonb NOT NULL,
    "orderIndex" integer DEFAULT 0 NOT NULL,
    delay integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 272 (class 1259 OID 9480548)
-- Name: automation_conditions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.automation_conditions (
    id text NOT NULL,
    "ruleId" text NOT NULL,
    type public."AutomationConditionType" NOT NULL,
    field text NOT NULL,
    operator text NOT NULL,
    value jsonb NOT NULL,
    "logicalOperator" text DEFAULT 'AND'::text NOT NULL,
    "groupId" text,
    "orderIndex" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 245 (class 1259 OID 9480275)
-- Name: automation_executions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.automation_executions (
    id text NOT NULL,
    "automationId" text NOT NULL,
    "triggerData" text,
    status text DEFAULT 'EJECUTANDO'::text NOT NULL,
    results text,
    "executedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "completedAt" timestamp(3) without time zone,
    "churchId" text NOT NULL
);


--
-- TOC entry 274 (class 1259 OID 9480571)
-- Name: automation_rule_executions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.automation_rule_executions (
    id text NOT NULL,
    "ruleId" text NOT NULL,
    "triggerData" jsonb NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    result jsonb,
    error text,
    "executedAt" timestamp(3) without time zone,
    duration integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 270 (class 1259 OID 9480526)
-- Name: automation_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.automation_rules (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "churchId" text NOT NULL,
    "createdBy" text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    "executeOnce" boolean DEFAULT false NOT NULL,
    "maxExecutions" integer,
    "executionCount" integer DEFAULT 0 NOT NULL,
    "lastExecuted" timestamp(3) without time zone,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 275 (class 1259 OID 9480580)
-- Name: automation_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.automation_templates (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    category text NOT NULL,
    template jsonb NOT NULL,
    "isSystem" boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "usageCount" integer DEFAULT 0 NOT NULL,
    "createdBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 271 (class 1259 OID 9480538)
-- Name: automation_triggers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.automation_triggers (
    id text NOT NULL,
    "ruleId" text NOT NULL,
    type public."AutomationTriggerType" NOT NULL,
    "eventSource" text,
    configuration jsonb DEFAULT '{}'::jsonb NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 244 (class 1259 OID 9480266)
-- Name: automations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.automations (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    trigger text NOT NULL,
    actions text NOT NULL,
    conditions text,
    "isActive" boolean DEFAULT true NOT NULL,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 299 (class 1259 OID 9480834)
-- Name: availability_matrices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.availability_matrices (
    id text NOT NULL,
    "memberId" text NOT NULL,
    "recurringAvailability" jsonb NOT NULL,
    "blackoutDates" jsonb NOT NULL,
    "preferredMinistries" jsonb NOT NULL,
    "maxCommitmentsPerMonth" integer DEFAULT 4 NOT NULL,
    "preferredTimeSlots" jsonb NOT NULL,
    "travelWillingness" integer DEFAULT 1 NOT NULL,
    "lastUpdated" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 230 (class 1259 OID 9480101)
-- Name: check_ins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.check_ins (
    id text NOT NULL,
    "firstName" text NOT NULL,
    "lastName" text NOT NULL,
    email text,
    phone text,
    "isFirstTime" boolean DEFAULT false NOT NULL,
    "visitReason" text,
    "prayerRequest" text,
    "qrCode" text,
    "eventId" text,
    "churchId" text NOT NULL,
    "checkedInAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "visitorType" text,
    "ministryInterest" text[] DEFAULT ARRAY[]::text[],
    "ageGroup" text,
    "familyStatus" text,
    "referredBy" text,
    "followUpFormId" text,
    "automationTriggered" boolean DEFAULT false NOT NULL,
    "lastContactDate" timestamp(3) without time zone,
    "engagementScore" integer DEFAULT 0 NOT NULL
);


--
-- TOC entry 232 (class 1259 OID 9480125)
-- Name: children_check_ins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.children_check_ins (
    id text NOT NULL,
    "childName" text NOT NULL,
    "childAge" integer,
    "parentName" text NOT NULL,
    "parentPhone" text NOT NULL,
    "parentEmail" text,
    "emergencyContact" text,
    "emergencyPhone" text,
    allergies text,
    "specialNeeds" text,
    "qrCode" text NOT NULL,
    "checkedIn" boolean DEFAULT true NOT NULL,
    "checkedInAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "checkedOut" boolean DEFAULT false NOT NULL,
    "checkedOutAt" timestamp(3) without time zone,
    "checkedOutBy" text,
    "eventId" text,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "childPhotoUrl" text,
    "parentPhotoUrl" text,
    "securityPin" text DEFAULT '000000'::text NOT NULL,
    "biometricHash" text,
    "photoTakenAt" timestamp(3) without time zone,
    "backupAuthCodes" text[] DEFAULT ARRAY[]::text[],
    "pickupAttempts" jsonb[] DEFAULT ARRAY[]::jsonb[],
    "requiresBothAuth" boolean DEFAULT true NOT NULL
);


--
-- TOC entry 310 (class 1259 OID 9671074)
-- Name: church_qualification_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.church_qualification_settings (
    id text NOT NULL,
    "churchId" text NOT NULL,
    "volunteerMinMembershipDays" integer DEFAULT 0 NOT NULL,
    "volunteerRequireActiveStatus" boolean DEFAULT true NOT NULL,
    "volunteerRequireSpiritualAssessment" boolean DEFAULT false NOT NULL,
    "volunteerMinSpiritualScore" integer DEFAULT 0 NOT NULL,
    "leadershipMinMembershipDays" integer DEFAULT 365 NOT NULL,
    "leadershipRequireVolunteerExp" boolean DEFAULT false NOT NULL,
    "leadershipMinVolunteerDays" integer DEFAULT 0 NOT NULL,
    "leadershipRequireTraining" boolean DEFAULT false NOT NULL,
    "leadershipMinSpiritualScore" integer DEFAULT 70 NOT NULL,
    "leadershipMinLeadershipScore" integer DEFAULT 60 NOT NULL,
    "enableSpiritualMaturityScoring" boolean DEFAULT true NOT NULL,
    "enableLeadershipAptitudeScoring" boolean DEFAULT true NOT NULL,
    "enableMinistryPassionMatching" boolean DEFAULT true NOT NULL,
    "spiritualGiftsWeight" double precision DEFAULT 0.4 NOT NULL,
    "availabilityWeight" double precision DEFAULT 0.25 NOT NULL,
    "experienceWeight" double precision DEFAULT 0.15 NOT NULL,
    "ministryPassionWeight" double precision DEFAULT 0.1 NOT NULL,
    "activityWeight" double precision DEFAULT 0.1 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 282 (class 1259 OID 9480653)
-- Name: church_subscription_addons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.church_subscription_addons (
    id text NOT NULL,
    "subscriptionId" text NOT NULL,
    "addonId" text NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 281 (class 1259 OID 9480642)
-- Name: church_subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.church_subscriptions (
    id text NOT NULL,
    "churchId" text NOT NULL,
    "planId" text NOT NULL,
    "billingCycle" text DEFAULT 'MONTHLY'::text NOT NULL,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    "currentPeriodStart" timestamp(3) without time zone NOT NULL,
    "currentPeriodEnd" timestamp(3) without time zone NOT NULL,
    "trialEnd" timestamp(3) without time zone,
    "cancelAtPeriodEnd" boolean DEFAULT false NOT NULL,
    "cancelledAt" timestamp(3) without time zone,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 269 (class 1259 OID 9480509)
-- Name: church_themes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.church_themes (
    id text NOT NULL,
    "churchId" text NOT NULL,
    "themeName" text DEFAULT 'church-default'::text NOT NULL,
    "themeConfig" text NOT NULL,
    "logoUrl" text,
    "faviconUrl" text,
    "bannerUrl" text,
    "brandColors" text,
    "primaryFont" text DEFAULT 'Inter'::text,
    "headingFont" text DEFAULT 'Inter'::text,
    "layoutStyle" text DEFAULT 'default'::text,
    "allowMemberThemes" boolean DEFAULT true NOT NULL,
    "allowColorChanges" boolean DEFAULT true NOT NULL,
    "allowFontChanges" boolean DEFAULT true NOT NULL,
    "allowLayoutChanges" boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 217 (class 1259 OID 9479977)
-- Name: churches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.churches (
    id text NOT NULL,
    name text NOT NULL,
    address text,
    phone text,
    email text,
    website text,
    founded timestamp(3) without time zone,
    logo text,
    description text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 240 (class 1259 OID 9480230)
-- Name: communication_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.communication_templates (
    id text NOT NULL,
    name text NOT NULL,
    subject text,
    content text NOT NULL,
    type text NOT NULL,
    variables text,
    category text,
    "isActive" boolean DEFAULT true NOT NULL,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 239 (class 1259 OID 9480221)
-- Name: communications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.communications (
    id text NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    type text NOT NULL,
    "targetGroup" text,
    recipients integer,
    status text DEFAULT 'BORRADOR'::text NOT NULL,
    "scheduledAt" timestamp(3) without time zone,
    "sentAt" timestamp(3) without time zone,
    "sentBy" text NOT NULL,
    "templateId" text,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 251 (class 1259 OID 9480332)
-- Name: custom_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_reports (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "reportType" text NOT NULL,
    config text NOT NULL,
    filters text,
    columns text NOT NULL,
    "groupBy" text,
    "sortBy" text,
    "chartType" text,
    "isPublic" boolean DEFAULT false NOT NULL,
    "isTemplate" boolean DEFAULT false NOT NULL,
    "createdBy" text NOT NULL,
    "churchId" text NOT NULL,
    "lastRunAt" timestamp(3) without time zone,
    "runCount" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 255 (class 1259 OID 9480371)
-- Name: dashboard_widgets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dashboard_widgets (
    id text NOT NULL,
    "dashboardId" text NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    "chartType" text,
    "dataSource" text NOT NULL,
    filters text,
    "position" text NOT NULL,
    "refreshInterval" integer DEFAULT 300 NOT NULL,
    "isVisible" boolean DEFAULT true NOT NULL,
    config text,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 286 (class 1259 OID 9480700)
-- Name: donation_campaigns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.donation_campaigns (
    id text NOT NULL,
    title text NOT NULL,
    description text,
    "goalAmount" double precision,
    "currentAmount" double precision DEFAULT 0 NOT NULL,
    currency text DEFAULT 'COP'::text NOT NULL,
    "churchId" text NOT NULL,
    "categoryId" text,
    "isActive" boolean DEFAULT true NOT NULL,
    "isPublic" boolean DEFAULT true NOT NULL,
    slug text,
    "coverImage" text,
    "startDate" timestamp(3) without time zone,
    "endDate" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 233 (class 1259 OID 9480140)
-- Name: donation_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.donation_categories (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "churchId" text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 235 (class 1259 OID 9480159)
-- Name: donations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.donations (
    id text NOT NULL,
    amount double precision NOT NULL,
    currency text DEFAULT 'COP'::text NOT NULL,
    "donorName" text,
    "donorEmail" text,
    "donorPhone" text,
    "memberId" text,
    "categoryId" text NOT NULL,
    "paymentMethodId" text NOT NULL,
    reference text,
    notes text,
    "isAnonymous" boolean DEFAULT false NOT NULL,
    status text DEFAULT 'COMPLETADA'::text NOT NULL,
    "donationDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "campaignId" text
);


--
-- TOC entry 242 (class 1259 OID 9480248)
-- Name: event_resource_reservations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_resource_reservations (
    id text NOT NULL,
    "resourceId" text NOT NULL,
    "eventId" text NOT NULL,
    "startTime" timestamp(3) without time zone NOT NULL,
    "endTime" timestamp(3) without time zone NOT NULL,
    notes text,
    status text DEFAULT 'CONFIRMADA'::text NOT NULL,
    "reservedBy" text NOT NULL,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 241 (class 1259 OID 9480239)
-- Name: event_resources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_resources (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    type text NOT NULL,
    capacity integer,
    "isActive" boolean DEFAULT true NOT NULL,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 227 (class 1259 OID 9480074)
-- Name: events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.events (
    id text NOT NULL,
    title text NOT NULL,
    description text,
    "startDate" timestamp(3) without time zone NOT NULL,
    "endDate" timestamp(3) without time zone,
    location text,
    "churchId" text NOT NULL,
    "isPublic" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 266 (class 1259 OID 9480474)
-- Name: funnel_conversions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.funnel_conversions (
    id text NOT NULL,
    email text NOT NULL,
    "firstName" text,
    "lastName" text,
    phone text,
    data jsonb,
    source text,
    "ipAddress" text,
    "userAgent" text,
    "funnelId" text NOT NULL,
    "stepId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 265 (class 1259 OID 9480465)
-- Name: funnel_steps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.funnel_steps (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    content jsonb NOT NULL,
    type public."FunnelStepType" NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    settings jsonb NOT NULL,
    "funnelId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 264 (class 1259 OID 9480455)
-- Name: funnels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.funnels (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    description text,
    type public."FunnelType" NOT NULL,
    config jsonb NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "isPublished" boolean DEFAULT false NOT NULL,
    "websiteId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 243 (class 1259 OID 9480257)
-- Name: integration_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.integration_configs (
    id text NOT NULL,
    service text NOT NULL,
    config text NOT NULL,
    "isActive" boolean DEFAULT false NOT NULL,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 308 (class 1259 OID 9579027)
-- Name: invoice_communications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoice_communications (
    id text NOT NULL,
    "invoiceId" text NOT NULL,
    type text NOT NULL,
    direction text NOT NULL,
    subject text,
    message text NOT NULL,
    "sentBy" text,
    "sentTo" text,
    status text DEFAULT 'SENT'::text NOT NULL,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 306 (class 1259 OID 9579009)
-- Name: invoice_line_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoice_line_items (
    id text NOT NULL,
    "invoiceId" text NOT NULL,
    description text NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    "unitPrice" double precision NOT NULL,
    "totalPrice" double precision NOT NULL,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 307 (class 1259 OID 9579018)
-- Name: invoice_payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoice_payments (
    id text NOT NULL,
    "invoiceId" text NOT NULL,
    amount double precision NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "paymentMethod" text NOT NULL,
    reference text,
    notes text,
    "verifiedBy" text,
    "verifiedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 305 (class 1259 OID 9578996)
-- Name: invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoices (
    id text NOT NULL,
    "invoiceNumber" text NOT NULL,
    "churchId" text NOT NULL,
    "subscriptionId" text,
    status text DEFAULT 'DRAFT'::text NOT NULL,
    type text DEFAULT 'SUBSCRIPTION'::text NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    subtotal double precision NOT NULL,
    "taxAmount" double precision DEFAULT 0.0 NOT NULL,
    "totalAmount" double precision NOT NULL,
    "dueDate" timestamp(3) without time zone NOT NULL,
    "isRecurrent" boolean DEFAULT false NOT NULL,
    "recurrentConfig" jsonb,
    notes text,
    "pdfPath" text,
    "sentAt" timestamp(3) without time zone,
    "paidAt" timestamp(3) without time zone,
    "createdBy" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 256 (class 1259 OID 9480381)
-- Name: kpi_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kpi_metrics (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    category text NOT NULL,
    "metricType" text NOT NULL,
    "dataSource" text NOT NULL,
    target double precision,
    "currentValue" double precision NOT NULL,
    "previousValue" double precision,
    "changePercent" double precision,
    "trendDirection" text,
    color text DEFAULT 'blue'::text NOT NULL,
    icon text,
    unit text,
    period text DEFAULT 'MONTHLY'::text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "churchId" text NOT NULL,
    "lastCalculated" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 249 (class 1259 OID 9480312)
-- Name: marketing_campaign_posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.marketing_campaign_posts (
    id text NOT NULL,
    "campaignId" text NOT NULL,
    "postId" text NOT NULL,
    "accountId" text NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    "scheduledAt" timestamp(3) without time zone,
    "publishedAt" timestamp(3) without time zone,
    status text DEFAULT 'PENDING'::text NOT NULL,
    metrics text,
    notes text,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 248 (class 1259 OID 9480302)
-- Name: marketing_campaigns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.marketing_campaigns (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    objectives text,
    "targetAudience" text,
    budget double precision,
    currency text DEFAULT 'USD'::text NOT NULL,
    "startDate" timestamp(3) without time zone NOT NULL,
    "endDate" timestamp(3) without time zone,
    status text DEFAULT 'DRAFT'::text NOT NULL,
    platforms text NOT NULL,
    metrics text,
    tags text,
    "managerId" text NOT NULL,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 298 (class 1259 OID 9480823)
-- Name: member_spiritual_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_spiritual_profiles (
    id text NOT NULL,
    "memberId" text NOT NULL,
    "primaryGifts" jsonb NOT NULL,
    "secondaryGifts" jsonb NOT NULL,
    "spiritualCalling" text,
    "ministryPassions" jsonb NOT NULL,
    "experienceLevel" integer DEFAULT 1 NOT NULL,
    "leadershipScore" integer DEFAULT 1 NOT NULL,
    "servingMotivation" text,
    "previousExperience" jsonb,
    "trainingCompleted" jsonb,
    "assessmentDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "availabilityScore" integer DEFAULT 50 NOT NULL,
    "communicationSkills" integer DEFAULT 50 NOT NULL,
    "discipleshipTraining" boolean DEFAULT false NOT NULL,
    "leadershipAptitudeScore" integer DEFAULT 50 NOT NULL,
    "leadershipReadinessScore" integer DEFAULT 0 NOT NULL,
    "leadershipTrainingCompleted" boolean DEFAULT false NOT NULL,
    "leadershipTrainingDate" timestamp(3) without time zone,
    "mentoringExperience" boolean DEFAULT false NOT NULL,
    "ministryPassionScore" integer DEFAULT 50 NOT NULL,
    "organizationalSkills" integer DEFAULT 50 NOT NULL,
    "pastoralHeart" integer DEFAULT 50 NOT NULL,
    "spiritualMaturityScore" integer DEFAULT 50 NOT NULL,
    "teachingAbility" integer DEFAULT 50 NOT NULL,
    "volunteerReadinessScore" integer DEFAULT 0 NOT NULL
);


--
-- TOC entry 225 (class 1259 OID 9480051)
-- Name: members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.members (
    id text NOT NULL,
    "firstName" text NOT NULL,
    "lastName" text NOT NULL,
    email text,
    phone text,
    address text,
    city text,
    state text,
    "zipCode" text,
    "birthDate" timestamp(3) without time zone,
    "baptismDate" timestamp(3) without time zone,
    "membershipDate" timestamp(3) without time zone,
    "maritalStatus" text,
    gender text,
    occupation text,
    photo text,
    notes text,
    "churchId" text NOT NULL,
    "userId" text,
    "ministryId" text,
    "isActive" boolean DEFAULT true NOT NULL,
    "spiritualGifts" jsonb,
    "secondaryGifts" jsonb,
    "spiritualCalling" text,
    "ministryPassion" jsonb,
    "experienceLevel" integer DEFAULT 1,
    "availabilityScore" double precision DEFAULT 0.0,
    "leadershipReadiness" integer DEFAULT 1,
    "skillsMatrix" jsonb,
    "personalityType" text,
    "transportationOwned" boolean DEFAULT false,
    "childcareAvailable" boolean DEFAULT false,
    "backgroundCheckDate" timestamp(3) without time zone,
    "emergencyContact" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 218 (class 1259 OID 9479986)
-- Name: ministries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ministries (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "churchId" text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 301 (class 1259 OID 9480855)
-- Name: ministry_gap_analyses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ministry_gap_analyses (
    id text NOT NULL,
    "ministryId" text NOT NULL,
    "churchId" text NOT NULL,
    "analysisDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "gapsIdentified" jsonb NOT NULL,
    "urgencyScore" integer NOT NULL,
    "recommendedActions" jsonb NOT NULL,
    "currentStaffing" integer NOT NULL,
    "optimalStaffing" integer NOT NULL,
    "gapPercentage" double precision NOT NULL,
    "seasonalFactor" double precision DEFAULT 1.0 NOT NULL,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 237 (class 1259 OID 9480182)
-- Name: notification_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_preferences (
    id text NOT NULL,
    "userId" text NOT NULL,
    "emailEnabled" boolean DEFAULT true NOT NULL,
    "emailEvents" boolean DEFAULT true NOT NULL,
    "emailDonations" boolean DEFAULT true NOT NULL,
    "emailCommunications" boolean DEFAULT true NOT NULL,
    "emailSystemUpdates" boolean DEFAULT true NOT NULL,
    "inAppEnabled" boolean DEFAULT true NOT NULL,
    "inAppEvents" boolean DEFAULT true NOT NULL,
    "inAppDonations" boolean DEFAULT true NOT NULL,
    "inAppCommunications" boolean DEFAULT true NOT NULL,
    "inAppSystemUpdates" boolean DEFAULT true NOT NULL,
    "pushEnabled" boolean DEFAULT false NOT NULL,
    "pushEvents" boolean DEFAULT true NOT NULL,
    "pushDonations" boolean DEFAULT false NOT NULL,
    "pushCommunications" boolean DEFAULT true NOT NULL,
    "pushSystemUpdates" boolean DEFAULT true NOT NULL,
    "quietHoursEnabled" boolean DEFAULT false NOT NULL,
    "quietHoursStart" text,
    "quietHoursEnd" text,
    "weekendNotifications" boolean DEFAULT true NOT NULL,
    "digestEnabled" boolean DEFAULT false NOT NULL,
    "digestFrequency" text DEFAULT 'DAILY'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 238 (class 1259 OID 9480209)
-- Name: notification_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_templates (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    category text NOT NULL,
    type text DEFAULT 'INFO'::text NOT NULL,
    priority text DEFAULT 'NORMAL'::text NOT NULL,
    "titleTemplate" text NOT NULL,
    "messageTemplate" text NOT NULL,
    "actionLabel" text,
    "isActive" boolean DEFAULT true NOT NULL,
    "isSystem" boolean DEFAULT false NOT NULL,
    "defaultTargetRole" text,
    "churchId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 236 (class 1259 OID 9480171)
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id text NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    type text NOT NULL,
    category text,
    "targetRole" text,
    "targetUser" text,
    "isRead" boolean DEFAULT false NOT NULL,
    "isGlobal" boolean DEFAULT false NOT NULL,
    priority text DEFAULT 'NORMAL'::text NOT NULL,
    "actionUrl" text,
    "actionLabel" text,
    "expiresAt" timestamp(3) without time zone,
    "churchId" text NOT NULL,
    "createdBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 284 (class 1259 OID 9480679)
-- Name: online_payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.online_payments (
    id text NOT NULL,
    "paymentId" text NOT NULL,
    amount double precision NOT NULL,
    currency text DEFAULT 'COP'::text NOT NULL,
    "gatewayType" text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    "donorName" text,
    "donorEmail" text,
    "donorPhone" text,
    "donationId" text,
    "churchId" text NOT NULL,
    "categoryId" text,
    reference text,
    "gatewayReference" text,
    "redirectUrl" text,
    "returnUrl" text,
    notes text,
    metadata jsonb,
    "webhookReceived" boolean DEFAULT false NOT NULL,
    "completedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 285 (class 1259 OID 9480690)
-- Name: payment_gateway_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_gateway_configs (
    id text NOT NULL,
    "gatewayType" text NOT NULL,
    "churchId" text NOT NULL,
    "isEnabled" boolean DEFAULT false NOT NULL,
    "isTestMode" boolean DEFAULT true NOT NULL,
    "merchantId" text,
    "apiKey" text,
    "clientId" text,
    "clientSecret" text,
    "webhookSecret" text,
    configuration jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 234 (class 1259 OID 9480149)
-- Name: payment_methods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_methods (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "isDigital" boolean DEFAULT false NOT NULL,
    "churchId" text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 219 (class 1259 OID 9479995)
-- Name: permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permissions (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    resource text NOT NULL,
    action text NOT NULL,
    conditions text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 279 (class 1259 OID 9480623)
-- Name: plan_features; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plan_features (
    id text NOT NULL,
    key text NOT NULL,
    name text NOT NULL,
    description text,
    category text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 304 (class 1259 OID 9480891)
-- Name: platform_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.platform_settings (
    id text DEFAULT 'default'::text NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "taxRate" double precision DEFAULT 0.0 NOT NULL,
    "freeTrialDays" integer DEFAULT 14 NOT NULL,
    "gracePeriodDays" integer DEFAULT 7 NOT NULL,
    "platformName" text DEFAULT 'Kḥesed-tek Church Management Systems'::text NOT NULL,
    "supportEmail" text DEFAULT 'soporte@khesedtek.com'::text NOT NULL,
    "maintenanceMode" boolean DEFAULT false NOT NULL,
    "allowRegistrations" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 291 (class 1259 OID 9480753)
-- Name: prayer_approvals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prayer_approvals (
    id text NOT NULL,
    "requestId" text NOT NULL,
    "contactId" text NOT NULL,
    "approvedBy" text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    notes text,
    "approvedAt" timestamp(3) without time zone,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 287 (class 1259 OID 9480712)
-- Name: prayer_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prayer_categories (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    icon text,
    color text,
    "isActive" boolean DEFAULT true NOT NULL,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 289 (class 1259 OID 9480731)
-- Name: prayer_contacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prayer_contacts (
    id text NOT NULL,
    "fullName" text NOT NULL,
    phone text,
    email text,
    "preferredContact" text DEFAULT 'sms'::text NOT NULL,
    "churchId" text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    source text DEFAULT 'prayer_form'::text NOT NULL,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 292 (class 1259 OID 9480762)
-- Name: prayer_forms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prayer_forms (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    fields jsonb NOT NULL,
    style jsonb,
    "isActive" boolean DEFAULT true NOT NULL,
    "isPublic" boolean DEFAULT true NOT NULL,
    slug text NOT NULL,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 293 (class 1259 OID 9480772)
-- Name: prayer_qr_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prayer_qr_codes (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "formId" text NOT NULL,
    code text NOT NULL,
    design jsonb,
    "isActive" boolean DEFAULT true NOT NULL,
    "scanCount" integer DEFAULT 0 NOT NULL,
    "lastScan" timestamp(3) without time zone,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 290 (class 1259 OID 9480742)
-- Name: prayer_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prayer_requests (
    id text NOT NULL,
    "contactId" text NOT NULL,
    "categoryId" text NOT NULL,
    message text,
    "isAnonymous" boolean DEFAULT false NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    priority text DEFAULT 'normal'::text NOT NULL,
    "scheduledAt" timestamp(3) without time zone,
    "sentAt" timestamp(3) without time zone,
    "responseType" text,
    "churchId" text NOT NULL,
    "formId" text,
    "qrCodeId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 288 (class 1259 OID 9480721)
-- Name: prayer_response_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prayer_response_templates (
    id text NOT NULL,
    "categoryId" text NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    "smsMessage" text,
    "isActive" boolean DEFAULT true NOT NULL,
    "isDefault" boolean DEFAULT false NOT NULL,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 294 (class 1259 OID 9480782)
-- Name: prayer_testimonies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prayer_testimonies (
    id text NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    "contactId" text,
    "prayerRequestId" text,
    category text DEFAULT 'general'::text NOT NULL,
    "isAnonymous" boolean DEFAULT false NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    "isPublic" boolean DEFAULT false NOT NULL,
    "imageUrl" text,
    tags jsonb,
    "churchId" text NOT NULL,
    "formId" text,
    "qrCodeId" text,
    "approvedBy" text,
    "approvedAt" timestamp(3) without time zone,
    "submittedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 277 (class 1259 OID 9480600)
-- Name: push_notification_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.push_notification_logs (
    id text NOT NULL,
    "churchId" text NOT NULL,
    "userId" text,
    title text NOT NULL,
    body text NOT NULL,
    payload jsonb,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "deliveryAttempts" integer DEFAULT 0 NOT NULL,
    "lastAttempt" timestamp(3) without time zone,
    error text,
    "clickedAt" timestamp(3) without time zone,
    "dismissedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 276 (class 1259 OID 9480591)
-- Name: push_subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.push_subscriptions (
    id text NOT NULL,
    "userId" text NOT NULL,
    "churchId" text NOT NULL,
    endpoint text NOT NULL,
    p256dh text NOT NULL,
    auth text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "userAgent" text,
    platform text,
    language text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 253 (class 1259 OID 9480353)
-- Name: report_executions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.report_executions (
    id text NOT NULL,
    "reportId" text NOT NULL,
    status text NOT NULL,
    format text NOT NULL,
    "fileUrl" text,
    parameters text,
    "rowCount" integer,
    "executionTime" integer,
    "errorMessage" text,
    "executedBy" text,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "completedAt" timestamp(3) without time zone
);


--
-- TOC entry 252 (class 1259 OID 9480343)
-- Name: report_schedules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.report_schedules (
    id text NOT NULL,
    "reportId" text NOT NULL,
    frequency text NOT NULL,
    "dayOfWeek" integer,
    "dayOfMonth" integer,
    "time" text NOT NULL,
    recipients text NOT NULL,
    format text DEFAULT 'PDF'::text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "lastSent" timestamp(3) without time zone,
    "nextScheduled" timestamp(3) without time zone,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 221 (class 1259 OID 9480015)
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_permissions (
    id text NOT NULL,
    "roleId" text NOT NULL,
    "permissionId" text NOT NULL,
    conditions text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 220 (class 1259 OID 9480004)
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "churchId" text,
    "isSystem" boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 226 (class 1259 OID 9480065)
-- Name: sermons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sermons (
    id text NOT NULL,
    title text NOT NULL,
    content text,
    outline text,
    scripture text,
    date timestamp(3) without time zone,
    speaker text,
    "churchId" text NOT NULL,
    "isPublic" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 259 (class 1259 OID 9480408)
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    id text NOT NULL,
    "sessionToken" text NOT NULL,
    "userId" text NOT NULL,
    expires timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 246 (class 1259 OID 9480284)
-- Name: social_media_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.social_media_accounts (
    id text NOT NULL,
    platform text NOT NULL,
    "accountId" text NOT NULL,
    username text,
    "displayName" text,
    "accessToken" text NOT NULL,
    "refreshToken" text,
    "tokenExpiresAt" timestamp(3) without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    "lastSync" timestamp(3) without time zone,
    "accountData" text,
    "churchId" text NOT NULL,
    "connectedBy" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 250 (class 1259 OID 9480322)
-- Name: social_media_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.social_media_metrics (
    id text NOT NULL,
    "accountId" text NOT NULL,
    "postId" text,
    "campaignId" text,
    platform text NOT NULL,
    "metricType" text NOT NULL,
    value double precision NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    "periodType" text DEFAULT 'DAILY'::text NOT NULL,
    metadata text,
    "churchId" text NOT NULL,
    "collectedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 247 (class 1259 OID 9480293)
-- Name: social_media_posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.social_media_posts (
    id text NOT NULL,
    title text,
    content text NOT NULL,
    "mediaUrls" text,
    platforms text NOT NULL,
    "accountIds" text NOT NULL,
    status text DEFAULT 'DRAFT'::text NOT NULL,
    "scheduledAt" timestamp(3) without time zone,
    "publishedAt" timestamp(3) without time zone,
    "postIds" text,
    engagement text,
    hashtags text,
    mentions text,
    "campaignId" text,
    "authorId" text NOT NULL,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 297 (class 1259 OID 9480815)
-- Name: spiritual_gifts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.spiritual_gifts (
    id text NOT NULL,
    name text NOT NULL,
    category text NOT NULL,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 280 (class 1259 OID 9480632)
-- Name: subscription_addons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscription_addons (
    id text NOT NULL,
    key text NOT NULL,
    name text NOT NULL,
    description text,
    "priceMonthly" text NOT NULL,
    "priceYearly" text,
    "billingType" text DEFAULT 'MONTHLY'::text NOT NULL,
    "pricePerUnit" text,
    unit text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 278 (class 1259 OID 9480610)
-- Name: subscription_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscription_plans (
    id text NOT NULL,
    name text NOT NULL,
    "displayName" text NOT NULL,
    description text,
    "priceMonthly" text NOT NULL,
    "priceYearly" text,
    "maxChurches" integer DEFAULT 1 NOT NULL,
    "maxMembers" integer DEFAULT 100 NOT NULL,
    "maxUsers" integer DEFAULT 5 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    features jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 283 (class 1259 OID 9480663)
-- Name: support_contact_info; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.support_contact_info (
    id text DEFAULT 'default'::text NOT NULL,
    "whatsappNumber" text DEFAULT '+57 300 KHESED (543733)'::text NOT NULL,
    "whatsappUrl" text DEFAULT 'https://wa.me/573003435733'::text NOT NULL,
    email text DEFAULT 'soporte@khesedtek.com'::text NOT NULL,
    schedule text DEFAULT 'Lun-Vie 8AM-8PM (Colombia)'::text NOT NULL,
    "companyName" text DEFAULT 'Khesed-tek Systems'::text NOT NULL,
    location text DEFAULT 'Bogotá, Colombia'::text NOT NULL,
    website text DEFAULT 'https://khesedtek.com'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 309 (class 1259 OID 9579036)
-- Name: tenant_credentials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenant_credentials (
    id text NOT NULL,
    "churchId" text NOT NULL,
    "loginEmail" text NOT NULL,
    "tempPassword" text,
    "isFirstLogin" boolean DEFAULT true NOT NULL,
    "sentAt" timestamp(3) without time zone,
    "lastSentAt" timestamp(3) without time zone,
    "createdBy" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 295 (class 1259 OID 9480795)
-- Name: testimony_forms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.testimony_forms (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    fields jsonb NOT NULL,
    style jsonb,
    "isActive" boolean DEFAULT true NOT NULL,
    "isPublic" boolean DEFAULT true NOT NULL,
    slug text NOT NULL,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 296 (class 1259 OID 9480805)
-- Name: testimony_qr_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.testimony_qr_codes (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "formId" text NOT NULL,
    code text NOT NULL,
    design jsonb,
    "isActive" boolean DEFAULT true NOT NULL,
    "scanCount" integer DEFAULT 0 NOT NULL,
    "lastScan" timestamp(3) without time zone,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 222 (class 1259 OID 9480023)
-- Name: user_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_permissions (
    id text NOT NULL,
    "userId" text NOT NULL,
    "permissionId" text NOT NULL,
    granted boolean DEFAULT true NOT NULL,
    conditions text,
    "expiresAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 223 (class 1259 OID 9480032)
-- Name: user_roles_advanced; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles_advanced (
    id text NOT NULL,
    "userId" text NOT NULL,
    "roleId" text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "expiresAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 268 (class 1259 OID 9480493)
-- Name: user_theme_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_theme_preferences (
    id text NOT NULL,
    "userId" text NOT NULL,
    "churchId" text,
    "themeName" text DEFAULT 'default'::text NOT NULL,
    "themeMode" text DEFAULT 'light'::text NOT NULL,
    "primaryColor" text,
    "secondaryColor" text,
    "accentColor" text,
    "destructiveColor" text,
    "backgroundColor" text,
    "foregroundColor" text,
    "cardColor" text,
    "cardForegroundColor" text,
    "borderColor" text,
    "mutedColor" text,
    "mutedForegroundColor" text,
    "fontFamily" text DEFAULT 'Inter'::text,
    "fontSize" text DEFAULT 'medium'::text,
    "borderRadius" text DEFAULT '0.5rem'::text,
    "compactMode" boolean DEFAULT false NOT NULL,
    "logoUrl" text,
    "faviconUrl" text,
    "brandName" text,
    "isActive" boolean DEFAULT true NOT NULL,
    "isPublic" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 224 (class 1259 OID 9480041)
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id text NOT NULL,
    name text,
    email text NOT NULL,
    "emailVerified" timestamp(3) without time zone,
    image text,
    password text,
    role public."UserRole" DEFAULT 'MIEMBRO'::public."UserRole" NOT NULL,
    "churchId" text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 260 (class 1259 OID 9480415)
-- Name: verification_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.verification_tokens (
    identifier text NOT NULL,
    token text NOT NULL,
    expires timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 231 (class 1259 OID 9480114)
-- Name: visitor_follow_ups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visitor_follow_ups (
    id text NOT NULL,
    "checkInId" text NOT NULL,
    "followUpType" text NOT NULL,
    status text DEFAULT 'PENDIENTE'::text NOT NULL,
    "scheduledAt" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    notes text,
    "assignedTo" text,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "automationRuleId" text,
    priority text DEFAULT 'MEDIUM'::text NOT NULL,
    category text,
    "touchSequence" integer,
    "responseReceived" boolean DEFAULT false NOT NULL,
    "responseData" jsonb,
    "nextActionDue" timestamp(3) without time zone,
    "ministryMatch" text
);


--
-- TOC entry 229 (class 1259 OID 9480092)
-- Name: volunteer_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.volunteer_assignments (
    id text NOT NULL,
    "volunteerId" text NOT NULL,
    "eventId" text,
    title text NOT NULL,
    description text,
    date timestamp(3) without time zone NOT NULL,
    "startTime" text NOT NULL,
    "endTime" text NOT NULL,
    status text DEFAULT 'ASIGNADO'::text NOT NULL,
    notes text,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 302 (class 1259 OID 9480866)
-- Name: volunteer_engagement_scores; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.volunteer_engagement_scores (
    id text NOT NULL,
    "volunteerId" text NOT NULL,
    "currentScore" double precision DEFAULT 0.0 NOT NULL,
    "participationRate" double precision DEFAULT 0.0 NOT NULL,
    "consistencyScore" double precision DEFAULT 0.0 NOT NULL,
    "feedbackScore" double precision DEFAULT 0.0 NOT NULL,
    "growthTrend" text DEFAULT 'STABLE'::text NOT NULL,
    "lastActivityDate" timestamp(3) without time zone,
    "burnoutRisk" text DEFAULT 'LOW'::text NOT NULL,
    "recommendedActions" jsonb,
    "calculatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 300 (class 1259 OID 9480845)
-- Name: volunteer_recommendations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.volunteer_recommendations (
    id text NOT NULL,
    "memberId" text NOT NULL,
    "ministryId" text NOT NULL,
    "eventId" text,
    "recommendationType" text NOT NULL,
    "matchScore" double precision NOT NULL,
    reasoning jsonb NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    priority text DEFAULT 'MEDIUM'::text NOT NULL,
    "validUntil" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 228 (class 1259 OID 9480083)
-- Name: volunteers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.volunteers (
    id text NOT NULL,
    "memberId" text,
    "firstName" text NOT NULL,
    "lastName" text NOT NULL,
    email text,
    phone text,
    skills text,
    availability text,
    "ministryId" text,
    "churchId" text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 263 (class 1259 OID 9480445)
-- Name: web_page_sections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.web_page_sections (
    id text NOT NULL,
    type text NOT NULL,
    content jsonb NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    "isVisible" boolean DEFAULT true NOT NULL,
    "pageId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 262 (class 1259 OID 9480434)
-- Name: web_pages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.web_pages (
    id text NOT NULL,
    title text NOT NULL,
    slug text NOT NULL,
    content jsonb NOT NULL,
    "metaTitle" text,
    "metaDescription" text,
    "metaImage" text,
    "isHomePage" boolean DEFAULT false NOT NULL,
    "isPublished" boolean DEFAULT false NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    "websiteId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 267 (class 1259 OID 9480482)
-- Name: website_analytics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.website_analytics (
    id text NOT NULL,
    "pageViews" integer DEFAULT 0 NOT NULL,
    "uniqueVisitors" integer DEFAULT 0 NOT NULL,
    "bounceRate" double precision,
    "avgSessionDuration" integer,
    referrer text,
    page text NOT NULL,
    date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "websiteId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 303 (class 1259 OID 9480881)
-- Name: website_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.website_requests (
    id text NOT NULL,
    "churchId" text NOT NULL,
    "requestType" text NOT NULL,
    "projectName" text NOT NULL,
    description text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    priority text DEFAULT 'medium'::text NOT NULL,
    "contactEmail" text NOT NULL,
    phone text,
    "estimatedPrice" integer,
    "finalPrice" integer,
    "estimatedCompletion" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    "adminNotes" text,
    metadata text,
    "existingWebsiteId" text,
    "resultingWebsiteId" text,
    "assignedTo" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 261 (class 1259 OID 9480420)
-- Name: websites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.websites (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    domain text,
    description text,
    theme text DEFAULT 'default'::text NOT NULL,
    "primaryColor" text DEFAULT '#3B82F6'::text NOT NULL,
    "secondaryColor" text DEFAULT '#64748B'::text NOT NULL,
    "accentColor" text,
    "fontFamily" text DEFAULT 'Inter'::text NOT NULL,
    "metaTitle" text,
    "metaDescription" text,
    "metaImage" text,
    metadata text,
    "isPublished" boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 4614 (class 0 OID 9480401)
-- Dependencies: 258
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.accounts (id, "userId", type, provider, "providerAccountId", refresh_token, access_token, expires_at, token_type, scope, id_token, session_state) FROM stdin;
\.


--
-- TOC entry 4613 (class 0 OID 9480393)
-- Dependencies: 257
-- Data for Name: analytics_cache; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.analytics_cache (id, "cacheKey", "dataType", data, parameters, "expiresAt", "churchId", "createdAt") FROM stdin;
\.


--
-- TOC entry 4610 (class 0 OID 9480361)
-- Dependencies: 254
-- Data for Name: analytics_dashboards; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.analytics_dashboards (id, name, description, layout, "isDefault", "isPublic", "userRole", "createdBy", "churchId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4629 (class 0 OID 9480559)
-- Dependencies: 273
-- Data for Name: automation_actions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.automation_actions (id, "ruleId", type, configuration, "orderIndex", delay, "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4628 (class 0 OID 9480548)
-- Dependencies: 272
-- Data for Name: automation_conditions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.automation_conditions (id, "ruleId", type, field, operator, value, "logicalOperator", "groupId", "orderIndex", "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4601 (class 0 OID 9480275)
-- Dependencies: 245
-- Data for Name: automation_executions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.automation_executions (id, "automationId", "triggerData", status, results, "executedAt", "completedAt", "churchId") FROM stdin;
\.


--
-- TOC entry 4630 (class 0 OID 9480571)
-- Dependencies: 274
-- Data for Name: automation_rule_executions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.automation_rule_executions (id, "ruleId", "triggerData", status, result, error, "executedAt", duration, "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4626 (class 0 OID 9480526)
-- Dependencies: 270
-- Data for Name: automation_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.automation_rules (id, name, description, "churchId", "createdBy", "isActive", priority, "executeOnce", "maxExecutions", "executionCount", "lastExecuted", metadata, "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4631 (class 0 OID 9480580)
-- Dependencies: 275
-- Data for Name: automation_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.automation_templates (id, name, description, category, template, "isSystem", "isActive", "usageCount", "createdBy", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4627 (class 0 OID 9480538)
-- Dependencies: 271
-- Data for Name: automation_triggers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.automation_triggers (id, "ruleId", type, "eventSource", configuration, "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4600 (class 0 OID 9480266)
-- Dependencies: 244
-- Data for Name: automations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.automations (id, name, description, trigger, actions, conditions, "isActive", "churchId", "createdAt", "updatedAt") FROM stdin;
cmeytjgs40033q8fcz52ixubv	Recordatorio de Eventos	Enviar recordatorio SMS 24 horas antes de eventos	EVENT_REMINDER	[{"type":"SEND_SMS","templateId":"cmeytjgrr0026q8fcwb5daw5e","targetGroup":"TODOS"}]	{"eventType":"público","reminderTime":"24_hours"}	t	demo-church	2025-08-30 22:13:49.876	2025-08-30 22:13:49.876
cmeytjgs40035q8fcgq1elwm3	Seguimiento Donaciones	Enviar agradecimiento por donaciones importantes	LARGE_DONATION	[{"type":"SEND_EMAIL","templateId":"cmeytjgrr002bq8fc6h31bllf","personalMessage":"Gracias por tu generosa donación"},{"type":"NOTIFY_PASTOR","message":"Donación importante recibida"}]	{"minimumAmount":500000}	f	demo-church	2025-08-30 22:13:49.877	2025-08-30 22:13:49.877
cmeytjgs40031q8fclu2q5hyy	Bienvenida Automática Visitantes	Enviar email de bienvenida a nuevos visitantes	NEW_VISITOR	[{"type":"SEND_EMAIL","templateId":"cmeytjgrr0029q8fcu3owv2b1","delay":1440},{"type":"SCHEDULE_FOLLOWUP","followUpType":"LLAMADA","delay":4320}]	{"isFirstTime":true}	t	demo-church	2025-08-30 22:13:49.876	2025-08-30 22:13:49.876
cmf76ch5p0032ugjfwzsjufmq	Bienvenida Automática Visitantes	Enviar email de bienvenida a nuevos visitantes	NEW_VISITOR	[{"type":"SEND_EMAIL","templateId":"cmf76ch55002augjfue5fpqa9","delay":1440},{"type":"SCHEDULE_FOLLOWUP","followUpType":"LLAMADA","delay":4320}]	{"isFirstTime":true}	t	demo-church	2025-09-05 18:34:28.19	2025-09-05 18:34:28.19
cmf76ch5p0034ugjffhtugm4g	Recordatorio de Eventos	Enviar recordatorio SMS 24 horas antes de eventos	EVENT_REMINDER	[{"type":"SEND_SMS","templateId":"cmf76ch550027ugjf8w2fehlp","targetGroup":"TODOS"}]	{"eventType":"público","reminderTime":"24_hours"}	t	demo-church	2025-09-05 18:34:28.19	2025-09-05 18:34:28.19
cmf76ch5p0035ugjfzor5kqtc	Seguimiento Donaciones	Enviar agradecimiento por donaciones importantes	LARGE_DONATION	[{"type":"SEND_EMAIL","templateId":"cmf76ch55002bugjf3l44xlc8","personalMessage":"Gracias por tu generosa donación"},{"type":"NOTIFY_PASTOR","message":"Donación importante recibida"}]	{"minimumAmount":500000}	f	demo-church	2025-09-05 18:34:28.19	2025-09-05 18:34:28.19
\.


--
-- TOC entry 4655 (class 0 OID 9480834)
-- Dependencies: 299
-- Data for Name: availability_matrices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.availability_matrices (id, "memberId", "recurringAvailability", "blackoutDates", "preferredMinistries", "maxCommitmentsPerMonth", "preferredTimeSlots", "travelWillingness", "lastUpdated", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4586 (class 0 OID 9480101)
-- Dependencies: 230
-- Data for Name: check_ins; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.check_ins (id, "firstName", "lastName", email, phone, "isFirstTime", "visitReason", "prayerRequest", "qrCode", "eventId", "churchId", "checkedInAt", "createdAt", "visitorType", "ministryInterest", "ageGroup", "familyStatus", "referredBy", "followUpFormId", "automationTriggered", "lastContactDate", "engagementScore") FROM stdin;
cmeytjgq6001bq8fc8m84k534	Elena	Vargas	elena@email.com	+1234567895	t	Búsqueda espiritual	Paz familiar	QR-VISITOR-1756592029806-002	\N	demo-church	2025-08-30 20:13:49.806	2025-08-30 22:13:49.806	\N	{}	\N	\N	\N	\N	f	\N	0
cmeytjgq6001aq8fcolds131w	Manuel	Rodríguez	manuel@email.com	+1234567894	t	Invitado por un amigo	Oración por trabajo	QR-VISITOR-1756592029806-001	\N	demo-church	2025-08-30 22:13:49.806	2025-08-30 22:13:49.806	\N	{}	\N	\N	\N	\N	f	\N	0
cmeytjgq6001dq8fcs73xw35w	Roberto	Silva	\N	+1234567896	f	Miembro visitante de otra ciudad	\N	QR-VISITOR-1756592029806-003	\N	demo-church	2025-08-30 21:43:49.806	2025-08-30 22:13:49.806	\N	{}	\N	\N	\N	\N	f	\N	0
cmf76ch3c001bugjf1jhx3mik	Manuel	Rodríguez	manuel@email.com	+1234567894	t	Invitado por un amigo	Oración por trabajo	QR-VISITOR-1757097268103-001	\N	demo-church	2025-09-05 18:34:28.103	2025-09-05 18:34:28.104	\N	{}	\N	\N	\N	\N	f	\N	0
cmf76ch3c001dugjfhw5tlg1j	Roberto	Silva	\N	+1234567896	f	Miembro visitante de otra ciudad	\N	QR-VISITOR-1757097268104-003	\N	demo-church	2025-09-05 18:04:28.104	2025-09-05 18:34:28.104	\N	{}	\N	\N	\N	\N	f	\N	0
cmf76ch3c001cugjful753i6y	Elena	Vargas	elena@email.com	+1234567895	t	Búsqueda espiritual	Paz familiar	QR-VISITOR-1757097268104-002	\N	demo-church	2025-09-05 16:34:28.104	2025-09-05 18:34:28.104	\N	{}	\N	\N	\N	\N	f	\N	0
cmfcreugh0001lr01q6sgpju4	Nelson	Castro	nc@hexonasystemsamericas.com	+578132793191	t	queria visitar	dar gracias	1757434981529-ta7kg3ice	\N	demo-church	2025-09-09 16:23:01.53	2025-09-09 16:23:01.53	\N	{}	\N	\N	\N	\N	f	\N	0
cmfcrffyu0007lr01dmkxkr9e	Nelson	Castro	nc@hexonasystemsamericas.com	+578132793191	t	queria visitar	dar gracias	1757435009428-s41zrs7cy	\N	demo-church	2025-09-09 16:23:29.429	2025-09-09 16:23:29.429	\N	{}	\N	\N	\N	\N	f	\N	0
cmfcrfngi000dlr01gk0d1c2r	Nelson	Castro	nc@hexonasystemsamericas.com	+578132793191	t	queria visitar	dar gracias	1757435019138-wtsa1qqje	\N	demo-church	2025-09-09 16:23:39.139	2025-09-09 16:23:39.139	\N	{}	\N	\N	\N	\N	f	\N	0
cmfe3dxcb0001lb01tichkdfr	Nelson	Castro	nc@hexonasystemsamericas.com	8132793191	t		adawfefaefwcatw4r	1757515560201-pej8lb7bk	\N	demo-church	2025-09-10 14:46:00.202	2025-09-10 14:46:00.202	\N	{}	\N	\N	\N	\N	f	\N	0
\.


--
-- TOC entry 4588 (class 0 OID 9480125)
-- Dependencies: 232
-- Data for Name: children_check_ins; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.children_check_ins (id, "childName", "childAge", "parentName", "parentPhone", "parentEmail", "emergencyContact", "emergencyPhone", allergies, "specialNeeds", "qrCode", "checkedIn", "checkedInAt", "checkedOut", "checkedOutAt", "checkedOutBy", "eventId", "churchId", "createdAt", "updatedAt", "childPhotoUrl", "parentPhotoUrl", "securityPin", "biometricHash", "photoTakenAt", "backupAuthCodes", "pickupAttempts", "requiresBothAuth") FROM stdin;
cmeytjgqq001pq8fcr8ob6z7e	Diego Morales	5	Patricia Morales	+1234567899	patricia@email.com	José Morales (Padre)	+1234567900	\N	Necesita recordatorio para usar el baño	QR-CHILD-1756592029826-002	t	2025-08-30 22:13:49.827	t	2025-08-30 21:13:49.826	cmeytjgnx0001q8fctjc12b43	\N	demo-church	2025-08-30 22:13:49.827	2025-08-30 22:13:49.827	\N	\N	000000	\N	\N	{}	{}	t
cmf76ch40001qugjf2rqkd88y	Diego Morales	5	Patricia Morales	+1234567899	patricia@email.com	José Morales (Padre)	+1234567900	\N	Necesita recordatorio para usar el baño	QR-CHILD-1757097268128-002	t	2025-09-05 18:34:28.129	t	2025-09-05 17:34:28.128	cmeytjgnx0001q8fctjc12b43	\N	demo-church	2025-09-05 18:34:28.129	2025-09-05 18:34:28.129	\N	\N	000000	\N	\N	{}	{}	t
cmf76ch40001rugjfynoon4oq	Isabella Cruz	9	Miguel Cruz	+1234567901	miguel@email.com	\N	\N	\N	\N	QR-CHILD-1757097268128-003	t	2025-09-05 18:34:28.129	t	2025-09-10 14:51:54.517	cmeytjgnx0001q8fctjc12b43	\N	demo-church	2025-09-05 18:34:28.129	2025-09-10 14:51:54.518	\N	\N	000000	\N	\N	{}	{}	t
cmf76ch40001pugjf012hwxs9	Sofía Ramírez	7	Carmen Ramírez	+1234567897	carmen@email.com	Luis Ramírez (Tío)	+1234567898	Alérgica a los frutos secos	\N	QR-CHILD-1757097268128-001	t	2025-09-05 18:34:28.129	t	2025-09-10 14:51:59.263	cmeytjgnx0001q8fctjc12b43	cmf76ch2a000zugjfkkjhyq7c	demo-church	2025-09-05 18:34:28.129	2025-09-10 14:51:59.264	\N	\N	000000	\N	\N	{}	{}	t
cmeytjgqq001qq8fc74yh3ooo	Sofía Ramírez	7	Carmen Ramírez	+1234567897	carmen@email.com	Luis Ramírez (Tío)	+1234567898	Alérgica a los frutos secos	\N	QR-CHILD-1756592029826-001	t	2025-08-30 22:13:49.827	t	2025-09-10 14:52:03.701	cmeytjgnx0001q8fctjc12b43	cmeytjgpc000zq8fc1o1bpb12	demo-church	2025-08-30 22:13:49.827	2025-09-10 14:52:03.701	\N	\N	000000	\N	\N	{}	{}	t
cmeytjgqr001rq8fcid46oewj	Isabella Cruz	9	Miguel Cruz	+1234567901	miguel@email.com	\N	\N	\N	\N	QR-CHILD-1756592029826-003	t	2025-08-30 22:13:49.827	t	2025-09-10 14:52:06.889	cmeytjgnx0001q8fctjc12b43	\N	demo-church	2025-08-30 22:13:49.827	2025-09-10 14:52:06.89	\N	\N	000000	\N	\N	{}	{}	t
\.


--
-- TOC entry 4666 (class 0 OID 9671074)
-- Dependencies: 310
-- Data for Name: church_qualification_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.church_qualification_settings (id, "churchId", "volunteerMinMembershipDays", "volunteerRequireActiveStatus", "volunteerRequireSpiritualAssessment", "volunteerMinSpiritualScore", "leadershipMinMembershipDays", "leadershipRequireVolunteerExp", "leadershipMinVolunteerDays", "leadershipRequireTraining", "leadershipMinSpiritualScore", "leadershipMinLeadershipScore", "enableSpiritualMaturityScoring", "enableLeadershipAptitudeScoring", "enableMinistryPassionMatching", "spiritualGiftsWeight", "availabilityWeight", "experienceWeight", "ministryPassionWeight", "activityWeight", "createdAt", "updatedAt") FROM stdin;
cmf342vka0008vv72l6re6pal	cmeyt1tkw0000q8xyyr97bp74	0	t	f	0	365	f	0	f	70	60	t	t	t	0.4	0.25	0.15	0.1	0.1	2025-09-02 22:19:56.362	2025-09-02 22:19:56.362
cmf3505850001k001qwn8amgv	demo-church	0	t	f	0	365	f	0	f	70	60	t	t	t	0.4	0.25	0.15	0.1	0.1	2025-09-02 22:45:48.533	2025-09-02 22:45:48.533
\.


--
-- TOC entry 4638 (class 0 OID 9480653)
-- Dependencies: 282
-- Data for Name: church_subscription_addons; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.church_subscription_addons (id, "subscriptionId", "addonId", quantity, "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4637 (class 0 OID 9480642)
-- Dependencies: 281
-- Data for Name: church_subscriptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.church_subscriptions (id, "churchId", "planId", "billingCycle", status, "currentPeriodStart", "currentPeriodEnd", "trialEnd", "cancelAtPeriodEnd", "cancelledAt", metadata, "createdAt", "updatedAt") FROM stdin;
cmez0uqjb0002q8e3al8szvt0	cmez0uqja0000q8e3wiqkv9jx	plan-basico	MONTHLY	TRIAL	2025-08-31 01:38:33.047	2025-10-01 01:38:33.047	2025-09-14 01:38:33.047	f	\N	{"signupDate": "2025-08-31T01:38:33.047Z", "selectedPlan": "BÁSICO"}	2025-08-31 01:38:33.048	2025-08-31 01:38:33.048
cmez0yne00009q8e3h09esj4z	cmez0yndy0007q8e3s9i3852m	plan-basico	MONTHLY	TRIAL	2025-08-31 01:41:35.592	2025-10-01 01:41:35.592	2025-09-14 01:41:35.592	f	\N	{"signupDate": "2025-08-31T01:41:35.592Z", "selectedPlan": "BÁSICO"}	2025-08-31 01:41:35.592	2025-08-31 01:41:35.592
cmez0ysow000gq8e3ahw3cj07	cmez0ysov000eq8e399j8ucvk	plan-basico	MONTHLY	TRIAL	2025-08-31 01:41:42.463	2025-10-01 01:41:42.463	2025-09-14 01:41:42.463	f	\N	{"signupDate": "2025-08-31T01:41:42.463Z", "selectedPlan": "BÁSICO"}	2025-08-31 01:41:42.464	2025-08-31 01:41:42.464
cmez0yxq7000nq8e3azyoilmu	cmez0yxq6000lq8e3x5yi4otw	plan-basico	MONTHLY	TRIAL	2025-08-31 01:41:48.99	2025-10-01 01:41:48.99	2025-09-14 01:41:48.99	f	\N	{"signupDate": "2025-08-31T01:41:48.991Z", "selectedPlan": "BÁSICO"}	2025-08-31 01:41:48.991	2025-08-31 01:41:48.991
cmez2v2yx0002q8gi7otxmu0h	cmez2v2yv0000q8gib6m58u6b	plan-basico	MONTHLY	TRIAL	2025-08-31 02:34:48.392	2025-10-01 02:34:48.392	2025-09-14 02:34:48.392	f	\N	{"signupDate": "2025-08-31T02:34:48.392Z", "selectedPlan": "BÁSICO"}	2025-08-31 02:34:48.393	2025-08-31 02:34:48.393
cmez30ezg0002q86nzi26ekts	cmez30eze0000q86ntsvyk2iz	plan-basico	MONTHLY	TRIAL	2025-08-31 02:38:57.244	2025-10-01 02:38:57.244	2025-09-14 02:38:57.244	f	\N	{"signupDate": "2025-08-31T02:38:57.244Z", "selectedPlan": "BÁSICO"}	2025-08-31 02:38:57.245	2025-08-31 02:38:57.245
cmez33zds0009q86nau1pwh5q	cmez33zdr0007q86nr4tvl5ib	plan-profesional	MONTHLY	TRIAL	2025-08-31 02:41:43.648	2025-10-01 02:41:43.648	2025-09-14 02:41:43.648	f	\N	{"signupDate": "2025-08-31T02:41:43.648Z", "selectedPlan": "PROFESIONAL"}	2025-08-31 02:41:43.649	2025-08-31 02:41:43.649
cmez3tbem0002q8qstqmipqa3	cmez3tbek0000q8qsrgyoaknu	plan-basico	MONTHLY	TRIAL	2025-08-31 03:01:25.63	2025-10-01 03:01:25.63	2025-09-14 03:01:25.63	f	\N	{"signupDate": "2025-08-31T03:01:25.630Z", "selectedPlan": "BÁSICO"}	2025-08-31 03:01:25.631	2025-08-31 03:01:25.631
cmf1c9n6y0002s8wff4bnezm1	cmf1c9n6w0000s8wf57x68925	plan-basico	MONTHLY	TRIAL	2025-09-01 16:33:36.681	2025-10-01 16:33:36.681	2025-09-15 16:33:36.681	f	\N	{"signupDate": "2025-09-01T16:33:36.681Z", "selectedPlan": "BÁSICO"}	2025-09-01 16:33:36.682	2025-09-01 16:33:36.682
cmf1cyh4v0002s8vh85pb2i62	cmf1cyh4t0000s8vh9p0cerql	plan-basico	MONTHLY	TRIAL	2025-09-01 16:52:55.23	2025-10-01 16:52:55.23	2025-09-15 16:52:55.23	f	\N	{"signupDate": "2025-09-01T16:52:55.230Z", "selectedPlan": "BÁSICO"}	2025-09-01 16:52:55.231	2025-09-01 16:52:55.231
cmf1euc2i0002s8e8tdz1xs07	cmf1euc2f0000s8e8xk8pw7d9	plan-basico	MONTHLY	TRIAL	2025-09-01 17:45:41.273	2025-10-01 17:45:41.273	2025-09-15 17:45:41.273	f	\N	{"signupDate": "2025-09-01T17:45:41.273Z", "selectedPlan": "BÁSICO"}	2025-09-01 17:45:41.274	2025-09-01 17:45:41.274
cmf1flwvi0002s84ogh5omzx8	cmf1flwvf0000s84oop1aeh96	plan-basico	MONTHLY	TRIAL	2025-09-01 18:07:07.949	2025-10-01 18:07:07.949	2025-09-15 18:07:07.949	f	\N	{"signupDate": "2025-09-01T18:07:07.950Z", "selectedPlan": "BÁSICO"}	2025-09-01 18:07:07.95	2025-09-01 18:07:07.95
cmf1gcbtj0002s8mp0ezzcred	cmf1gcbtg0000s8mpc4skc5rg	plan-basico	MONTHLY	TRIAL	2025-09-01 18:27:40.374	2025-10-01 18:27:40.374	2025-09-15 18:27:40.374	f	\N	{"signupDate": "2025-09-01T18:27:40.374Z", "selectedPlan": "BÁSICO"}	2025-09-01 18:27:40.375	2025-09-01 18:27:40.375
cmf1jo2tf0002p2nvrrtugkas	cmf1jo2tc0000p2nv3nbzeape	plan-basico	MONTHLY	TRIAL	2025-09-01 20:00:47.427	2025-10-01 20:00:47.427	2025-09-15 20:00:47.427	f	\N	{"signupDate": "2025-09-01T20:00:47.427Z", "selectedPlan": "BÁSICO"}	2025-09-01 20:00:47.428	2025-09-01 20:00:47.428
cmf1kqq830002p2gqdb6vbfaz	cmf1kqq810000p2gq6eacddjl	plan-basico	MONTHLY	TRIAL	2025-09-01 20:30:50.69	2025-10-01 20:30:50.69	2025-09-15 20:30:50.69	f	\N	{"signupDate": "2025-09-01T20:30:50.690Z", "selectedPlan": "BÁSICO"}	2025-09-01 20:30:50.691	2025-09-01 20:30:50.691
cmf1mfqc80002m2q150odsgwn	cmf1mfqc60000m2q1k2g3md5b	plan-basico	MONTHLY	TRIAL	2025-09-01 21:18:16.856	2025-10-01 21:18:16.856	2025-09-15 21:18:16.856	f	\N	{"signupDate": "2025-09-01T21:18:16.856Z", "selectedPlan": "BÁSICO"}	2025-09-01 21:18:16.857	2025-09-01 21:18:16.857
cmf1nzgzp0002m2latob0sqdm	cmf1nzgzm0000m2ladrdl8007	plan-basico	MONTHLY	TRIAL	2025-09-01 22:01:37.476	2025-10-01 22:01:37.476	2025-09-15 22:01:37.476	f	\N	{"signupDate": "2025-09-01T22:01:37.477Z", "selectedPlan": "BÁSICO"}	2025-09-01 22:01:37.478	2025-09-01 22:01:37.478
cmf1ojke90002m20ovk18rkz7	cmf1ojke60000m20o274v44ch	plan-basico	MONTHLY	TRIAL	2025-09-01 22:17:15.009	2025-10-01 22:17:15.009	2025-09-15 22:17:15.009	f	\N	{"signupDate": "2025-09-01T22:17:15.009Z", "selectedPlan": "BÁSICO"}	2025-09-01 22:17:15.01	2025-09-01 22:17:15.01
cmf1p8blq0002m2qglw8prc3x	cmf1p8blo0000m2qg06rvrow4	plan-basico	MONTHLY	TRIAL	2025-09-01 22:36:30.013	2025-10-01 22:36:30.013	2025-09-15 22:36:30.013	f	\N	{"signupDate": "2025-09-01T22:36:30.014Z", "selectedPlan": "BÁSICO"}	2025-09-01 22:36:30.014	2025-09-01 22:36:30.014
cmf1q0nn10002m2g91cysr0vm	cmf1q0nmy0000m2g97d1xzdx1	plan-basico	MONTHLY	TRIAL	2025-09-01 22:58:31.981	2025-10-01 22:58:31.981	2025-09-15 22:58:31.981	f	\N	{"signupDate": "2025-09-01T22:58:31.981Z", "selectedPlan": "BÁSICO"}	2025-09-01 22:58:31.982	2025-09-01 22:58:31.982
cmf1qpumi0002m2zusdxa0nld	cmf1qpumf0000m2zuk31kulwc	plan-basico	MONTHLY	TRIAL	2025-09-01 23:18:07.433	2025-10-01 23:18:07.433	2025-09-15 23:18:07.433	f	\N	{"signupDate": "2025-09-01T23:18:07.433Z", "selectedPlan": "BÁSICO"}	2025-09-01 23:18:07.434	2025-09-01 23:18:07.434
cmf1ri0vl0002m2j6pcru9h21	cmf1ri0vj0000m2j6ic7bjkmi	plan-basico	MONTHLY	TRIAL	2025-09-01 23:40:01.905	2025-10-01 23:40:01.905	2025-09-15 23:40:01.905	f	\N	{"signupDate": "2025-09-01T23:40:01.905Z", "selectedPlan": "BÁSICO"}	2025-09-01 23:40:01.906	2025-09-01 23:40:01.906
cmf1s66fh0002of01lb5oikqf	cmf1s66fe0000of019relorwd	plan-basico	MONTHLY	TRIAL	2025-09-01 23:58:48.845	2025-10-01 23:58:48.845	2025-09-15 23:58:48.845	f	\N	{"signupDate": "2025-09-01T23:58:48.845Z", "selectedPlan": "BÁSICO"}	2025-09-01 23:58:48.846	2025-09-01 23:58:48.846
cmf2lzzdy0002q7z8u3ncpujy	cmf2lzzdq0000q7z8kkfwdmol	plan-basico	MONTHLY	TRIAL	2025-09-02 13:53:48.261	2025-10-02 13:53:48.261	2025-09-16 13:53:48.261	f	\N	{"signupDate": "2025-09-02T13:53:48.261Z", "selectedPlan": "BÁSICO"}	2025-09-02 13:53:48.262	2025-09-02 13:53:48.262
cmf2nf3dh0002q7qzm3mk73ad	cmf2nf3dd0000q7qzpg7bbuwz	plan-basico	MONTHLY	TRIAL	2025-09-02 14:33:32.884	2025-10-02 14:33:32.884	2025-09-16 14:33:32.884	f	\N	{"signupDate": "2025-09-02T14:33:32.885Z", "selectedPlan": "BÁSICO"}	2025-09-02 14:33:32.885	2025-09-02 14:33:32.885
cmf2o64se0002q7hm7454gb5z	cmf2o64sb0000q7hmquald4hd	plan-basico	MONTHLY	TRIAL	2025-09-02 14:54:34.429	2025-10-02 14:54:34.429	2025-09-16 14:54:34.429	f	\N	{"signupDate": "2025-09-02T14:54:34.429Z", "selectedPlan": "BÁSICO"}	2025-09-02 14:54:34.43	2025-09-02 14:54:34.43
cmf2owxbt0002q74hvi3jkz7w	cmf2owxbq0000q74hhyfjnsy0	plan-basico	MONTHLY	TRIAL	2025-09-02 15:15:24.472	2025-10-02 15:15:24.472	2025-09-16 15:15:24.472	f	\N	{"signupDate": "2025-09-02T15:15:24.472Z", "selectedPlan": "BÁSICO"}	2025-09-02 15:15:24.473	2025-09-02 15:15:24.473
cmf2px4jf0002q7ppa04erdq4	cmf2px4jc0000q7pph68odq7g	plan-basico	MONTHLY	TRIAL	2025-09-02 15:43:33.435	2025-10-02 15:43:33.435	2025-09-16 15:43:33.435	f	\N	{"signupDate": "2025-09-02T15:43:33.435Z", "selectedPlan": "BÁSICO"}	2025-09-02 15:43:33.436	2025-09-02 15:43:33.436
cmf2rb4rx0002q776xuhdsx7r	cmf2rb4ru0000q7763rck0uwj	plan-basico	MONTHLY	TRIAL	2025-09-02 16:22:26.54	2025-10-02 16:22:26.54	2025-09-16 16:22:26.54	f	\N	{"signupDate": "2025-09-02T16:22:26.540Z", "selectedPlan": "BÁSICO"}	2025-09-02 16:22:26.541	2025-09-02 16:22:26.541
cmf2tg72y0002ntovkin8dw6g	cmf2tg72q0000ntovxmk4l8ti	plan-basico	MONTHLY	TRIAL	2025-09-02 17:22:22.042	2025-10-02 17:22:22.042	2025-09-16 17:22:22.042	f	\N	{"signupDate": "2025-09-02T17:22:22.042Z", "selectedPlan": "BÁSICO"}	2025-09-02 17:22:22.043	2025-09-02 17:22:22.043
cmf2uaqxp0002ntbf6egqxcc7	cmf2uaqxn0000ntbfywax1quq	plan-basico	MONTHLY	TRIAL	2025-09-02 17:46:07.452	2025-10-02 17:46:07.452	2025-09-16 17:46:07.452	f	\N	{"signupDate": "2025-09-02T17:46:07.452Z", "selectedPlan": "BÁSICO"}	2025-09-02 17:46:07.453	2025-09-02 17:46:07.453
cmf2vfy8n0002nt4g8tgnm2xo	cmf2vfy8l0000nt4gc5gz994q	plan-basico	MONTHLY	TRIAL	2025-09-02 18:18:09.815	2025-10-02 18:18:09.815	2025-09-16 18:18:09.815	f	\N	{"signupDate": "2025-09-02T18:18:09.815Z", "selectedPlan": "BÁSICO"}	2025-09-02 18:18:09.816	2025-09-02 18:18:09.816
cmf2wun9z0002nt0oo21uwc9p	cmf2wun9w0000nt0oswz1q6px	plan-basico	MONTHLY	TRIAL	2025-09-02 18:57:35.063	2025-10-02 18:57:35.063	2025-09-16 18:57:35.063	f	\N	{"signupDate": "2025-09-02T18:57:35.063Z", "selectedPlan": "BÁSICO"}	2025-09-02 18:57:35.064	2025-09-02 18:57:35.064
cmf30f6pm0002vvon6yz5sjzl	cmf30f6pg0000vvoni6r15qoh	plan-basico	MONTHLY	TRIAL	2025-09-02 20:37:32.217	2025-10-02 20:37:32.217	2025-09-16 20:37:32.217	f	\N	{"signupDate": "2025-09-02T20:37:32.217Z", "selectedPlan": "BÁSICO"}	2025-09-02 20:37:32.218	2025-09-02 20:37:32.218
cmf318t6h0002vv7wjfzadfkv	cmf318t6f0000vv7w2f1muqzg	plan-basico	MONTHLY	TRIAL	2025-09-02 21:00:34.361	2025-10-02 21:00:34.361	2025-09-16 21:00:34.361	f	\N	{"signupDate": "2025-09-02T21:00:34.361Z", "selectedPlan": "BÁSICO"}	2025-09-02 21:00:34.362	2025-09-02 21:00:34.362
cmf32jnwr0002vv3jitylkf97	cmf32jnwo0000vv3jilchdgw8	plan-basico	MONTHLY	TRIAL	2025-09-02 21:37:00.363	2025-10-02 21:37:00.363	2025-09-16 21:37:00.363	f	\N	{"signupDate": "2025-09-02T21:37:00.363Z", "selectedPlan": "BÁSICO"}	2025-09-02 21:37:00.364	2025-09-02 21:37:00.364
cmf341qg70002vv72yumn29fr	cmf341qg40000vv723fg9he77	plan-basico	MONTHLY	TRIAL	2025-09-02 22:19:03.079	2025-10-02 22:19:03.079	2025-09-16 22:19:03.079	f	\N	{"signupDate": "2025-09-02T22:19:03.079Z", "selectedPlan": "BÁSICO"}	2025-09-02 22:19:03.08	2025-09-02 22:19:03.08
cmf34o6tf0002vvrnnbffhx2k	cmf34o6td0000vvrndejb7y2p	plan-basico	MONTHLY	TRIAL	2025-09-02 22:36:30.723	2025-10-02 22:36:30.723	2025-09-16 22:36:30.723	f	\N	{"signupDate": "2025-09-02T22:36:30.723Z", "selectedPlan": "BÁSICO"}	2025-09-02 22:36:30.724	2025-09-02 22:36:30.724
cmf35jn750002vvubro0saq3b	cmf35jn730000vvubhnnw4oxz	plan-basico	MONTHLY	TRIAL	2025-09-02 23:00:58.288	2025-10-02 23:00:58.288	2025-09-16 23:00:58.288	f	\N	{"signupDate": "2025-09-02T23:00:58.288Z", "selectedPlan": "BÁSICO"}	2025-09-02 23:00:58.289	2025-09-02 23:00:58.289
cmf35rkjm0002vvjtltu38kou	cmf35rkjj0000vvjt4pwsy0dz	plan-basico	MONTHLY	TRIAL	2025-09-02 23:07:08.097	2025-10-02 23:07:08.097	2025-09-16 23:07:08.097	f	\N	{"signupDate": "2025-09-02T23:07:08.097Z", "selectedPlan": "BÁSICO"}	2025-09-02 23:07:08.098	2025-09-02 23:07:08.098
cmf36kgaj0002vv92l6oac396	cmf36kgah0000vv92dg716icf	plan-basico	MONTHLY	TRIAL	2025-09-02 23:29:35.611	2025-10-02 23:29:35.611	2025-09-16 23:29:35.611	f	\N	{"signupDate": "2025-09-02T23:29:35.611Z", "selectedPlan": "BÁSICO"}	2025-09-02 23:29:35.612	2025-09-02 23:29:35.612
cmf474kom0002uqzvgwk53i2o	cmf474koj0000uqzvlrfoxqtm	plan-basico	MONTHLY	TRIAL	2025-09-03 16:33:00.597	2025-10-03 16:33:00.597	2025-09-17 16:33:00.597	f	\N	{"signupDate": "2025-09-03T16:33:00.598Z", "selectedPlan": "BÁSICO"}	2025-09-03 16:33:00.598	2025-09-03 16:33:00.598
cmf47wdk80002uqos87a66qu6	cmf47wdk60000uqos0lkwharm	plan-basico	MONTHLY	TRIAL	2025-09-03 16:54:37.736	2025-10-03 16:54:37.736	2025-09-17 16:54:37.736	f	\N	{"signupDate": "2025-09-03T16:54:37.736Z", "selectedPlan": "BÁSICO"}	2025-09-03 16:54:37.737	2025-09-03 16:54:37.737
cmf48k9670002uq91bdfqkpt2	cmf48k9650000uq91bnx3l1ma	plan-basico	MONTHLY	TRIAL	2025-09-03 17:13:11.79	2025-10-03 17:13:11.79	2025-09-17 17:13:11.79	f	\N	{"signupDate": "2025-09-03T17:13:11.790Z", "selectedPlan": "BÁSICO"}	2025-09-03 17:13:11.791	2025-09-03 17:13:11.791
cmf49g0v70002uqpi9utxfl1r	cmf49g0v50000uqpiv19hw43t	plan-basico	MONTHLY	TRIAL	2025-09-03 17:37:54.018	2025-10-03 17:37:54.018	2025-09-17 17:37:54.018	f	\N	{"signupDate": "2025-09-03T17:37:54.018Z", "selectedPlan": "BÁSICO"}	2025-09-03 17:37:54.019	2025-09-03 17:37:54.019
cmf4a1dqu0002uq9n5cjcvw4y	cmf4a1dqs0000uq9npv695x49	plan-basico	MONTHLY	TRIAL	2025-09-03 17:54:30.486	2025-10-03 17:54:30.486	2025-09-17 17:54:30.486	f	\N	{"signupDate": "2025-09-03T17:54:30.486Z", "selectedPlan": "BÁSICO"}	2025-09-03 17:54:30.486	2025-09-03 17:54:30.486
cmf4an4pv0002uqr2526y5h1s	cmf4an4pq0000uqr2r3vrslq2	plan-basico	MONTHLY	TRIAL	2025-09-03 18:11:25.217	2025-10-03 18:11:25.217	2025-09-17 18:11:25.217	f	\N	{"signupDate": "2025-09-03T18:11:25.217Z", "selectedPlan": "BÁSICO"}	2025-09-03 18:11:25.219	2025-09-03 18:11:25.219
cmf4beful0002uqbl5khrsq6y	cmf4befuj0000uqblsubhki3k	plan-basico	MONTHLY	TRIAL	2025-09-03 18:32:39.357	2025-10-03 18:32:39.357	2025-09-17 18:32:39.357	f	\N	{"signupDate": "2025-09-03T18:32:39.357Z", "selectedPlan": "BÁSICO"}	2025-09-03 18:32:39.358	2025-09-03 18:32:39.358
cmf5jm5hp0002s7msrxjod8d8	cmf5jm5hl0000s7mstbgeeqmq	plan-basico	MONTHLY	TRIAL	2025-09-04 15:10:22.284	2025-10-04 15:10:22.284	2025-09-18 15:10:22.284	f	\N	{"signupDate": "2025-09-04T15:10:22.285Z", "selectedPlan": "BÁSICO"}	2025-09-04 15:10:22.286	2025-09-04 15:10:22.286
cmf5jyxsz0002s7nlmbgdtro3	cmf5jyxsw0000s7nlvukvas4x	plan-basico	MONTHLY	TRIAL	2025-09-04 15:20:18.85	2025-10-04 15:20:18.85	2025-09-18 15:20:18.85	f	\N	{"signupDate": "2025-09-04T15:20:18.850Z", "selectedPlan": "BÁSICO"}	2025-09-04 15:20:18.851	2025-09-04 15:20:18.851
cmf5lu99u0002s7m6hzff5w0n	cmf5lu99r0000s7m69navda79	plan-basico	MONTHLY	TRIAL	2025-09-04 16:12:39.665	2025-10-04 16:12:39.665	2025-09-18 16:12:39.665	f	\N	{"signupDate": "2025-09-04T16:12:39.665Z", "selectedPlan": "BÁSICO"}	2025-09-04 16:12:39.666	2025-09-04 16:12:39.666
cmf5mgtf40002s71yjm4gpcz5	cmf5mgtf20000s71ymce0bf3w	plan-basico	MONTHLY	TRIAL	2025-09-04 16:30:12.208	2025-10-04 16:30:12.208	2025-09-18 16:30:12.208	f	\N	{"signupDate": "2025-09-04T16:30:12.208Z", "selectedPlan": "BÁSICO"}	2025-09-04 16:30:12.209	2025-09-04 16:30:12.209
cmf5o3quv0002s78rwbzpnpyi	cmf5o3qut0000s78rgnu9t0ad	plan-basico	MONTHLY	TRIAL	2025-09-04 17:16:01.59	2025-10-04 17:16:01.59	2025-09-18 17:16:01.59	f	\N	{"signupDate": "2025-09-04T17:16:01.591Z", "selectedPlan": "BÁSICO"}	2025-09-04 17:16:01.592	2025-09-04 17:16:01.592
cmf5w9nq50002vgrp9oz4kjyc	cmf5w9nq10000vgrptiufiw9h	plan-basico	MONTHLY	TRIAL	2025-09-04 21:04:34.396	2025-10-04 21:04:34.396	2025-09-18 21:04:34.396	f	\N	{"signupDate": "2025-09-04T21:04:34.396Z", "selectedPlan": "BÁSICO"}	2025-09-04 21:04:34.397	2025-09-04 21:04:34.397
cmf5xcqej0002vgkobb43ql7j	cmf5xcqeh0000vgkovh9xdwem	plan-basico	MONTHLY	TRIAL	2025-09-04 21:34:57.45	2025-10-04 21:34:57.45	2025-09-18 21:34:57.45	f	\N	{"signupDate": "2025-09-04T21:34:57.450Z", "selectedPlan": "BÁSICO"}	2025-09-04 21:34:57.451	2025-09-04 21:34:57.451
cmf5y3lms0002vgv97yer74lz	cmf5y3lmp0000vgv9am7u3vz5	plan-basico	MONTHLY	TRIAL	2025-09-04 21:55:50.979	2025-10-04 21:55:50.979	2025-09-18 21:55:50.979	f	\N	{"signupDate": "2025-09-04T21:55:50.979Z", "selectedPlan": "BÁSICO"}	2025-09-04 21:55:50.98	2025-09-04 21:55:50.98
cmf76r2x30002ug011359cfbr	cmf76r2x00000ug01ao08qy8m	plan-basico	MONTHLY	TRIAL	2025-09-05 18:45:49.574	2025-10-05 18:45:49.574	2025-09-19 18:45:49.574	f	\N	{"signupDate": "2025-09-05T18:45:49.574Z", "selectedPlan": "BÁSICO"}	2025-09-05 18:45:49.575	2025-09-05 18:45:49.575
cmf77xx0b0002ug7zultsog5q	cmf77xx090000ug7zfogto5zs	plan-basico	MONTHLY	TRIAL	2025-09-05 19:19:08.123	2025-10-05 19:19:08.123	2025-09-19 19:19:08.123	f	\N	{"signupDate": "2025-09-05T19:19:08.123Z", "selectedPlan": "BÁSICO"}	2025-09-05 19:19:08.124	2025-09-05 19:19:08.124
cmf7b8e760002vubomlr9nonk	cmf7b8e730000vubolitp5wub	plan-basico	MONTHLY	TRIAL	2025-09-05 20:51:15.809	2025-10-05 20:51:15.809	2025-09-19 20:51:15.809	f	\N	{"signupDate": "2025-09-05T20:51:15.810Z", "selectedPlan": "BÁSICO"}	2025-09-05 20:51:15.81	2025-09-05 20:51:15.81
cmf8g5njt0002wm851forzgrc	cmf8g5njq0000wm851h777hnb	plan-basico	MONTHLY	TRIAL	2025-09-06 15:56:52.216	2025-10-06 15:56:52.216	2025-09-20 15:56:52.216	f	\N	{"signupDate": "2025-09-06T15:56:52.217Z", "selectedPlan": "BÁSICO"}	2025-09-06 15:56:52.218	2025-09-06 15:56:52.218
cmf8jgltl0002wmkzeik3if66	cmf8jglte0000wmkzim9zee72	plan-basico	MONTHLY	TRIAL	2025-09-06 17:29:22.04	2025-10-06 17:29:22.04	2025-09-20 17:29:22.04	f	\N	{"signupDate": "2025-09-06T17:29:22.040Z", "selectedPlan": "BÁSICO"}	2025-09-06 17:29:22.041	2025-09-06 17:29:22.041
cmf8l2j8n0002zozz88b8ff9j	cmf8l2j8l0000zozzbth9kmum	plan-basico	MONTHLY	TRIAL	2025-09-06 18:14:24.743	2025-10-06 18:14:24.743	2025-09-20 18:14:24.743	f	\N	{"signupDate": "2025-09-06T18:14:24.743Z", "selectedPlan": "BÁSICO"}	2025-09-06 18:14:24.744	2025-09-06 18:14:24.744
cmf8m09x60002zol2fxtevfb0	cmf8m09x30000zol2oia50lkd	plan-basico	MONTHLY	TRIAL	2025-09-06 18:40:38.969	2025-10-06 18:40:38.969	2025-09-20 18:40:38.969	f	\N	{"signupDate": "2025-09-06T18:40:38.969Z", "selectedPlan": "BÁSICO"}	2025-09-06 18:40:38.97	2025-09-06 18:40:38.97
cmf8nkc720002zobh60gceada	cmf8nkc6y0000zobhy1ybl7hk	plan-basico	MONTHLY	TRIAL	2025-09-06 19:24:14.654	2025-10-06 19:24:14.654	2025-09-20 19:24:14.654	f	\N	{"signupDate": "2025-09-06T19:24:14.654Z", "selectedPlan": "BÁSICO"}	2025-09-06 19:24:14.655	2025-09-06 19:24:14.655
cmf8olij00002zow4f1fj2p0g	cmf8oliiw0000zow4q4zq31ez	plan-basico	MONTHLY	TRIAL	2025-09-06 19:53:09.131	2025-10-06 19:53:09.131	2025-09-20 19:53:09.131	f	\N	{"signupDate": "2025-09-06T19:53:09.131Z", "selectedPlan": "BÁSICO"}	2025-09-06 19:53:09.132	2025-09-06 19:53:09.132
cmf8qt52t00020hqrzbl37mn9	cmf8qt52p00000hqreyjwk5al	plan-basico	MONTHLY	TRIAL	2025-09-06 20:55:04.18	2025-10-06 20:55:04.18	2025-09-20 20:55:04.18	f	\N	{"signupDate": "2025-09-06T20:55:04.180Z", "selectedPlan": "BÁSICO"}	2025-09-06 20:55:04.181	2025-09-06 20:55:04.181
cmf8se6ja00020hrdl308xt3y	cmf8se6j700000hrdcsgpog77	plan-basico	MONTHLY	TRIAL	2025-09-06 21:39:25.461	2025-10-06 21:39:25.461	2025-09-20 21:39:25.461	f	\N	{"signupDate": "2025-09-06T21:39:25.461Z", "selectedPlan": "BÁSICO"}	2025-09-06 21:39:25.462	2025-09-06 21:39:25.462
cmf8tfuaz00020hp1lukkfiel	cmf8tfuaw00000hp1oen710io	plan-basico	MONTHLY	TRIAL	2025-09-06 22:08:42.538	2025-10-06 22:08:42.538	2025-09-20 22:08:42.538	f	\N	{"signupDate": "2025-09-06T22:08:42.538Z", "selectedPlan": "BÁSICO"}	2025-09-06 22:08:42.539	2025-09-06 22:08:42.539
cmf8tw0ix00020he1gy4h6y22	cmf8tw0iv00000he1hsz6dsju	plan-basico	MONTHLY	TRIAL	2025-09-06 22:21:17.097	2025-10-06 22:21:17.097	2025-09-20 22:21:17.097	f	\N	{"signupDate": "2025-09-06T22:21:17.097Z", "selectedPlan": "BÁSICO"}	2025-09-06 22:21:17.098	2025-09-06 22:21:17.098
cmf8vhax400020h49scvwutod	cmf8vhax200000h49hwrlwkdt	plan-basico	MONTHLY	TRIAL	2025-09-06 23:05:49.96	2025-10-06 23:05:49.96	2025-09-20 23:05:49.96	f	\N	{"signupDate": "2025-09-06T23:05:49.960Z", "selectedPlan": "BÁSICO"}	2025-09-06 23:05:49.961	2025-09-06 23:05:49.961
cmf8vpiqm00020hl3io886y76	cmf8vpiqk00000hl309k0bgkh	plan-basico	MONTHLY	TRIAL	2025-09-06 23:12:13.341	2025-10-06 23:12:13.341	2025-09-20 23:12:13.341	f	\N	{"signupDate": "2025-09-06T23:12:13.341Z", "selectedPlan": "BÁSICO"}	2025-09-06 23:12:13.342	2025-09-06 23:12:13.342
cmf8x48zi00020hlxhjgffutk	cmf8x48zg00000hlxgyjpc7e0	plan-basico	MONTHLY	TRIAL	2025-09-06 23:51:40.158	2025-10-06 23:51:40.158	2025-09-20 23:51:40.158	f	\N	{"signupDate": "2025-09-06T23:51:40.158Z", "selectedPlan": "BÁSICO"}	2025-09-06 23:51:40.159	2025-09-06 23:51:40.159
cmfbf4e070002tyrpazujjdk1	cmfbf4e020000tyrpgns0kbnq	plan-basico	MONTHLY	TRIAL	2025-09-08 17:51:12.102	2025-10-08 17:51:12.102	2025-09-22 17:51:12.102	f	\N	{"signupDate": "2025-09-08T17:51:12.102Z", "selectedPlan": "BÁSICO"}	2025-09-08 17:51:12.103	2025-09-08 17:51:12.103
cmfbfxl9t0002tybmox5sy8w1	cmfbfxl9q0000tybm5bfrp0mc	plan-basico	MONTHLY	TRIAL	2025-09-08 18:13:54.545	2025-10-08 18:13:54.545	2025-09-22 18:13:54.545	f	\N	{"signupDate": "2025-09-08T18:13:54.545Z", "selectedPlan": "BÁSICO"}	2025-09-08 18:13:54.546	2025-09-08 18:13:54.546
cmfbmddi00002uyyz7rh1qqde	cmfbmddhx0000uyyzzgmhz09z	plan-basico	MONTHLY	TRIAL	2025-09-08 21:14:08.663	2025-10-08 21:14:08.663	2025-09-22 21:14:08.663	f	\N	{"signupDate": "2025-09-08T21:14:08.663Z", "selectedPlan": "BÁSICO"}	2025-09-08 21:14:08.664	2025-09-08 21:14:08.664
cmfbnh7sy0002uylnphz7hvxh	cmfbnh7sv0000uylnq5rdr1qp	plan-basico	MONTHLY	TRIAL	2025-09-08 21:45:07.522	2025-10-08 21:45:07.522	2025-09-22 21:45:07.522	f	\N	{"signupDate": "2025-09-08T21:45:07.522Z", "selectedPlan": "BÁSICO"}	2025-09-08 21:45:07.523	2025-09-08 21:45:07.523
cmfbocb0r0002uynz379y1ws1	cmfbocb0p0000uynz5m7l3i6s	plan-basico	MONTHLY	TRIAL	2025-09-08 22:09:18.026	2025-10-08 22:09:18.026	2025-09-22 22:09:18.026	f	\N	{"signupDate": "2025-09-08T22:09:18.027Z", "selectedPlan": "BÁSICO"}	2025-09-08 22:09:18.028	2025-09-08 22:09:18.028
cmfbp2uhx0002uywtqc6r74nq	cmfbp2uhv0000uywtp2b8d1wn	plan-basico	MONTHLY	TRIAL	2025-09-08 22:29:56.325	2025-10-08 22:29:56.325	2025-09-22 22:29:56.325	f	\N	{"signupDate": "2025-09-08T22:29:56.325Z", "selectedPlan": "BÁSICO"}	2025-09-08 22:29:56.326	2025-09-08 22:29:56.326
cmfh1xpai0002vux1w3tianne	cmfh1xpac0000vux1gz7o2nwp	plan-basico	MONTHLY	TRIAL	2025-09-12 16:28:42.185	2025-10-12 16:28:42.185	2025-09-26 16:28:42.185	f	\N	{"signupDate": "2025-09-12T16:28:42.186Z", "selectedPlan": "BÁSICO"}	2025-09-12 16:28:42.186	2025-09-12 16:28:42.186
\.


--
-- TOC entry 4625 (class 0 OID 9480509)
-- Dependencies: 269
-- Data for Name: church_themes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.church_themes (id, "churchId", "themeName", "themeConfig", "logoUrl", "faviconUrl", "bannerUrl", "brandColors", "primaryFont", "headingFont", "layoutStyle", "allowMemberThemes", "allowColorChanges", "allowFontChanges", "allowLayoutChanges", "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4573 (class 0 OID 9479977)
-- Dependencies: 217
-- Data for Name: churches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.churches (id, name, address, phone, email, website, founded, logo, description, "isActive", "createdAt", "updatedAt") FROM stdin;
cmeyt1tkw0000q8xyyr97bp74	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-08-30 22:00:06.657	2025-08-30 22:00:06.657
demo-church	Iglesia Central Ejemplo	Calle Principal 123, Ciudad, Estado	+1234567890	contacto@iglesiacentral.com	https://iglesiacentral.com	2000-01-01 00:00:00	\N	Una iglesia comprometida con la comunidad y el crecimiento espiritual.	t	2025-08-30 22:13:48.858	2025-08-30 22:13:48.858
cmeyulmq10000q88uarsz29du	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-08-30 22:43:30.506	2025-08-30 22:43:30.506
cmeywekr50000q8jzbj0r3u0c	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-08-30 23:34:00.594	2025-08-30 23:34:00.594
cmeyxxtr90000q8xonjxhcvar	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-08-31 00:16:58.341	2025-08-31 00:16:58.341
cmeyzngfn0000q8legh8qh70q	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-08-31 01:04:53.747	2025-08-31 01:04:53.747
cmez0uqja0000q8e3wiqkv9jx	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-08-31 01:38:33.046	2025-08-31 01:38:33.046
cmez0yndy0007q8e3s9i3852m	Test Secure Church	\N	\N	\N	\N	\N	\N	\N	t	2025-08-31 01:41:35.591	2025-08-31 01:41:35.591
cmez0ysov000eq8e399j8ucvk	Bad Church	\N	\N	\N	\N	\N	\N	\N	t	2025-08-31 01:41:42.463	2025-08-31 01:41:42.463
cmez0yxq6000lq8e3x5yi4otw	Bad Church 2	\N	\N	\N	\N	\N	\N	\N	t	2025-08-31 01:41:48.99	2025-08-31 01:41:48.99
cmez2v2yv0000q8gib6m58u6b	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-08-31 02:34:48.391	2025-08-31 02:34:48.391
cmez30eze0000q86ntsvyk2iz	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-08-31 02:38:57.243	2025-08-31 02:38:57.243
cmez33zdr0007q86nr4tvl5ib	Synced Test Church	\N	\N	\N	\N	\N	\N	\N	t	2025-08-31 02:41:43.647	2025-08-31 02:41:43.647
cmez3tbek0000q8qsrgyoaknu	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-08-31 03:01:25.629	2025-08-31 03:01:25.629
cmf1c9n6w0000s8wf57x68925	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-01 16:33:36.68	2025-09-01 16:33:36.68
cmf1cyh4t0000s8vh9p0cerql	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-01 16:52:55.229	2025-09-01 16:52:55.229
cmf1euc2f0000s8e8xk8pw7d9	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-01 17:45:41.271	2025-09-01 17:45:41.271
cmf1flwvf0000s84oop1aeh96	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-01 18:07:07.948	2025-09-01 18:07:07.948
cmf1gcbtg0000s8mpc4skc5rg	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-01 18:27:40.373	2025-09-01 18:27:40.373
cmf1jo2tc0000p2nv3nbzeape	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-01 20:00:47.424	2025-09-01 20:00:47.424
cmf1kqq810000p2gq6eacddjl	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-01 20:30:50.689	2025-09-01 20:30:50.689
cmf1mfqc60000m2q1k2g3md5b	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-01 21:18:16.854	2025-09-01 21:18:16.854
cmf1nzgzm0000m2ladrdl8007	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-01 22:01:37.474	2025-09-01 22:01:37.474
cmf1ojke60000m20o274v44ch	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-01 22:17:15.007	2025-09-01 22:17:15.007
cmf1p8blo0000m2qg06rvrow4	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-01 22:36:30.012	2025-09-01 22:36:30.012
cmf1q0nmy0000m2g97d1xzdx1	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-01 22:58:31.979	2025-09-01 22:58:31.979
cmf1qpumf0000m2zuk31kulwc	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-01 23:18:07.432	2025-09-01 23:18:07.432
cmf1ri0vj0000m2j6ic7bjkmi	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-01 23:40:01.904	2025-09-01 23:40:01.904
cmf1s66fe0000of019relorwd	NEW HOPE BAPTIST CHURCH	\N	\N	\N	\N	\N	\N	\N	t	2025-09-01 23:58:48.842	2025-09-01 23:58:48.842
cmf2lzzdq0000q7z8kkfwdmol	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-02 13:53:48.254	2025-09-02 13:53:48.254
cmf2nf3dd0000q7qzpg7bbuwz	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-02 14:33:32.881	2025-09-02 14:33:32.881
cmf2o64sb0000q7hmquald4hd	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-02 14:54:34.427	2025-09-02 14:54:34.427
cmf2owxbq0000q74hhyfjnsy0	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-02 15:15:24.47	2025-09-02 15:15:24.47
cmf2px4jc0000q7pph68odq7g	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-02 15:43:33.432	2025-09-02 15:43:33.432
cmf2rb4ru0000q7763rck0uwj	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-02 16:22:26.538	2025-09-02 16:22:26.538
cmf2tg72q0000ntovxmk4l8ti	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-02 17:22:22.034	2025-09-02 17:22:22.034
cmf2uaqxn0000ntbfywax1quq	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-02 17:46:07.451	2025-09-02 17:46:07.451
cmf2vfy8l0000nt4gc5gz994q	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-02 18:18:09.813	2025-09-02 18:18:09.813
cmf2wun9w0000nt0oswz1q6px	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-02 18:57:35.06	2025-09-02 18:57:35.06
cmf30f6pg0000vvoni6r15qoh	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-02 20:37:32.212	2025-09-02 20:37:32.212
cmf318t6f0000vv7w2f1muqzg	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-02 21:00:34.36	2025-09-02 21:00:34.36
cmf32jnwo0000vv3jilchdgw8	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-02 21:37:00.361	2025-09-02 21:37:00.361
cmf341qg40000vv723fg9he77	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-02 22:19:03.076	2025-09-02 22:19:03.076
cmf34o6td0000vvrndejb7y2p	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-02 22:36:30.722	2025-09-02 22:36:30.722
cmf35jn730000vvubhnnw4oxz	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-02 23:00:58.287	2025-09-02 23:00:58.287
cmf35rkjj0000vvjt4pwsy0dz	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-02 23:07:08.096	2025-09-02 23:07:08.096
cmf36kgah0000vv92dg716icf	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-02 23:29:35.609	2025-09-02 23:29:35.609
cmf474koj0000uqzvlrfoxqtm	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-03 16:33:00.595	2025-09-03 16:33:00.595
cmf47wdk60000uqos0lkwharm	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-03 16:54:37.735	2025-09-03 16:54:37.735
cmf48k9650000uq91bnx3l1ma	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-03 17:13:11.789	2025-09-03 17:13:11.789
cmf49g0v50000uqpiv19hw43t	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-03 17:37:54.017	2025-09-03 17:37:54.017
cmf4a1dqs0000uq9npv695x49	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-03 17:54:30.484	2025-09-03 17:54:30.484
cmf4an4pq0000uqr2r3vrslq2	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-03 18:11:25.214	2025-09-03 18:11:25.214
cmf4befuj0000uqblsubhki3k	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-03 18:32:39.355	2025-09-03 18:32:39.355
cmf5jm5hl0000s7mstbgeeqmq	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-04 15:10:22.281	2025-09-04 15:10:22.281
cmf5jyxsw0000s7nlvukvas4x	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-04 15:20:18.849	2025-09-04 15:20:18.849
cmf5lu99r0000s7m69navda79	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-04 16:12:39.663	2025-09-04 16:12:39.663
cmf5mgtf20000s71ymce0bf3w	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-04 16:30:12.206	2025-09-04 16:30:12.206
cmf5o3qut0000s78rgnu9t0ad	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-04 17:16:01.589	2025-09-04 17:16:01.589
cmf5w9nq10000vgrptiufiw9h	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-04 21:04:34.394	2025-09-04 21:04:34.394
cmf5xcqeh0000vgkovh9xdwem	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-04 21:34:57.449	2025-09-04 21:34:57.449
cmf5y3lmp0000vgv9am7u3vz5	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-04 21:55:50.978	2025-09-04 21:55:50.978
cmf76r2x00000ug01ao08qy8m	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-05 18:45:49.572	2025-09-05 18:45:49.572
cmf77xx090000ug7zfogto5zs	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-05 19:19:08.121	2025-09-05 19:19:08.121
cmf7b8e730000vubolitp5wub	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-05 20:51:15.807	2025-09-05 20:51:15.807
cmf8g5njq0000wm851h777hnb	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-06 15:56:52.214	2025-09-06 15:56:52.214
cmf8jglte0000wmkzim9zee72	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-06 17:29:22.034	2025-09-06 17:29:22.034
cmf8l2j8l0000zozzbth9kmum	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-06 18:14:24.741	2025-09-06 18:14:24.741
cmf8m09x30000zol2oia50lkd	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-06 18:40:38.967	2025-09-06 18:40:38.967
cmf8nkc6y0000zobhy1ybl7hk	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-06 19:24:14.65	2025-09-06 19:24:14.65
cmf8oliiw0000zow4q4zq31ez	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-06 19:53:09.129	2025-09-06 19:53:09.129
cmf8qt52p00000hqreyjwk5al	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-06 20:55:04.177	2025-09-06 20:55:04.177
cmf8rb8v60000mt0148xslbte	DEFENSORES DE LA FE	CALLE 50 SE # 1280 LA RIVIERA RIO PIEDRAS, PR	787 755 5555	PEDRO CARRERA		2025-09-06 00:00:00	\N		t	2025-09-06 21:09:08.898	2025-09-06 21:09:08.898
cmf8se6j700000hrdcsgpog77	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-06 21:39:25.46	2025-09-06 21:39:25.46
cmf8tfuaw00000hp1oen710io	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-06 22:08:42.536	2025-09-06 22:08:42.536
cmf8tw0iv00000he1hsz6dsju	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-06 22:21:17.096	2025-09-06 22:21:17.096
cmf8udnbz0000s101ohl648q7	REBAÑO COMPAÑERISMO CRISTIANO (ARLINGTON)	7033 S. COOPER ST. ARLINGTON, TX 76010	847 406 8956	tonypilarte@gmail.com		2025-09-06 00:00:00	\N		t	2025-09-06 22:34:59.808	2025-09-06 22:34:59.808
cmf8vhax200000h49hwrlwkdt	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-06 23:05:49.959	2025-09-06 23:05:49.959
cmf8vpiqk00000hl309k0bgkh	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-06 23:12:13.34	2025-09-06 23:12:13.34
cmf8x48zg00000hlxgyjpc7e0	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-06 23:51:40.156	2025-09-06 23:51:40.156
cmfbf4e020000tyrpgns0kbnq	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-08 17:51:12.099	2025-09-08 17:51:12.099
cmfbfxl9q0000tybm5bfrp0mc	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-08 18:13:54.542	2025-09-08 18:13:54.542
cmfbmddhx0000uyyzzgmhz09z	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-08 21:14:08.661	2025-09-08 21:14:08.661
cmfbnh7sv0000uylnq5rdr1qp	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-08 21:45:07.52	2025-09-08 21:45:07.52
cmfbocb0p0000uynz5m7l3i6s	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-08 22:09:18.026	2025-09-08 22:09:18.026
cmfbp2uhv0000uywtp2b8d1wn	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-08 22:29:56.323	2025-09-08 22:29:56.323
cmfh1xpac0000vux1gz7o2nwp	Iglesia de Prueba	\N	\N	\N	\N	\N	\N	\N	t	2025-09-12 16:28:42.18	2025-09-12 16:28:42.18
\.


--
-- TOC entry 4596 (class 0 OID 9480230)
-- Dependencies: 240
-- Data for Name: communication_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.communication_templates (id, name, subject, content, type, variables, category, "isActive", "churchId", "createdAt", "updatedAt") FROM stdin;
cmeytjgrr0026q8fcwb5daw5e	Recordatorio de Evento	\N	Hola {{nombre}}, te recordamos que {{evento}} será {{fecha}} a las {{hora}}. ¡Te esperamos!	SMS	["nombre","evento","fecha","hora"]	RECORDATORIO	t	demo-church	2025-08-30 22:13:49.863	2025-08-30 22:13:49.863
cmeytjgrr002aq8fcfc86kpn7	Seguimiento Primera Visita	\N	¡Hola {{nombre}}! Fue un placer conocerte en nuestra iglesia. ¿Te gustaría que oremos por algo específico contigo?	WHATSAPP	["nombre"]	SEGUIMIENTO	t	demo-church	2025-08-30 22:13:49.863	2025-08-30 22:13:49.863
cmeytjgrr0029q8fcu3owv2b1	Bienvenida Nuevos Visitantes	¡Bienvenido a nuestra iglesia!	¡Hola {{nombre}}! Nos alegra mucho que hayas visitado nuestra iglesia {{iglesia}}. Esperamos verte pronto de nuevo. Si tienes alguna pregunta, no dudes en contactarnos.	EMAIL	["nombre","iglesia"]	BIENVENIDA	t	demo-church	2025-08-30 22:13:49.863	2025-08-30 22:13:49.863
cmeytjgrr002bq8fc6h31bllf	Anuncio General	Anuncio importante de {{iglesia}}	Querida congregación,\n\n{{mensaje}}\n\nBendiciones,\nEl equipo pastoral	EMAIL	["iglesia","mensaje"]	ANUNCIO	t	demo-church	2025-08-30 22:13:49.863	2025-08-30 22:13:49.863
cmf76ch55002augjfue5fpqa9	Bienvenida Nuevos Visitantes	¡Bienvenido a nuestra iglesia!	¡Hola {{nombre}}! Nos alegra mucho que hayas visitado nuestra iglesia {{iglesia}}. Esperamos verte pronto de nuevo. Si tienes alguna pregunta, no dudes en contactarnos.	EMAIL	["nombre","iglesia"]	BIENVENIDA	t	demo-church	2025-09-05 18:34:28.17	2025-09-05 18:34:28.17
cmf76ch550029ugjf9u15xv5i	Seguimiento Primera Visita	\N	¡Hola {{nombre}}! Fue un placer conocerte en nuestra iglesia. ¿Te gustaría que oremos por algo específico contigo?	WHATSAPP	["nombre"]	SEGUIMIENTO	t	demo-church	2025-09-05 18:34:28.17	2025-09-05 18:34:28.17
cmf76ch55002bugjf3l44xlc8	Anuncio General	Anuncio importante de {{iglesia}}	Querida congregación,\n\n{{mensaje}}\n\nBendiciones,\nEl equipo pastoral	EMAIL	["iglesia","mensaje"]	ANUNCIO	t	demo-church	2025-09-05 18:34:28.17	2025-09-05 18:34:28.17
cmf76ch550027ugjf8w2fehlp	Recordatorio de Evento	\N	Hola {{nombre}}, te recordamos que {{evento}} será {{fecha}} a las {{hora}}. ¡Te esperamos!	SMS	["nombre","evento","fecha","hora"]	RECORDATORIO	t	demo-church	2025-09-05 18:34:28.17	2025-09-05 18:34:28.17
\.


--
-- TOC entry 4595 (class 0 OID 9480221)
-- Dependencies: 239
-- Data for Name: communications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.communications (id, title, content, type, "targetGroup", recipients, status, "scheduledAt", "sentAt", "sentBy", "templateId", "churchId", "createdAt", "updatedAt") FROM stdin;
cmeytjgs7003bq8fcj3y5nnx2	Anuncio Próximos Eventos	Próximamente tendremos varios eventos especiales. Mantente atento a más información.	WHATSAPP	LIDERES	12	PROGRAMADO	2025-08-31 22:13:49.878	\N	cmeytjgo50007q8fce5bou6vw	\N	demo-church	2025-08-30 22:13:49.879	2025-08-30 22:13:49.879
cmeytjgs7003aq8fctfzy7d1e	Bienvenida Enero 2024	¡Bienvenidos a todos los nuevos visitantes! Nos alegra tenerlos con nosotros.	EMAIL	TODOS	50	ENVIADO	\N	2025-08-23 22:13:49.878	cmeytjgo50007q8fce5bou6vw	cmeytjgrr0029q8fcu3owv2b1	demo-church	2025-08-30 22:13:49.879	2025-08-30 22:13:49.879
cmeytjgs70039q8fcm5h05ug9	Recordatorio Conferencia Jóvenes	Recordatorio: La conferencia de jóvenes es este viernes a las 6 PM. ¡No te lo pierdas!	SMS	VOLUNTARIOS	25	ENVIADO	\N	2025-08-28 22:13:49.878	cmeytjgnx0001q8fctjc12b43	cmeytjgrr0026q8fcwb5daw5e	demo-church	2025-08-30 22:13:49.879	2025-08-30 22:13:49.879
cmf76ch5u0039ugjfbhym8yw4	Bienvenida Enero 2024	¡Bienvenidos a todos los nuevos visitantes! Nos alegra tenerlos con nosotros.	EMAIL	TODOS	50	ENVIADO	\N	2025-08-29 18:34:28.193	cmeytjgo50007q8fce5bou6vw	cmf76ch55002augjfue5fpqa9	demo-church	2025-09-05 18:34:28.194	2025-09-05 18:34:28.194
cmf76ch5u003augjfpmhyrp11	Recordatorio Conferencia Jóvenes	Recordatorio: La conferencia de jóvenes es este viernes a las 6 PM. ¡No te lo pierdas!	SMS	VOLUNTARIOS	25	ENVIADO	\N	2025-09-03 18:34:28.193	cmeytjgnx0001q8fctjc12b43	cmf76ch550027ugjf8w2fehlp	demo-church	2025-09-05 18:34:28.194	2025-09-05 18:34:28.194
cmf76ch5u003bugjf8wstn06a	Anuncio Próximos Eventos	Próximamente tendremos varios eventos especiales. Mantente atento a más información.	WHATSAPP	LIDERES	12	PROGRAMADO	2025-09-06 18:34:28.193	\N	cmeytjgo50007q8fce5bou6vw	\N	demo-church	2025-09-05 18:34:28.194	2025-09-05 18:34:28.194
\.


--
-- TOC entry 4607 (class 0 OID 9480332)
-- Dependencies: 251
-- Data for Name: custom_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_reports (id, name, description, "reportType", config, filters, columns, "groupBy", "sortBy", "chartType", "isPublic", "isTemplate", "createdBy", "churchId", "lastRunAt", "runCount", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4611 (class 0 OID 9480371)
-- Dependencies: 255
-- Data for Name: dashboard_widgets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dashboard_widgets (id, "dashboardId", name, type, "chartType", "dataSource", filters, "position", "refreshInterval", "isVisible", config, "churchId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4642 (class 0 OID 9480700)
-- Dependencies: 286
-- Data for Name: donation_campaigns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.donation_campaigns (id, title, description, "goalAmount", "currentAmount", currency, "churchId", "categoryId", "isActive", "isPublic", slug, "coverImage", "startDate", "endDate", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4589 (class 0 OID 9480140)
-- Dependencies: 233
-- Data for Name: donation_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.donation_categories (id, name, description, "churchId", "isActive", "createdAt", "updatedAt") FROM stdin;
cat-diezmos	Diezmos	Diezmos regulares de los miembros	demo-church	t	2025-08-30 22:13:49.832	2025-08-30 22:13:49.832
cat-construccion	Proyecto de Construcción	Fondos para nueva construcción del templo	demo-church	t	2025-08-30 22:13:49.832	2025-08-30 22:13:49.832
cat-misiones	Misiones	Donaciones para obra misionera	demo-church	t	2025-08-30 22:13:49.832	2025-08-30 22:13:49.832
cat-ofrendas	Ofrendas	Ofrendas voluntarias en servicios	demo-church	t	2025-08-30 22:13:49.832	2025-08-30 22:13:49.832
\.


--
-- TOC entry 4591 (class 0 OID 9480159)
-- Dependencies: 235
-- Data for Name: donations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.donations (id, amount, currency, "donorName", "donorEmail", "donorPhone", "memberId", "categoryId", "paymentMethodId", reference, notes, "isAnonymous", status, "donationDate", "churchId", "createdAt", "updatedAt", "campaignId") FROM stdin;
cmeytjgr5001zq8fcoi209zg9	150000	COP	Sofia García	sofia.garcia@email.com	\N	\N	cat-misiones	method-tarjeta	CARD-4567	Para obra misionera en África	f	COMPLETADA	2025-08-09 00:00:00	demo-church	2025-08-30 22:13:49.842	2025-08-30 22:13:49.842	\N
cmeytjgr5001yq8fc8k0641j7	500000	COP	\N	\N	\N	\N	cat-construccion	method-nequi	NEQUI-789456	Donación especial para nueva construcción	t	COMPLETADA	2025-08-04 00:00:00	demo-church	2025-08-30 22:13:49.842	2025-08-30 22:13:49.842	\N
cmeytjgr5001wq8fcrvcw20u8	100000	COP	Pedro López	pedro.lopez@email.com	\N	\N	cat-ofrendas	method-efectivo	\N	Ofrenda dominical	f	COMPLETADA	2025-07-13 00:00:00	demo-church	2025-08-30 22:13:49.842	2025-08-30 22:13:49.842	\N
cmeytjgr5001xq8fco4bj6mzb	250000	COP	Ana Martínez	ana.martinez@email.com	+1234567801	\N	cat-diezmos	method-transferencia	TRX-2024-001	Diezmo mensual	f	COMPLETADA	2025-07-06 00:00:00	demo-church	2025-08-30 22:13:49.842	2025-08-30 22:13:49.842	\N
cmeytjgrl0021q8fcue9sg3oy	300000	COP	Miguel Torres	miguel.torres@email.com	\N	\N	cat-diezmos	method-transferencia	TRX-2024-015	Diezmo + ofrenda especial	f	COMPLETADA	2025-08-28 22:13:49.841	demo-church	2025-08-30 22:13:49.842	2025-08-30 22:13:49.842	\N
cmeytjgrm0023q8fc8nurfive	75000	COP	\N	\N	\N	\N	cat-ofrendas	method-efectivo	\N	Ofrenda de gratitud	t	COMPLETADA	2025-08-29 22:13:49.841	demo-church	2025-08-30 22:13:49.842	2025-08-30 22:13:49.842	\N
cmf76ch4j001yugjfv8u7u6az	150000	COP	Sofia García	sofia.garcia@email.com	\N	\N	cat-misiones	method-tarjeta	CARD-4567	Para obra misionera en África	f	COMPLETADA	2025-09-09 00:00:00	demo-church	2025-09-05 18:34:28.147	2025-09-05 18:34:28.147	\N
cmf76ch4j001wugjfy7hp7p79	100000	COP	Pedro López	pedro.lopez@email.com	\N	\N	cat-ofrendas	method-efectivo	\N	Ofrenda dominical	f	COMPLETADA	2025-08-13 00:00:00	demo-church	2025-09-05 18:34:28.147	2025-09-05 18:34:28.147	\N
cmf76ch4j001zugjfu4zbubwh	500000	COP	\N	\N	\N	\N	cat-construccion	method-nequi	NEQUI-789456	Donación especial para nueva construcción	t	COMPLETADA	2025-09-04 00:00:00	demo-church	2025-09-05 18:34:28.147	2025-09-05 18:34:28.147	\N
cmf76ch4j001xugjfnbof04ld	250000	COP	Ana Martínez	ana.martinez@email.com	+1234567801	\N	cat-diezmos	method-transferencia	TRX-2024-001	Diezmo mensual	f	COMPLETADA	2025-08-06 00:00:00	demo-church	2025-09-05 18:34:28.147	2025-09-05 18:34:28.147	\N
cmf76ch4y0021ugjf5bkvba5o	75000	COP	\N	\N	\N	\N	cat-ofrendas	method-efectivo	\N	Ofrenda de gratitud	t	COMPLETADA	2025-09-04 18:34:28.146	demo-church	2025-09-05 18:34:28.147	2025-09-05 18:34:28.147	\N
cmf76ch500023ugjff45dxjuy	300000	COP	Miguel Torres	miguel.torres@email.com	\N	\N	cat-diezmos	method-transferencia	TRX-2024-015	Diezmo + ofrenda especial	f	COMPLETADA	2025-09-03 18:34:28.146	demo-church	2025-09-05 18:34:28.147	2025-09-05 18:34:28.147	\N
\.


--
-- TOC entry 4598 (class 0 OID 9480248)
-- Dependencies: 242
-- Data for Name: event_resource_reservations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.event_resource_reservations (id, "resourceId", "eventId", "startTime", "endTime", notes, status, "reservedBy", "churchId", "createdAt", "updatedAt") FROM stdin;
cmeytjgry002tq8fcvf52flzn	cmeytjgru002gq8fc72aa7kfy	cmeytjgpf0011q8fci27ylgk1	2024-03-08 16:00:00	2024-03-10 14:00:00	Espacio principal para el retiro	CONFIRMADA	cmeytjgnx0001q8fctjc12b43	demo-church	2025-08-30 22:13:49.87	2025-08-30 22:13:49.87
cmeytjgry002rq8fcxo58mnrl	cmeytjgru002fq8fc6xt0vvit	cmeytjgpc000zq8fc1o1bpb12	2024-02-15 18:00:00	2024-02-17 20:00:00	Sonido para música y predicación	CONFIRMADA	cmeytjgo50007q8fce5bou6vw	demo-church	2025-08-30 22:13:49.87	2025-08-30 22:13:49.87
cmeytjgry002sq8fcehox18ct	cmeytjgru002hq8fcgtysjtuz	cmeytjgpc000zq8fc1o1bpb12	2024-02-15 18:00:00	2024-02-17 20:00:00	Para presentaciones durante la conferencia	CONFIRMADA	cmeytjgo50007q8fce5bou6vw	demo-church	2025-08-30 22:13:49.87	2025-08-30 22:13:49.87
cmf76ch5f002tugjfs3j90l3d	cmf76ch5a002iugjfae1ovqll	cmf76ch2a000zugjfkkjhyq7c	2024-02-15 18:00:00	2024-02-17 20:00:00	Para presentaciones durante la conferencia	CONFIRMADA	cmeytjgo50007q8fce5bou6vw	demo-church	2025-09-05 18:34:28.18	2025-09-05 18:34:28.18
cmf76ch5f002sugjfcpkuz2xr	cmf76ch5a002kugjfmt79gf7o	cmf76ch2f0011ugjfkpk2o38t	2024-03-08 16:00:00	2024-03-10 14:00:00	Espacio principal para el retiro	CONFIRMADA	cmeytjgnx0001q8fctjc12b43	demo-church	2025-09-05 18:34:28.18	2025-09-05 18:34:28.18
cmf76ch5f002rugjfmqlcqqts	cmf76ch5a002fugjfedvugkar	cmf76ch2a000zugjfkkjhyq7c	2024-02-15 18:00:00	2024-02-17 20:00:00	Sonido para música y predicación	CONFIRMADA	cmeytjgo50007q8fce5bou6vw	demo-church	2025-09-05 18:34:28.18	2025-09-05 18:34:28.18
\.


--
-- TOC entry 4597 (class 0 OID 9480239)
-- Dependencies: 241
-- Data for Name: event_resources; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.event_resources (id, name, description, type, capacity, "isActive", "churchId", "createdAt", "updatedAt") FROM stdin;
cmeytjgru002hq8fcgtysjtuz	Proyector Principal	Proyector de alta definición para presentaciones	EQUIPO	\N	t	demo-church	2025-08-30 22:13:49.867	2025-08-30 22:13:49.867
cmeytjgru002gq8fc72aa7kfy	Salón Principal	Auditorium principal de la iglesia	ESPACIO	300	t	demo-church	2025-08-30 22:13:49.867	2025-08-30 22:13:49.867
cmeytjgru002mq8fco9sfmxws	Piano	Piano de cola para servicios musicales	EQUIPO	\N	t	demo-church	2025-08-30 22:13:49.867	2025-08-30 22:13:49.867
cmeytjgru002fq8fc6xt0vvit	Sistema de Sonido	Equipo de audio completo con micrófonos	EQUIPO	\N	t	demo-church	2025-08-30 22:13:49.867	2025-08-30 22:13:49.867
cmeytjgru002kq8fcv6xedzk3	Salón de Usos Múltiples	Salón para actividades diversas	ESPACIO	100	t	demo-church	2025-08-30 22:13:49.867	2025-08-30 22:13:49.867
cmeytjgru002nq8fc441akx2g	Sillas Adicionales	Set de 50 sillas plegables	MATERIAL	\N	t	demo-church	2025-08-30 22:13:49.867	2025-08-30 22:13:49.867
cmf76ch5a002kugjfmt79gf7o	Salón Principal	Auditorium principal de la iglesia	ESPACIO	300	t	demo-church	2025-09-05 18:34:28.175	2025-09-05 18:34:28.175
cmf76ch5a002iugjfae1ovqll	Proyector Principal	Proyector de alta definición para presentaciones	EQUIPO	\N	t	demo-church	2025-09-05 18:34:28.175	2025-09-05 18:34:28.175
cmf76ch5a002fugjfedvugkar	Sistema de Sonido	Equipo de audio completo con micrófonos	EQUIPO	\N	t	demo-church	2025-09-05 18:34:28.175	2025-09-05 18:34:28.175
cmf76ch5a002nugjfxbjjspv6	Sillas Adicionales	Set de 50 sillas plegables	MATERIAL	\N	t	demo-church	2025-09-05 18:34:28.175	2025-09-05 18:34:28.175
cmf76ch5a002jugjfy7s4whrn	Salón de Usos Múltiples	Salón para actividades diversas	ESPACIO	100	t	demo-church	2025-09-05 18:34:28.175	2025-09-05 18:34:28.175
cmf76ch5a002mugjf3j8rq8ko	Piano	Piano de cola para servicios musicales	EQUIPO	\N	t	demo-church	2025-09-05 18:34:28.175	2025-09-05 18:34:28.175
\.


--
-- TOC entry 4583 (class 0 OID 9480074)
-- Dependencies: 227
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.events (id, title, description, "startDate", "endDate", location, "churchId", "isPublic", "createdAt", "updatedAt") FROM stdin;
cmeytjgpc000zq8fc1o1bpb12	Conferencia de Jóvenes	Una conferencia especial para jóvenes con música, testimonios y enseñanza bíblica.	2024-02-15 18:00:00	2024-02-17 20:00:00	Auditorio Principal	demo-church	t	2025-08-30 22:13:49.777	2025-08-30 22:13:49.777
cmeytjgpf0011q8fci27ylgk1	Retiro de Matrimonios	Un fin de semana para fortalecer los matrimonios a través de talleres y actividades.	2024-03-08 16:00:00	2024-03-10 14:00:00	Centro de Retiros Valle Verde	demo-church	t	2025-08-30 22:13:49.779	2025-08-30 22:13:49.779
cmeytjgph0013q8fcpte7p3bj	Evangelización Comunitaria	Salida misionera al parque central para compartir el evangelio.	2024-02-24 09:00:00	2024-02-24 13:00:00	Parque Central	demo-church	t	2025-08-30 22:13:49.781	2025-08-30 22:13:49.781
cmf76ch2a000zugjfkkjhyq7c	Conferencia de Jóvenes	Una conferencia especial para jóvenes con música, testimonios y enseñanza bíblica.	2024-02-15 18:00:00	2024-02-17 20:00:00	Auditorio Principal	demo-church	t	2025-09-05 18:34:28.066	2025-09-05 18:34:28.066
cmf76ch2f0011ugjfkpk2o38t	Retiro de Matrimonios	Un fin de semana para fortalecer los matrimonios a través de talleres y actividades.	2024-03-08 16:00:00	2024-03-10 14:00:00	Centro de Retiros Valle Verde	demo-church	t	2025-09-05 18:34:28.071	2025-09-05 18:34:28.071
cmf76ch2h0013ugjf2hjvjin0	Evangelización Comunitaria	Salida misionera al parque central para compartir el evangelio.	2024-02-24 09:00:00	2024-02-24 13:00:00	Parque Central	demo-church	t	2025-09-05 18:34:28.073	2025-09-05 18:34:28.073
\.


--
-- TOC entry 4622 (class 0 OID 9480474)
-- Dependencies: 266
-- Data for Name: funnel_conversions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.funnel_conversions (id, email, "firstName", "lastName", phone, data, source, "ipAddress", "userAgent", "funnelId", "stepId", "createdAt") FROM stdin;
\.


--
-- TOC entry 4621 (class 0 OID 9480465)
-- Dependencies: 265
-- Data for Name: funnel_steps; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.funnel_steps (id, name, slug, content, type, "order", settings, "funnelId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4620 (class 0 OID 9480455)
-- Dependencies: 264
-- Data for Name: funnels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.funnels (id, name, slug, description, type, config, "isActive", "isPublished", "websiteId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4599 (class 0 OID 9480257)
-- Dependencies: 243
-- Data for Name: integration_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.integration_configs (id, service, config, "isActive", "churchId", "createdAt", "updatedAt") FROM stdin;
cmeytjgs1002yq8fcbgx1qwrb	WHATSAPP	{"businessAccountId":"example_business_id","phoneNumberId":"example_phone_id","accessToken":"example_access_token"}	f	demo-church	2025-08-30 22:13:49.873	2025-08-30 22:13:49.873
cmeytjgs1002zq8fc4po3k96z	MAILGUN	{"apiKey":"example_api_key","domain":"example.mailgun.org","from":"noreply@iglesiacentral.com"}	f	demo-church	2025-08-30 22:13:49.873	2025-08-30 22:13:49.873
cmeytjgs1002xq8fcnk1hv4n0	TWILIO	{"accountSid":"AC_EXAMPLE_SID","authToken":"example_auth_token","phoneNumber":"+1234567890"}	f	demo-church	2025-08-30 22:13:49.873	2025-08-30 22:13:49.873
cmf76ch5k002yugjfoip3lv4y	WHATSAPP	{"businessAccountId":"example_business_id","phoneNumberId":"example_phone_id","accessToken":"example_access_token"}	f	demo-church	2025-09-05 18:34:28.184	2025-09-05 18:34:28.184
cmf76ch5k002zugjfdh3vprok	MAILGUN	{"apiKey":"example_api_key","domain":"example.mailgun.org","from":"noreply@iglesiacentral.com"}	f	demo-church	2025-09-05 18:34:28.184	2025-09-05 18:34:28.184
cmf76ch5k002xugjfitj81yse	TWILIO	{"accountSid":"AC_EXAMPLE_SID","authToken":"example_auth_token","phoneNumber":"+1234567890"}	f	demo-church	2025-09-05 18:34:28.184	2025-09-05 18:34:28.184
\.


--
-- TOC entry 4664 (class 0 OID 9579027)
-- Dependencies: 308
-- Data for Name: invoice_communications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoice_communications (id, "invoiceId", type, direction, subject, message, "sentBy", "sentTo", status, metadata, "createdAt") FROM stdin;
\.


--
-- TOC entry 4662 (class 0 OID 9579009)
-- Dependencies: 306
-- Data for Name: invoice_line_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoice_line_items (id, "invoiceId", description, quantity, "unitPrice", "totalPrice", metadata, "createdAt") FROM stdin;
\.


--
-- TOC entry 4663 (class 0 OID 9579018)
-- Dependencies: 307
-- Data for Name: invoice_payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoice_payments (id, "invoiceId", amount, currency, "paymentMethod", reference, notes, "verifiedBy", "verifiedAt", "createdAt") FROM stdin;
\.


--
-- TOC entry 4661 (class 0 OID 9578996)
-- Dependencies: 305
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoices (id, "invoiceNumber", "churchId", "subscriptionId", status, type, currency, subtotal, "taxAmount", "totalAmount", "dueDate", "isRecurrent", "recurrentConfig", notes, "pdfPath", "sentAt", "paidAt", "createdBy", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4612 (class 0 OID 9480381)
-- Dependencies: 256
-- Data for Name: kpi_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kpi_metrics (id, name, description, category, "metricType", "dataSource", target, "currentValue", "previousValue", "changePercent", "trendDirection", color, icon, unit, period, "isActive", "churchId", "lastCalculated", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4605 (class 0 OID 9480312)
-- Dependencies: 249
-- Data for Name: marketing_campaign_posts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.marketing_campaign_posts (id, "campaignId", "postId", "accountId", "order", "scheduledAt", "publishedAt", status, metrics, notes, "churchId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4604 (class 0 OID 9480302)
-- Dependencies: 248
-- Data for Name: marketing_campaigns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.marketing_campaigns (id, name, description, objectives, "targetAudience", budget, currency, "startDate", "endDate", status, platforms, metrics, tags, "managerId", "churchId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4654 (class 0 OID 9480823)
-- Dependencies: 298
-- Data for Name: member_spiritual_profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.member_spiritual_profiles (id, "memberId", "primaryGifts", "secondaryGifts", "spiritualCalling", "ministryPassions", "experienceLevel", "leadershipScore", "servingMotivation", "previousExperience", "trainingCompleted", "assessmentDate", "createdAt", "updatedAt", "availabilityScore", "communicationSkills", "discipleshipTraining", "leadershipAptitudeScore", "leadershipReadinessScore", "leadershipTrainingCompleted", "leadershipTrainingDate", "mentoringExperience", "ministryPassionScore", "organizationalSkills", "pastoralHeart", "spiritualMaturityScore", "teachingAbility", "volunteerReadinessScore") FROM stdin;
cmf35at360003k001i7uzhf9t	cmf2zrjok0001qt01lpqehwa4	["cmf4h2u1s000cpcnnbjyidp3d", "cmf4h2u1f0003pcnnzbmuvuf6", "cmf4h2u1c0001pcnn7p99f6ee", "cmf4h2u1x000gpcnn5wkt32te", "cmf4h2u20000ipcnnmr64xzj4", "cmf4h2u1m0008pcnn7t2exocb", "cmf4h2u26000mpcnnobihclkw", "cmf4h2u25000lpcnnxnftzg79"]	["cmf4h2u170000pcnnkbr6rhwh", "cmf4h2u1r000bpcnndj4ykn7r", "cmf4h2u1i0005pcnnf9os4ctv", "cmf4h2u1w000fpcnn1qd0g4xn", "cmf4h2u22000jpcnnxmplxtoy", "cmf4h2u23000kpcnn5rk09vll", "cmf4h2u1p000apcnn57kkpkns", "cmf4h2u27000npcnn1ip6rckz"]	EN MI RELACIÓN PERSONAL CON EL	["Administración", "Tecnología", "Medios"]	9	1	AGRADECIMIENTO	[]	[]	2025-09-03 21:23:54.907	2025-09-02 22:54:05.993	2025-09-03 21:23:54.908	50	50	f	50	0	f	\N	f	50	50	50	50	50	0
cmfe5vxdd000zqj01ofano6qe	cmf76ch1t000nugjfxhh83umo	["cmf4h2u1c0001pcnn7p99f6ee", "cmf4h2u23000kpcnn5rk09vll", "cmf4h2u1m0008pcnn7t2exocb", "cmf4h2u1f0003pcnnzbmuvuf6", "cmf4h2u1w000fpcnn1qd0g4xn", "cmf4h2u2a000ppcnn2eeok3he", "cmf4h2u26000mpcnnobihclkw", "cmf4h2u25000lpcnnxnftzg79", "cmf4h2u27000npcnn1ip6rckz"]	["cmf4h2u170000pcnnkbr6rhwh", "cmf4h2u22000jpcnnxmplxtoy", "cmf4h2u1l0007pcnnn679uhv5", "cmf4h2u1i0005pcnnf9os4ctv", "cmf4h2u1x000gpcnn5wkt32te", "cmf4h2u2c000rpcnn37w506x3"]	servir	["Administración", "Tecnología", "Medios"]	10	1	agradecimiento	[]	[]	2025-09-10 15:55:59.281	2025-09-10 15:55:59.281	2025-09-10 15:55:59.281	50	50	f	50	0	f	\N	f	50	50	50	50	50	0
\.


--
-- TOC entry 4581 (class 0 OID 9480051)
-- Dependencies: 225
-- Data for Name: members; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.members (id, "firstName", "lastName", email, phone, address, city, state, "zipCode", "birthDate", "baptismDate", "membershipDate", "maritalStatus", gender, occupation, photo, notes, "churchId", "userId", "ministryId", "isActive", "spiritualGifts", "secondaryGifts", "spiritualCalling", "ministryPassion", "experienceLevel", "availabilityScore", "leadershipReadiness", "skillsMatrix", "personalityType", "transportationOwned", "childcareAvailable", "backgroundCheckDate", "emergencyContact", "createdAt", "updatedAt") FROM stdin;
cmeyt1tl10004q8xyln4xqjwt	Test	User	testuserzxerg65w@example.com	\N	\N	\N	\N	\N	\N	\N	2025-08-30 22:00:06.66	\N	\N	\N	\N	\N	cmeyt1tkw0000q8xyyr97bp74	cmeyt1tky0002q8xy011u77r7	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-08-30 22:00:06.661	2025-08-30 22:00:06.661
cmeytjgok0009q8fc9cvk8h87	Ana	Martínez	ana.martinez@email.com	+1234567801	Calle Ejemplo 456	Ciudad Ejemplo	Estado Ejemplo	12345	1985-03-15 00:00:00	2010-05-20 00:00:00	2010-06-01 00:00:00	casado	femenino	Enfermera	\N	\N	demo-church	\N	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-08-30 22:13:49.748	2025-08-30 22:13:49.748
cmeytjgom000bq8fcnvp6sn6u	Pedro	López	pedro.lopez@email.com	+1234567802	Calle Ejemplo 456	Ciudad Ejemplo	Estado Ejemplo	12345	1982-07-22 00:00:00	2008-12-14 00:00:00	2009-01-15 00:00:00	casado	masculino	Ingeniero	\N	\N	demo-church	\N	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-08-30 22:13:49.751	2025-08-30 22:13:49.751
cmeytjgoo000dq8fctigwv6sc	Sofia	García	sofia.garcia@email.com	+1234567803	Calle Ejemplo 456	Ciudad Ejemplo	Estado Ejemplo	12345	1990-11-08 00:00:00	2015-08-30 00:00:00	2015-09-15 00:00:00	soltero	femenino	Maestra	\N	\N	demo-church	\N	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-08-30 22:13:49.752	2025-08-30 22:13:49.752
cmeytjgoq000fq8fc9pyni8we	Miguel	Torres	miguel.torres@email.com	+1234567804	Calle Ejemplo 456	Ciudad Ejemplo	Estado Ejemplo	12345	1998-04-12 00:00:00	2020-02-16 00:00:00	2020-03-01 00:00:00	soltero	masculino	Estudiante	\N	\N	demo-church	\N	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-08-30 22:13:49.754	2025-08-30 22:13:49.754
cmeytjgor000hq8fct2xw3j65	Carmen	Rodríguez	carmen.rodriguez@email.com	+1234567805	Calle Ejemplo 456	Ciudad Ejemplo	Estado Ejemplo	12345	1955-09-28 00:00:00	1975-04-06 00:00:00	1975-05-01 00:00:00	viudo	femenino	Jubilada	\N	\N	demo-church	\N	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-08-30 22:13:49.756	2025-08-30 22:13:49.756
cmeytjgot000jq8fcj6k0yvkf	David	Hernández	david.hernandez@email.com	+1234567806	Calle Ejemplo 456	Ciudad Ejemplo	Estado Ejemplo	12345	1978-12-03 00:00:00	2012-10-21 00:00:00	2012-11-05 00:00:00	casado	masculino	Contador	\N	\N	demo-church	\N	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-08-30 22:13:49.758	2025-08-30 22:13:49.758
cmeytjgov000lq8fcnlwz6v5m	Lucía	Morales	lucia.morales@email.com	+1234567807	Calle Ejemplo 456	Ciudad Ejemplo	Estado Ejemplo	12345	1987-06-17 00:00:00	2018-07-15 00:00:00	2018-08-01 00:00:00	casado	femenino	Doctora	\N	\N	demo-church	\N	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-08-30 22:13:49.76	2025-08-30 22:13:49.76
cmeytjgox000nq8fcuc6hmdvf	Roberto	Jiménez	roberto.jimenez@email.com	+1234567808	Calle Ejemplo 456	Ciudad Ejemplo	Estado Ejemplo	12345	1992-01-25 00:00:00	2019-09-08 00:00:00	2019-10-01 00:00:00	soltero	masculino	Programador	\N	\N	demo-church	\N	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-08-30 22:13:49.761	2025-08-30 22:13:49.761
cmeytjgoz000pq8fcbtvgzby4	María	González	admin@iglesiacentral.com	+1234567890	Avenida Principal 789	Ciudad Ejemplo	Estado Ejemplo	12345	1980-05-10 00:00:00	2005-03-20 00:00:00	2005-04-01 00:00:00	casado	femenino	Administradora de Iglesia	\N	\N	demo-church	cmeytjgnx0001q8fctjc12b43	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-08-30 22:13:49.763	2025-08-30 22:13:49.763
cmeytjgp2000rq8fczh09q392	Carlos	Ruiz	pastor@iglesiacentral.com	+1234567891	Calle Pastoral 101	Ciudad Ejemplo	Estado Ejemplo	12345	1975-08-15 00:00:00	1995-06-10 00:00:00	2000-01-01 00:00:00	casado	masculino	Pastor Principal	\N	\N	demo-church	cmeytjgo50007q8fce5bou6vw	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-08-30 22:13:49.767	2025-08-30 22:13:49.767
cmeyulmqc0004q88u04h2hhs6	Test	User	testusersafef8ul@example.com	\N	\N	\N	\N	\N	\N	\N	2025-08-30 22:43:30.516	\N	\N	\N	\N	\N	cmeyulmq10000q88uarsz29du	cmeyulmq30002q88urqrs7sso	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-08-30 22:43:30.517	2025-08-30 22:43:30.517
cmeywekr90004q8jz2xiq19v7	Test	User	testuser2b653kof@example.com	\N	\N	\N	\N	\N	\N	\N	2025-08-30 23:34:00.596	\N	\N	\N	\N	\N	cmeywekr50000q8jzbj0r3u0c	cmeywekr70002q8jz299u8hx6	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-08-30 23:34:00.597	2025-08-30 23:34:00.597
cmeyxxtrd0004q8xoemqc9m8y	Test	User	testuser8fysugzj@example.com	\N	\N	\N	\N	\N	\N	\N	2025-08-31 00:16:58.344	\N	\N	\N	\N	\N	cmeyxxtr90000q8xonjxhcvar	cmeyxxtrb0002q8xo63p8quq5	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-08-31 00:16:58.345	2025-08-31 00:16:58.345
cmeyzngfq0004q8lea17ofcxe	Test	User	testuser95h124yl@example.com	\N	\N	\N	\N	\N	\N	\N	2025-08-31 01:04:53.75	\N	\N	\N	\N	\N	cmeyzngfn0000q8legh8qh70q	cmeyzngfp0002q8lenarome5b	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-08-31 01:04:53.751	2025-08-31 01:04:53.751
cmez0uqje0006q8e34bsnar97	Test	User	testusero0rh3sxs@example.com	\N	\N	\N	\N	\N	\N	\N	2025-08-31 01:38:33.05	\N	\N	\N	\N	\N	cmez0uqja0000q8e3wiqkv9jx	cmez0uqjd0004q8e3cgcx0bje	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-08-31 01:38:33.051	2025-08-31 01:38:33.051
cmez0yne3000dq8e3nmxa2jy0	Test	Admin	securetest@example.com	\N	\N	\N	\N	\N	\N	\N	2025-08-31 01:41:35.595	\N	\N	\N	\N	\N	cmez0yndy0007q8e3s9i3852m	cmez0yne2000bq8e3bds5v55t	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-08-31 01:41:35.596	2025-08-31 01:41:35.596
cmez0ysoy000kq8e3k64g7ln7	Test	Hacker	hacker@example.com	\N	\N	\N	\N	\N	\N	\N	2025-08-31 01:41:42.465	\N	\N	\N	\N	\N	cmez0ysov000eq8e399j8ucvk	cmez0ysox000iq8e3q54o4h0o	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-08-31 01:41:42.466	2025-08-31 01:41:42.466
cmez0yxq9000rq8e3uu2rvr1k	Test	Hacker	hacker2@example.com	\N	\N	\N	\N	\N	\N	\N	2025-08-31 01:41:48.992	\N	\N	\N	\N	\N	cmez0yxq6000lq8e3x5yi4otw	cmez0yxq8000pq8e3ubhwam9m	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-08-31 01:41:48.993	2025-08-31 01:41:48.993
cmez2v2z00006q8giva8opcqz	Test	User	testuserfvkx5grf@example.com	\N	\N	\N	\N	\N	\N	\N	2025-08-31 02:34:48.395	\N	\N	\N	\N	\N	cmez2v2yv0000q8gib6m58u6b	cmez2v2yy0004q8giogx2btbp	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-08-31 02:34:48.396	2025-08-31 02:34:48.396
cmez30ezj0006q86nlmri9z0g	Test	User	testuserx1avfqgm@example.com	\N	\N	\N	\N	\N	\N	\N	2025-08-31 02:38:57.247	\N	\N	\N	\N	\N	cmez30eze0000q86ntsvyk2iz	cmez30ezi0004q86nsajzeei9	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-08-31 02:38:57.248	2025-08-31 02:38:57.248
cmez33zdv000dq86ncxl776r9	Dynamic	User	dynamic@example.com	\N	\N	\N	\N	\N	\N	\N	2025-08-31 02:41:43.651	\N	\N	\N	\N	\N	cmez33zdr0007q86nr4tvl5ib	cmez33zdu000bq86n86p6l3sc	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-08-31 02:41:43.652	2025-08-31 02:41:43.652
cmez3tbep0006q8qsn3epv19g	Test	User	testuserjatf5ado@example.com	\N	\N	\N	\N	\N	\N	\N	2025-08-31 03:01:25.633	\N	\N	\N	\N	\N	cmez3tbek0000q8qsrgyoaknu	cmez3tbeo0004q8qsuiku97bf	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-08-31 03:01:25.633	2025-08-31 03:01:25.633
cmf1c9n7a0006s8wfr0kiwl2w	Test	User	testuserunlw4ss4@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-01 16:33:36.693	\N	\N	\N	\N	\N	cmf1c9n6w0000s8wf57x68925	cmf1c9n760004s8wf7chikz3d	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-01 16:33:36.694	2025-09-01 16:33:36.694
cmf1cyh4z0006s8vh7bax2j87	Test	User	testusery4n0qu6u@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-01 16:52:55.234	\N	\N	\N	\N	\N	cmf1cyh4t0000s8vh9p0cerql	cmf1cyh4x0004s8vhu11evdtw	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-01 16:52:55.235	2025-09-01 16:52:55.235
cmf1euc2m0006s8e8qwhtz1vp	Test	User	testusero0yfg4gu@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-01 17:45:41.278	\N	\N	\N	\N	\N	cmf1euc2f0000s8e8xk8pw7d9	cmf1euc2l0004s8e8t1ga8pag	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-01 17:45:41.279	2025-09-01 17:45:41.279
cmf1flwvn0006s84og5s55n62	Test	User	testuser3dt7kv7j@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-01 18:07:07.955	\N	\N	\N	\N	\N	cmf1flwvf0000s84oop1aeh96	cmf1flwvl0004s84ov0htth73	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-01 18:07:07.956	2025-09-01 18:07:07.956
cmf1gcbtn0006s8mp7qlomyiy	Test	User	testuserzofpgxao@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-01 18:27:40.379	\N	\N	\N	\N	\N	cmf1gcbtg0000s8mpc4skc5rg	cmf1gcbtl0004s8mpvq47tw5j	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-01 18:27:40.38	2025-09-01 18:27:40.38
cmf1jo2tn0006p2nv3k38dzx6	Test	User	testuser75zozdpq@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-01 20:00:47.435	\N	\N	\N	\N	\N	cmf1jo2tc0000p2nv3nbzeape	cmf1jo2tl0004p2nvzfrg1uvc	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-01 20:00:47.435	2025-09-01 20:00:47.435
cmf1kqq890006p2gqlc29o3gf	Test	User	testuser5memlw9c@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-01 20:30:50.696	\N	\N	\N	\N	\N	cmf1kqq810000p2gq6eacddjl	cmf1kqq850004p2gqggytnxgk	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-01 20:30:50.697	2025-09-01 20:30:50.697
cmf1mfqce0006m2q16mlcufwe	Test	User	testuser8m6du67a@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-01 21:18:16.861	\N	\N	\N	\N	\N	cmf1mfqc60000m2q1k2g3md5b	cmf1mfqcb0004m2q1a3l5lce5	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-01 21:18:16.862	2025-09-01 21:18:16.862
cmf1nzgzw0006m2laa7ups8mx	Test	User	testuserprvlnnuo@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-01 22:01:37.483	\N	\N	\N	\N	\N	cmf1nzgzm0000m2ladrdl8007	cmf1nzgzs0004m2lazg7xpkl5	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-01 22:01:37.484	2025-09-01 22:01:37.484
cmf1ojkee0006m20o8j145ob9	Test	User	testusernvfvl8xs@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-01 22:17:15.014	\N	\N	\N	\N	\N	cmf1ojke60000m20o274v44ch	cmf1ojkec0004m20oay0mo82g	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-01 22:17:15.015	2025-09-01 22:17:15.015
cmf1p8blu0006m2qgcgmzd8nj	Test	User	testuser18p18myb@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-01 22:36:30.018	\N	\N	\N	\N	\N	cmf1p8blo0000m2qg06rvrow4	cmf1p8bls0004m2qgd3hx3c43	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-01 22:36:30.019	2025-09-01 22:36:30.019
cmf1q0nn60006m2g9m0mjiihx	Test	User	testuserf5nfjoyd@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-01 22:58:31.986	\N	\N	\N	\N	\N	cmf1q0nmy0000m2g97d1xzdx1	cmf1q0nn40004m2g9zoe6ap0v	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-01 22:58:31.987	2025-09-01 22:58:31.987
cmf1qpumq0006m2zugkc4yp1z	Test	User	testuserx0k6enav@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-01 23:18:07.442	\N	\N	\N	\N	\N	cmf1qpumf0000m2zuk31kulwc	cmf1qpumn0004m2zue4x50h0r	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-01 23:18:07.442	2025-09-01 23:18:07.442
cmf1ri0vq0006m2j64p046tke	Test	User	testuserzycd9jgw@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-01 23:40:01.91	\N	\N	\N	\N	\N	cmf1ri0vj0000m2j6ic7bjkmi	cmf1ri0vo0004m2j6udkou737	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-01 23:40:01.91	2025-09-01 23:40:01.91
cmf1s66fo0006of01eln2frf4	Nelson	Castro	saviatek.ia@gmail.com	\N	\N	\N	\N	\N	\N	\N	2025-09-01 23:58:48.852	\N	\N	\N	\N	\N	cmf1s66fe0000of019relorwd	cmf1s66fl0004of01jghyqn9j	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-01 23:58:48.853	2025-09-01 23:58:48.853
cmf2lzzed0006q7z8i33wma3e	Test	User	testuser3c111a1b@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-02 13:53:48.277	\N	\N	\N	\N	\N	cmf2lzzdq0000q7z8kkfwdmol	cmf2lzze80004q7z8cyx2qfj3	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-02 13:53:48.278	2025-09-02 13:53:48.278
cmf2nf3dt0006q7qzbujsuuse	Test	User	testuserruziv3ge@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-02 14:33:32.896	\N	\N	\N	\N	\N	cmf2nf3dd0000q7qzpg7bbuwz	cmf2nf3dp0004q7qzdl6cmew1	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-02 14:33:32.897	2025-09-02 14:33:32.897
cmf2o64sp0006q7hmn47nkavs	Test	User	testuserm1inci4k@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-02 14:54:34.441	\N	\N	\N	\N	\N	cmf2o64sb0000q7hmquald4hd	cmf2o64sk0004q7hm8c9vc0k3	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-02 14:54:34.442	2025-09-02 14:54:34.442
cmf2owxc20006q74h8o3sril6	Test	User	testuserjfnco12u@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-02 15:15:24.481	\N	\N	\N	\N	\N	cmf2owxbq0000q74hhyfjnsy0	cmf2owxbz0004q74h98qo2zdo	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-02 15:15:24.482	2025-09-02 15:15:24.482
cmf2px4jp0006q7ppjk0lrgdi	Test	User	testuserb49m87je@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-02 15:43:33.444	\N	\N	\N	\N	\N	cmf2px4jc0000q7pph68odq7g	cmf2px4jm0004q7ppsxn8v5ro	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-02 15:43:33.445	2025-09-02 15:43:33.445
cmf2rb4s70006q77604md6rtp	Test	User	testuserdmaf4tlw@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-02 16:22:26.55	\N	\N	\N	\N	\N	cmf2rb4ru0000q7763rck0uwj	cmf2rb4s40004q776tsngfsmy	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-02 16:22:26.551	2025-09-02 16:22:26.551
cmf2tg73f0006ntov5hpcae8c	Test	User	testuserqctgsfuc@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-02 17:22:22.058	\N	\N	\N	\N	\N	cmf2tg72q0000ntovxmk4l8ti	cmf2tg7380004ntovupluuhg7	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-02 17:22:22.059	2025-09-02 17:22:22.059
cmf2uaqxx0006ntbffbflc02q	Test	User	testuser7nqztvhe@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-02 17:46:07.461	\N	\N	\N	\N	\N	cmf2uaqxn0000ntbfywax1quq	cmf2uaqxu0004ntbfk1rvdzpl	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-02 17:46:07.462	2025-09-02 17:46:07.462
cmf2vfy8x0006nt4g4csfpxs9	Test	User	testuser4y6s4tq9@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-02 18:18:09.825	\N	\N	\N	\N	\N	cmf2vfy8l0000nt4gc5gz994q	cmf2vfy8u0004nt4gq6kg5lj1	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-02 18:18:09.826	2025-09-02 18:18:09.826
cmf2wunac0006nt0o1tdcqe9q	Test	User	testuserzgpwvfnt@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-02 18:57:35.075	\N	\N	\N	\N	\N	cmf2wun9w0000nt0oswz1q6px	cmf2wuna60004nt0ovhevs55l	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-02 18:57:35.076	2025-09-02 18:57:35.076
cmf30f6pz0006vvonr1dgxmg9	Test	User	testuser03plhzzt@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-02 20:37:32.231	\N	\N	\N	\N	\N	cmf30f6pg0000vvoni6r15qoh	cmf30f6pt0004vvono9yqoo1d	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-02 20:37:32.231	2025-09-02 20:37:32.231
cmf318t6q0006vv7wpbj3fmhg	Test	User	testusernkvb4rk7@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-02 21:00:34.369	\N	\N	\N	\N	\N	cmf318t6f0000vv7w2f1muqzg	cmf318t6n0004vv7woxb6c3wr	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-02 21:00:34.37	2025-09-02 21:00:34.37
cmf32jnx30006vv3jgtp2xftu	Test	User	testuserbqq8jgp8@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-02 21:37:00.375	\N	\N	\N	\N	\N	cmf32jnwo0000vv3jilchdgw8	cmf32jnwy0004vv3j5u43e47h	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-02 21:37:00.376	2025-09-02 21:37:00.376
cmf341qgh0006vv72z4ijs2ho	Test	User	testuserrp400i0q@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-02 22:19:03.089	\N	\N	\N	\N	\N	cmf341qg40000vv723fg9he77	cmf341qge0004vv72atozt4dx	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-02 22:19:03.09	2025-09-02 22:19:03.09
cmf34o6tj0006vvrngohiugus	Test	User	testuserhg6stzwo@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-02 22:36:30.727	\N	\N	\N	\N	\N	cmf34o6td0000vvrndejb7y2p	cmf34o6th0004vvrnkkiu34qh	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-02 22:36:30.728	2025-09-02 22:36:30.728
cmf5lu9aa0006s7m6nyiom6pt	Test	User	testuserhr40pccw@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-04 16:12:39.681	\N	\N	\N	\N	\N	cmf5lu99r0000s7m69navda79	cmf5lu9a40004s7m6ruzwronq	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-04 16:12:39.682	2025-09-04 16:12:39.682
cmf35jn7e0006vvub9jq4lrqq	Test	User	testuser9woizi4h@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-02 23:00:58.298	\N	\N	\N	\N	\N	cmf35jn730000vvubhnnw4oxz	cmf35jn7b0004vvuby7hm92fi	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-02 23:00:58.298	2025-09-02 23:00:58.298
cmf35rkjp0006vvjtxuk4ol6f	Test	User	testuser0yj001j4@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-02 23:07:08.101	\N	\N	\N	\N	\N	cmf35rkjj0000vvjt4pwsy0dz	cmf35rkjo0004vvjtwx1149x0	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-02 23:07:08.102	2025-09-02 23:07:08.102
cmf4an4q50006uqr2dtup1b5x	Test	User	testuserwzrr8tot@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-03 18:11:25.228	\N	\N	\N	\N	\N	cmf4an4pq0000uqr2r3vrslq2	cmf4an4q00004uqr2zenuktcn	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-03 18:11:25.229	2025-09-03 18:11:25.229
cmf36kgan0006vv929uozhod1	Test	User	testuserz7b35k3f@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-02 23:29:35.615	\N	\N	\N	\N	\N	cmf36kgah0000vv92dg716icf	cmf36kgal0004vv92yogrme7d	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-02 23:29:35.616	2025-09-02 23:29:35.616
cmf4befuq0006uqblmc8ca373	Test	User	testuserfbnmn2zd@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-03 18:32:39.362	\N	\N	\N	\N	\N	cmf4befuj0000uqblsubhki3k	cmf4befuo0004uqbl6y4c5pup	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-03 18:32:39.362	2025-09-03 18:32:39.362
cmf474kow0006uqzvhln2b67e	Test	User	testuserkh9lm4gh@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-03 16:33:00.608	\N	\N	\N	\N	\N	cmf474koj0000uqzvlrfoxqtm	cmf474kot0004uqzv36d1rxov	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-03 16:33:00.609	2025-09-03 16:33:00.609
cmf2zrjok0001qt01lpqehwa4	JUAN 	PACHANGA							1988-04-29 00:00:00	2020-01-02 00:00:00	2025-09-02 00:00:00			RUMBERO	\N		demo-church	\N	\N	t	["cmf4h2u1s000cpcnnbjyidp3d", "cmf4h2u1f0003pcnnzbmuvuf6", "cmf4h2u1c0001pcnn7p99f6ee", "cmf4h2u1x000gpcnn5wkt32te", "cmf4h2u20000ipcnnmr64xzj4", "cmf4h2u1m0008pcnn7t2exocb", "cmf4h2u26000mpcnnobihclkw", "cmf4h2u25000lpcnnxnftzg79"]	["cmf4h2u170000pcnnkbr6rhwh", "cmf4h2u1r000bpcnndj4ykn7r", "cmf4h2u1i0005pcnnf9os4ctv", "cmf4h2u1w000fpcnn1qd0g4xn", "cmf4h2u22000jpcnnxmplxtoy", "cmf4h2u23000kpcnn5rk09vll", "cmf4h2u1p000apcnn57kkpkns", "cmf4h2u27000npcnn1ip6rckz"]	EN MI RELACIÓN PERSONAL CON EL	["Administración", "Tecnología", "Medios"]	9	0	1	\N	\N	f	f	\N	\N	2025-09-02 20:19:09.283	2025-09-03 21:23:54.935
cmf47wdkg0006uqos6jutlq82	Test	User	testuserz77hub6v@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-03 16:54:37.744	\N	\N	\N	\N	\N	cmf47wdk60000uqos0lkwharm	cmf47wdke0004uqost7eol10f	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-03 16:54:37.744	2025-09-03 16:54:37.744
cmf5jm5i40006s7ms7k2039ps	Test	User	testuserhmo9le82@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-04 15:10:22.299	\N	\N	\N	\N	\N	cmf5jm5hl0000s7mstbgeeqmq	cmf5jm5hz0004s7ms2cxdt6xe	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-04 15:10:22.3	2025-09-04 15:10:22.3
cmf48k96f0006uq91aamsiir6	Test	User	testuser2tyjn47r@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-03 17:13:11.798	\N	\N	\N	\N	\N	cmf48k9650000uq91bnx3l1ma	cmf48k96c0004uq91jtqy9355	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-03 17:13:11.799	2025-09-03 17:13:11.799
cmf5jyxt20006s7nl2sv6vjrj	Test	User	testuser4uq41lam@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-04 15:20:18.854	\N	\N	\N	\N	\N	cmf5jyxsw0000s7nlvukvas4x	cmf5jyxt10004s7nllf6ca0gi	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-04 15:20:18.855	2025-09-04 15:20:18.855
cmf49g0vf0006uqpi6f0ir1ih	Test	User	testuser7b235mfh@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-03 17:37:54.026	\N	\N	\N	\N	\N	cmf49g0v50000uqpiv19hw43t	cmf49g0vc0004uqpistrlzzec	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-03 17:37:54.027	2025-09-03 17:37:54.027
cmf5mgtfa0006s71yuxf0u5tp	Test	User	testuserpfos8hab@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-04 16:30:12.213	\N	\N	\N	\N	\N	cmf5mgtf20000s71ymce0bf3w	cmf5mgtf70004s71yg72c37lh	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-04 16:30:12.214	2025-09-04 16:30:12.214
cmf4a1dqy0006uq9n9855rpiz	Test	User	testuserg8o6in3k@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-03 17:54:30.49	\N	\N	\N	\N	\N	cmf4a1dqs0000uq9npv695x49	cmf4a1dqw0004uq9nba8v3wkt	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-03 17:54:30.491	2025-09-03 17:54:30.491
cmf5o3qv60006s78rhcc660tn	Test	User	testuser1pl0zw46@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-04 17:16:01.599	\N	\N	\N	\N	\N	cmf5o3qut0000s78rgnu9t0ad	cmf5o3quy0004s78razkcvbx8	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-04 17:16:01.603	2025-09-04 17:16:01.603
cmf5w9nqd0006vgrpt06jpsas	Test	User	testuser05oynv59@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-04 21:04:34.405	\N	\N	\N	\N	\N	cmf5w9nq10000vgrptiufiw9h	cmf5w9nqb0004vgrp4qnag1qd	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-04 21:04:34.406	2025-09-04 21:04:34.406
cmf5xcqeo0006vgkoixxc911a	Test	User	testuserr45livxe@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-04 21:34:57.456	\N	\N	\N	\N	\N	cmf5xcqeh0000vgkovh9xdwem	cmf5xcqel0004vgkommke1h0l	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-04 21:34:57.456	2025-09-04 21:34:57.456
cmf5y3lmv0006vgv9dxujxent	Test	User	testuser5glsoruk@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-04 21:55:50.983	\N	\N	\N	\N	\N	cmf5y3lmp0000vgv9am7u3vz5	cmf5y3lmt0004vgv9o5lxelwt	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-04 21:55:50.983	2025-09-04 21:55:50.983
cmf76ch1b0009ugjfx5mjzfpb	Ana	Martínez	ana.martinez@email.com	+1234567801	Calle Ejemplo 456	Ciudad Ejemplo	Estado Ejemplo	12345	1985-03-15 00:00:00	2010-05-20 00:00:00	2010-06-01 00:00:00	casado	femenino	Enfermera	\N	\N	demo-church	\N	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-05 18:34:28.031	2025-09-05 18:34:28.031
cmf76ch1g000bugjf3rsuewh0	Pedro	López	pedro.lopez@email.com	+1234567802	Calle Ejemplo 456	Ciudad Ejemplo	Estado Ejemplo	12345	1982-07-22 00:00:00	2008-12-14 00:00:00	2009-01-15 00:00:00	casado	masculino	Ingeniero	\N	\N	demo-church	\N	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-05 18:34:28.036	2025-09-05 18:34:28.036
cmf76ch1i000dugjfcpgf5ciw	Sofia	García	sofia.garcia@email.com	+1234567803	Calle Ejemplo 456	Ciudad Ejemplo	Estado Ejemplo	12345	1990-11-08 00:00:00	2015-08-30 00:00:00	2015-09-15 00:00:00	soltero	femenino	Maestra	\N	\N	demo-church	\N	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-05 18:34:28.039	2025-09-05 18:34:28.039
cmf76ch1k000fugjfjb1xk65k	Miguel	Torres	miguel.torres@email.com	+1234567804	Calle Ejemplo 456	Ciudad Ejemplo	Estado Ejemplo	12345	1998-04-12 00:00:00	2020-02-16 00:00:00	2020-03-01 00:00:00	soltero	masculino	Estudiante	\N	\N	demo-church	\N	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-05 18:34:28.041	2025-09-05 18:34:28.041
cmf76ch1m000hugjf2r3hkr2h	Carmen	Rodríguez	carmen.rodriguez@email.com	+1234567805	Calle Ejemplo 456	Ciudad Ejemplo	Estado Ejemplo	12345	1955-09-28 00:00:00	1975-04-06 00:00:00	1975-05-01 00:00:00	viudo	femenino	Jubilada	\N	\N	demo-church	\N	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-05 18:34:28.043	2025-09-05 18:34:28.043
cmf76ch1p000jugjfjnipq8qd	David	Hernández	david.hernandez@email.com	+1234567806	Calle Ejemplo 456	Ciudad Ejemplo	Estado Ejemplo	12345	1978-12-03 00:00:00	2012-10-21 00:00:00	2012-11-05 00:00:00	casado	masculino	Contador	\N	\N	demo-church	\N	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-05 18:34:28.045	2025-09-05 18:34:28.045
cmf76ch1r000lugjfrv8nchlt	Lucía	Morales	lucia.morales@email.com	+1234567807	Calle Ejemplo 456	Ciudad Ejemplo	Estado Ejemplo	12345	1987-06-17 00:00:00	2018-07-15 00:00:00	2018-08-01 00:00:00	casado	femenino	Doctora	\N	\N	demo-church	\N	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-05 18:34:28.047	2025-09-05 18:34:28.047
cmf76r2xb0006ug016o168wmy	Test	User	testusersp2z60zb@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-05 18:45:49.583	\N	\N	\N	\N	\N	cmf76r2x00000ug01ao08qy8m	cmf76r2x90004ug01gu81kvxt	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-05 18:45:49.584	2025-09-05 18:45:49.584
cmf77xx0l0006ug7zbnpryk3q	Test	User	testuser9n6nmnub@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-05 19:19:08.132	\N	\N	\N	\N	\N	cmf77xx090000ug7zfogto5zs	cmf77xx0h0004ug7zysacjkgc	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-05 19:19:08.133	2025-09-05 19:19:08.133
cmf7b8e7c0006vubo2z4pwbwe	Test	User	testuser6b33rmgy@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-05 20:51:15.816	\N	\N	\N	\N	\N	cmf7b8e730000vubolitp5wub	cmf7b8e7a0004vubo6ha6kjiu	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-05 20:51:15.817	2025-09-05 20:51:15.817
cmf8g5nk20006wm85hkfziol5	Test	User	testusera8880naj@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-06 15:56:52.226	\N	\N	\N	\N	\N	cmf8g5njq0000wm851h777hnb	cmf8g5njz0004wm85ika2ru6m	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-06 15:56:52.227	2025-09-06 15:56:52.227
cmf8jgltw0006wmkz56fk44ku	Test	User	testuserzcu4ddul@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-06 17:29:22.051	\N	\N	\N	\N	\N	cmf8jglte0000wmkzim9zee72	cmf8jgltq0004wmkztpijorgj	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-06 17:29:22.052	2025-09-06 17:29:22.052
cmf8l2j8x0006zozz49xwzorp	Test	User	testuseropogkkrl@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-06 18:14:24.752	\N	\N	\N	\N	\N	cmf8l2j8l0000zozzbth9kmum	cmf8l2j8t0004zozzaq5r4nkb	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-06 18:14:24.753	2025-09-06 18:14:24.753
cmf8m09xf0006zol23zc36tqe	Test	User	testuser4ov75bfy@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-06 18:40:38.979	\N	\N	\N	\N	\N	cmf8m09x30000zol2oia50lkd	cmf8m09xc0004zol2ydc81v2g	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-06 18:40:38.98	2025-09-06 18:40:38.98
cmf8nkc7c0006zobhuw9c4znd	Test	User	testusereoy3ir7y@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-06 19:24:14.664	\N	\N	\N	\N	\N	cmf8nkc6y0000zobhy1ybl7hk	cmf8nkc790004zobhq4n0ntu2	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-06 19:24:14.665	2025-09-06 19:24:14.665
cmf8olija0006zow4oqkn1wma	Test	User	testuserc795l7q7@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-06 19:53:09.141	\N	\N	\N	\N	\N	cmf8oliiw0000zow4q4zq31ez	cmf8olij60004zow4r1ijv63b	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-06 19:53:09.142	2025-09-06 19:53:09.142
cmf8qt53300060hqrcxjvmabx	Test	User	testuser7sr4vmzx@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-06 20:55:04.19	\N	\N	\N	\N	\N	cmf8qt52p00000hqreyjwk5al	cmf8qt52z00040hqrxxc7kzxk	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-06 20:55:04.191	2025-09-06 20:55:04.191
cmf8rb9440004mt01bop80i7d	PEDRO	CARRERA	PEDROCARRERA@GMAIL.COM	7877555555	\N	\N	\N	\N	\N	\N	2025-09-06 21:09:09.219	\N	\N	\N	\N	\N	cmf8rb8v60000mt0148xslbte	cmf8rb93y0002mt01krrj2h2i	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-06 21:09:09.22	2025-09-06 21:09:09.22
cmf8se6jk00060hrdk1yza6tg	Test	User	testuserd3hruwvn@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-06 21:39:25.471	\N	\N	\N	\N	\N	cmf8se6j700000hrdcsgpog77	cmf8se6jg00040hrdwvqrmqsw	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-06 21:39:25.472	2025-09-06 21:39:25.472
cmf8tfub800060hp182ayxhqt	Test	User	testuser26wdw5m4@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-06 22:08:42.548	\N	\N	\N	\N	\N	cmf8tfuaw00000hp1oen710io	cmf8tfub500040hp15c8ne7vv	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-06 22:08:42.548	2025-09-06 22:08:42.548
cmf8tw0j200060he14099bmm5	Test	User	testuserrv3inksy@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-06 22:21:17.102	\N	\N	\N	\N	\N	cmf8tw0iv00000he1hsz6dsju	cmf8tw0j000040he1ioisk2dh	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-06 22:21:17.103	2025-09-06 22:21:17.103
cmf8udnky0004s101gowiwrmf	TONY	PILARTE	tonypilarte@gmail.com	8474068956	\N	\N	\N	\N	\N	\N	2025-09-06 22:35:00.13	\N	\N	\N	\N	\N	cmf8udnbz0000s101ohl648q7	cmf8udnku0002s101efrwt89o	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-06 22:35:00.131	2025-09-06 22:35:00.131
cmf8vhaxd00060h4997ns11ew	Test	User	testuserzin8wqmi@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-06 23:05:49.968	\N	\N	\N	\N	\N	cmf8vhax200000h49hwrlwkdt	cmf8vhaxa00040h49izdznzpf	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-06 23:05:49.969	2025-09-06 23:05:49.969
cmf8vpiqq00060hl39yzgkb9a	Test	User	testuser5nt3htkw@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-06 23:12:13.345	\N	\N	\N	\N	\N	cmf8vpiqk00000hl309k0bgkh	cmf8vpiqo00040hl3troihuhi	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-06 23:12:13.346	2025-09-06 23:12:13.346
cmf8x48zs00060hlxalrucrtb	Test	User	testuser58lxhn98@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-06 23:51:40.167	\N	\N	\N	\N	\N	cmf8x48zg00000hlxgyjpc7e0	cmf8x48zo00040hlxwguog6hm	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-06 23:51:40.168	2025-09-06 23:51:40.168
cmfbf4e0j0006tyrpqdad09c0	Test	User	testuser8l3xnyvn@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-08 17:51:12.115	\N	\N	\N	\N	\N	cmfbf4e020000tyrpgns0kbnq	cmfbf4e0f0004tyrp9t6e37s8	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-08 17:51:12.116	2025-09-08 17:51:12.116
cmfbfxla40006tybmu92pk8ay	Test	User	testuserxrmhq8dm@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-08 18:13:54.555	\N	\N	\N	\N	\N	cmfbfxl9q0000tybm5bfrp0mc	cmfbfxla00004tybmrpkk9hz2	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-08 18:13:54.556	2025-09-08 18:13:54.556
cmfbmddi60006uyyzw2jyjq7n	Test	User	testuser1yvruf1d@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-08 21:14:08.669	\N	\N	\N	\N	\N	cmfbmddhx0000uyyzzgmhz09z	cmfbmddi30004uyyztt4kp4gw	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-08 21:14:08.67	2025-09-08 21:14:08.67
cmfbnh7t70006uylnvq2wt8lz	Test	User	testuser29229t3p@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-08 21:45:07.531	\N	\N	\N	\N	\N	cmfbnh7sv0000uylnq5rdr1qp	cmfbnh7t40004uylnxhovzmsj	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-08 21:45:07.531	2025-09-08 21:45:07.531
cmfbocb0u0006uynz2qgaircb	Test	User	testuser663wtknw@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-08 22:09:18.03	\N	\N	\N	\N	\N	cmfbocb0p0000uynz5m7l3i6s	cmfbocb0t0004uynzu2mfqr65	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-08 22:09:18.031	2025-09-08 22:09:18.031
cmfbp2ui20006uywtkvrir2wp	Test	User	testusersf16e6ah@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-08 22:29:56.33	\N	\N	\N	\N	\N	cmfbp2uhv0000uywtp2b8d1wn	cmfbp2ui00004uywtwcf6ihnk	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-08 22:29:56.331	2025-09-08 22:29:56.331
cmf76ch1t000nugjfxhh83umo	Roberto	Jiménez	roberto.jimenez@email.com	+1234567808	Calle Ejemplo 456	Ciudad Ejemplo	Estado Ejemplo	12345	1992-01-25 00:00:00	2019-09-08 00:00:00	2019-10-01 00:00:00	soltero	masculino	Programador	\N	\N	demo-church	\N	\N	t	["cmf4h2u1c0001pcnn7p99f6ee", "cmf4h2u23000kpcnn5rk09vll", "cmf4h2u1m0008pcnn7t2exocb", "cmf4h2u1f0003pcnnzbmuvuf6", "cmf4h2u1w000fpcnn1qd0g4xn", "cmf4h2u2a000ppcnn2eeok3he", "cmf4h2u26000mpcnnobihclkw", "cmf4h2u25000lpcnnxnftzg79", "cmf4h2u27000npcnn1ip6rckz"]	["cmf4h2u170000pcnnkbr6rhwh", "cmf4h2u22000jpcnnxmplxtoy", "cmf4h2u1l0007pcnnn679uhv5", "cmf4h2u1i0005pcnnf9os4ctv", "cmf4h2u1x000gpcnn5wkt32te", "cmf4h2u2c000rpcnn37w506x3"]	servir	["Administración", "Tecnología", "Medios"]	10	0	1	\N	\N	f	f	\N	\N	2025-09-05 18:34:28.049	2025-09-10 15:55:59.294
cmfh1xpb00006vux1kkeil9b2	Test	User	testuserzmih6oxi@example.com	\N	\N	\N	\N	\N	\N	\N	2025-09-12 16:28:42.204	\N	\N	\N	\N	\N	cmfh1xpac0000vux1gz7o2nwp	cmfh1xpat0004vux17ltnpkex	\N	t	\N	\N	\N	\N	1	0	1	\N	\N	f	f	\N	\N	2025-09-12 16:28:42.204	2025-09-12 16:28:42.204
\.


--
-- TOC entry 4574 (class 0 OID 9479986)
-- Dependencies: 218
-- Data for Name: ministries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ministries (id, name, description, "churchId", "isActive", "createdAt", "updatedAt") FROM stdin;
ministry-ministerio-de-jóvenes	Ministerio de Jóvenes	Para jóvenes de 15-35 años	demo-church	t	2025-08-30 22:13:49.736	2025-08-30 22:13:49.736
ministry-ministerio-de-niños	Ministerio de Niños	Para niños de 3-12 años	demo-church	t	2025-08-30 22:13:49.739	2025-08-30 22:13:49.739
ministry-ministerio-de-alabanza	Ministerio de Alabanza	Equipo de música y adoración	demo-church	t	2025-08-30 22:13:49.741	2025-08-30 22:13:49.741
ministry-ministerio-de-evangelismo	Ministerio de Evangelismo	Alcance comunitario y misiones	demo-church	t	2025-08-30 22:13:49.744	2025-08-30 22:13:49.744
ministry-ministerio-de-matrimonios	Ministerio de Matrimonios	Apoyo a parejas casadas	demo-church	t	2025-08-30 22:13:49.746	2025-08-30 22:13:49.746
\.


--
-- TOC entry 4657 (class 0 OID 9480855)
-- Dependencies: 301
-- Data for Name: ministry_gap_analyses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ministry_gap_analyses (id, "ministryId", "churchId", "analysisDate", "gapsIdentified", "urgencyScore", "recommendedActions", "currentStaffing", "optimalStaffing", "gapPercentage", "seasonalFactor", status, "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4593 (class 0 OID 9480182)
-- Dependencies: 237
-- Data for Name: notification_preferences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification_preferences (id, "userId", "emailEnabled", "emailEvents", "emailDonations", "emailCommunications", "emailSystemUpdates", "inAppEnabled", "inAppEvents", "inAppDonations", "inAppCommunications", "inAppSystemUpdates", "pushEnabled", "pushEvents", "pushDonations", "pushCommunications", "pushSystemUpdates", "quietHoursEnabled", "quietHoursStart", "quietHoursEnd", "weekendNotifications", "digestEnabled", "digestFrequency", "createdAt", "updatedAt") FROM stdin;
cmeyt30x90008q8xyrw2h94hx	cmeyt1tt30006q8xyi98u4d5x	t	t	t	t	t	t	t	t	t	t	f	t	f	t	t	f	\N	\N	t	f	DAILY	2025-08-30 22:01:02.829	2025-08-30 22:01:02.829
cmf1c6b7k0001pd01xugatf60	cmeytjgo10003q8fcortp6k60	t	t	t	t	t	t	t	t	t	t	f	t	f	t	t	t	00:00	12:00	t	f	DAILY	2025-09-01 16:31:01.184	2025-09-01 16:34:28.537
cmfffaqrd0001qs01hxcunvze	cmeytjgnx0001q8fctjc12b43	t	t	t	t	t	t	t	t	t	t	f	t	f	t	t	f	\N	\N	t	f	DAILY	2025-09-11 13:07:13.273	2025-09-11 13:07:13.273
\.


--
-- TOC entry 4594 (class 0 OID 9480209)
-- Dependencies: 238
-- Data for Name: notification_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification_templates (id, name, description, category, type, priority, "titleTemplate", "messageTemplate", "actionLabel", "isActive", "isSystem", "defaultTargetRole", "churchId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4592 (class 0 OID 9480171)
-- Dependencies: 236
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, title, message, type, category, "targetRole", "targetUser", "isRead", "isGlobal", priority, "actionUrl", "actionLabel", "expiresAt", "churchId", "createdBy", "createdAt", "updatedAt") FROM stdin;
cmf1jq06d0001pk01v42fk9xh	Usuario actualizado por SUPER_ADMIN	Usuario Test User actualizado	info	\N	\N	\N	f	f	NORMAL	\N	\N	\N	cmf1jo2tc0000p2nv3nbzeape	\N	2025-09-01 20:02:17.318	2025-09-01 20:02:17.318
cmf1jqdj20003pk01shjew6td	Usuario actualizado por SUPER_ADMIN	Usuario Test User actualizado	info	\N	\N	\N	f	f	NORMAL	\N	\N	\N	cmf1gcbtg0000s8mpc4skc5rg	\N	2025-09-01 20:02:34.623	2025-09-01 20:02:34.623
cmf1jqjj80005pk01yp2bpq4p	Usuario actualizado por SUPER_ADMIN	Usuario Test User actualizado	info	\N	\N	\N	f	f	NORMAL	\N	\N	\N	cmf1flwvf0000s84oop1aeh96	\N	2025-09-01 20:02:42.404	2025-09-01 20:02:42.404
cmf1jqmdm0007pk01erhw5hks	Usuario actualizado por SUPER_ADMIN	Usuario Test User actualizado	info	\N	\N	\N	f	f	NORMAL	\N	\N	\N	cmf1euc2f0000s8e8xk8pw7d9	\N	2025-09-01 20:02:46.091	2025-09-01 20:02:46.091
cmf1jqq050009pk01i531hmnu	Usuario actualizado por SUPER_ADMIN	Usuario Test User actualizado	info	\N	\N	\N	f	f	NORMAL	\N	\N	\N	cmf1cyh4t0000s8vh9p0cerql	\N	2025-09-01 20:02:50.79	2025-09-01 20:02:50.79
cmf1jqw0t000bpk01mfcz5g79	Usuario actualizado por SUPER_ADMIN	Usuario Test User actualizado	info	\N	\N	\N	f	f	NORMAL	\N	\N	\N	cmf1c9n6w0000s8wf57x68925	\N	2025-09-01 20:02:58.59	2025-09-01 20:02:58.59
cmf8rb9490006mt017mqiwoh5	Nueva iglesia creada	Iglesia "DEFENSORES DE LA FE" creada por SUPER_ADMIN	info	\N	\N	\N	f	f	NORMAL	\N	\N	\N	cmf8rb8v60000mt0148xslbte	\N	2025-09-06 21:09:09.226	2025-09-06 21:09:09.226
cmf8udnl20006s101w5akq4sy	Nueva iglesia creada	Iglesia "REBAÑO COMPAÑERISMO CRISTIANO (ARLINGTON)" creada por SUPER_ADMIN	info	\N	\N	\N	f	f	NORMAL	\N	\N	\N	cmf8udnbz0000s101ohl648q7	\N	2025-09-06 22:35:00.135	2025-09-06 22:35:00.135
cmf8y21wc0001qv018cwo8bav	Usuario actualizado por SUPER_ADMIN	Usuario Test User actualizado	info	\N	\N	\N	f	f	NORMAL	\N	\N	\N	cmf8oliiw0000zow4q4zq31ez	\N	2025-09-07 00:17:57.277	2025-09-07 00:17:57.277
cmf8y2b9y0003qv01jutgh3yn	Usuario actualizado por SUPER_ADMIN	Usuario Test User actualizado	info	\N	\N	\N	f	f	NORMAL	\N	\N	\N	cmf8qt52p00000hqreyjwk5al	\N	2025-09-07 00:18:09.43	2025-09-07 00:18:09.43
\.


--
-- TOC entry 4640 (class 0 OID 9480679)
-- Dependencies: 284
-- Data for Name: online_payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.online_payments (id, "paymentId", amount, currency, "gatewayType", status, "donorName", "donorEmail", "donorPhone", "donationId", "churchId", "categoryId", reference, "gatewayReference", "redirectUrl", "returnUrl", notes, metadata, "webhookReceived", "completedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4641 (class 0 OID 9480690)
-- Dependencies: 285
-- Data for Name: payment_gateway_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_gateway_configs (id, "gatewayType", "churchId", "isEnabled", "isTestMode", "merchantId", "apiKey", "clientId", "clientSecret", "webhookSecret", configuration, "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4590 (class 0 OID 9480149)
-- Dependencies: 234
-- Data for Name: payment_methods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_methods (id, name, description, "isDigital", "churchId", "isActive", "createdAt", "updatedAt") FROM stdin;
method-nequi	Nequi	Pago a través de la app Nequi	t	demo-church	t	2025-08-30 22:13:49.837	2025-08-30 22:13:49.837
method-tarjeta	Tarjeta de Crédito/Débito	Pago con tarjeta bancaria	t	demo-church	t	2025-08-30 22:13:49.837	2025-08-30 22:13:49.837
method-transferencia	Transferencia Bancaria	Transferencia directa a cuenta de la iglesia	t	demo-church	t	2025-08-30 22:13:49.837	2025-08-30 22:13:49.837
method-efectivo	Efectivo	Pago en efectivo durante el servicio	f	demo-church	t	2025-08-30 22:13:49.837	2025-08-30 22:13:49.837
\.


--
-- TOC entry 4575 (class 0 OID 9479995)
-- Dependencies: 219
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permissions (id, name, description, resource, action, conditions, "isActive", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4635 (class 0 OID 9480623)
-- Dependencies: 279
-- Data for Name: plan_features; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.plan_features (id, key, name, description, category, "isActive", "createdAt", "updatedAt") FROM stdin;
cmeywczqe0000q8edp6wutbrs	events_management	Gestión de Eventos	Creación y administración de eventos	core	t	2025-08-30 23:32:46.694	2025-08-30 23:32:46.694
cmeywczqp0001q8edfa7rj4f5	multi_church	Multi-Iglesia	Gestión de múltiples iglesias desde una cuenta	enterprise	t	2025-08-30 23:32:46.694	2025-08-30 23:32:46.694
cmeywczqq0002q8ed6d3yxu1t	analytics_dashboard	Dashboard de Analytics	Dashboard completo con métricas y gráficos	advanced	t	2025-08-30 23:32:46.694	2025-08-30 23:32:46.694
cmeywczqu0003q8edd8jzajij	custom_branding	Marca Personalizada	Personalización completa de marca y colores	enterprise	t	2025-08-30 23:32:46.695	2025-08-30 23:32:46.695
cmeywczqu0004q8edtv1eb34a	members_management	Gestión de Miembros	Administración completa de miembros de la iglesia	core	t	2025-08-30 23:32:46.694	2025-08-30 23:32:46.694
cmeywczqx0005q8edyrb5f2e8	communications	Sistema de Comunicaciones	Envío masivo de emails y notificaciones	advanced	t	2025-08-30 23:32:46.694	2025-08-30 23:32:46.694
cmeywczqz0007q8edyahub1xn	priority_support	Soporte Prioritario	Soporte 24/7 con respuesta prioritaria	enterprise	t	2025-08-30 23:32:46.695	2025-08-30 23:32:46.695
cmeywczqz0008q8ed0do6bt95	advanced_integrations	Integraciones Avanzadas	Integraciones con sistemas externos	enterprise	t	2025-08-30 23:32:46.695	2025-08-30 23:32:46.695
cmeywczqz0006q8edqp9q8pkp	advanced_reports	Reportes Avanzados	Reportes personalizados y programables	advanced	t	2025-08-30 23:32:46.694	2025-08-30 23:32:46.694
cmeywczr10009q8edf19i0vcw	api_access	Acceso a API	API completa para integraciones personalizadas	enterprise	t	2025-08-30 23:32:46.694	2025-08-30 23:32:46.694
cmeywczr1000aq8ed511tw6pl	automation_rules	Automatizaciones	Reglas de automatización y triggers	advanced	t	2025-08-30 23:32:46.694	2025-08-30 23:32:46.694
cmeywczs8000cq8ednxcxqjq6	donations_basic	Donaciones Básicas	Sistema básico de registro de donaciones	core	t	2025-08-30 23:32:46.694	2025-08-30 23:32:46.694
cmeywczs8000bq8ed6ggbkfh4	basic_reports	Reportes Básicos	Reportes simples de miembros y donaciones	core	t	2025-08-30 23:32:46.694	2025-08-30 23:32:46.694
cmeywczs9000dq8edzxrn2jrf	volunteer_management	Gestión de Voluntarios	Administración completa de voluntarios	advanced	t	2025-08-30 23:32:46.694	2025-08-30 23:32:46.694
\.


--
-- TOC entry 4660 (class 0 OID 9480891)
-- Dependencies: 304
-- Data for Name: platform_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.platform_settings (id, currency, "taxRate", "freeTrialDays", "gracePeriodDays", "platformName", "supportEmail", "maintenanceMode", "allowRegistrations", "createdAt", "updatedAt") FROM stdin;
default	USD	0	14	7	Kḥesed-tek Church Management Systems	soporte@khesedtek.com	f	t	2025-08-30 22:22:40.131	2025-09-01 20:52:59.763
\.


--
-- TOC entry 4647 (class 0 OID 9480753)
-- Dependencies: 291
-- Data for Name: prayer_approvals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.prayer_approvals (id, "requestId", "contactId", "approvedBy", status, notes, "approvedAt", "churchId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4643 (class 0 OID 9480712)
-- Dependencies: 287
-- Data for Name: prayer_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.prayer_categories (id, name, description, icon, color, "isActive", "churchId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4645 (class 0 OID 9480731)
-- Dependencies: 289
-- Data for Name: prayer_contacts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.prayer_contacts (id, "fullName", phone, email, "preferredContact", "churchId", "isActive", source, notes, "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4648 (class 0 OID 9480762)
-- Dependencies: 292
-- Data for Name: prayer_forms; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.prayer_forms (id, name, description, fields, style, "isActive", "isPublic", slug, "churchId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4649 (class 0 OID 9480772)
-- Dependencies: 293
-- Data for Name: prayer_qr_codes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.prayer_qr_codes (id, name, description, "formId", code, design, "isActive", "scanCount", "lastScan", "churchId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4646 (class 0 OID 9480742)
-- Dependencies: 290
-- Data for Name: prayer_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.prayer_requests (id, "contactId", "categoryId", message, "isAnonymous", status, priority, "scheduledAt", "sentAt", "responseType", "churchId", "formId", "qrCodeId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4644 (class 0 OID 9480721)
-- Dependencies: 288
-- Data for Name: prayer_response_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.prayer_response_templates (id, "categoryId", title, message, "smsMessage", "isActive", "isDefault", "churchId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4650 (class 0 OID 9480782)
-- Dependencies: 294
-- Data for Name: prayer_testimonies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.prayer_testimonies (id, title, message, "contactId", "prayerRequestId", category, "isAnonymous", status, "isPublic", "imageUrl", tags, "churchId", "formId", "qrCodeId", "approvedBy", "approvedAt", "submittedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4633 (class 0 OID 9480600)
-- Dependencies: 277
-- Data for Name: push_notification_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.push_notification_logs (id, "churchId", "userId", title, body, payload, status, "deliveryAttempts", "lastAttempt", error, "clickedAt", "dismissedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4632 (class 0 OID 9480591)
-- Dependencies: 276
-- Data for Name: push_subscriptions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.push_subscriptions (id, "userId", "churchId", endpoint, p256dh, auth, "isActive", "userAgent", platform, language, "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4609 (class 0 OID 9480353)
-- Dependencies: 253
-- Data for Name: report_executions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.report_executions (id, "reportId", status, format, "fileUrl", parameters, "rowCount", "executionTime", "errorMessage", "executedBy", "churchId", "createdAt", "completedAt") FROM stdin;
\.


--
-- TOC entry 4608 (class 0 OID 9480343)
-- Dependencies: 252
-- Data for Name: report_schedules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.report_schedules (id, "reportId", frequency, "dayOfWeek", "dayOfMonth", "time", recipients, format, "isActive", "lastSent", "nextScheduled", "churchId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4577 (class 0 OID 9480015)
-- Dependencies: 221
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.role_permissions (id, "roleId", "permissionId", conditions, "createdAt") FROM stdin;
\.


--
-- TOC entry 4576 (class 0 OID 9480004)
-- Dependencies: 220
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, name, description, "churchId", "isSystem", "isActive", priority, "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4582 (class 0 OID 9480065)
-- Dependencies: 226
-- Data for Name: sermons; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sermons (id, title, content, outline, scripture, date, speaker, "churchId", "isPublic", "createdAt", "updatedAt") FROM stdin;
cmeytjgp5000tq8fc4lqn6im4	El Amor Incondicional de Dios	Dios nos ama con un amor que no tiene condiciones ni límites. En Juan 3:16 vemos la mayor expresión de este amor: "Porque de tal manera amó Dios al mundo, que ha dado a su Hijo unigénito, para que todo aquel que en él cree, no se pierda, mas tenga vida eterna."\n\nEste amor no depende de nuestras acciones, nuestro estatus social, o nuestros errores del pasado. Es un amor que nos busca cuando estamos perdidos, nos levanta cuando caemos, y nos da esperanza cuando todo parece perdido.\n\nTres aspectos del amor de Dios:\n1. Es personal - Dios te conoce por nombre\n2. Es sacrificial - Dio a su Hijo por ti\n3. Es eterno - Nunca se acaba\n\nHoy puedes experimentar este amor. Solo tienes que abrir tu corazón y recibirlo.	\N	Juan 3:16	2024-01-07 00:00:00	Pastor Carlos Ruiz	demo-church	f	2025-08-30 22:13:49.77	2025-08-30 22:13:49.77
cmeytjgp7000vq8fcwdhyen8d	Viviendo con Propósito	Cada persona fue creada con un propósito específico en el plan de Dios. En Jeremías 29:11 Dios nos dice: "Porque yo sé los pensamientos que tengo acerca de vosotros, dice Jehová, pensamientos de paz, y no de mal, para daros el fin que esperáis."\n\nNo estás aquí por casualidad. Tu vida tiene significado y valor. Dios tiene planes específicos para ti:\n\n1. Un plan de esperanza - No de destrucción sino de edificación\n2. Un plan de futuro - No solo para el presente sino para toda la vida\n3. Un plan de bien - Para tu beneficio y el de otros\n\nPara descubrir tu propósito:\n- Busca a Dios en oración\n- Estudia Su Palabra\n- Sirve a otros\n- Usa los dones que Él te ha dado\n\nTu propósito puede estar más cerca de lo que imaginas.	\N	Jeremías 29:11	2024-01-14 00:00:00	Pastor Carlos Ruiz	demo-church	f	2025-08-30 22:13:49.772	2025-08-30 22:13:49.772
cmeytjgpa000xq8fcfrjun37y	La Importancia del Perdón	El perdón es una de las enseñanzas más poderosas de Jesús. En Mateo 6:14-15 Él nos dice: "Porque si perdonáis a los hombres sus ofensas, os perdonará también a vosotros vuestro Padre celestial; mas si no perdonáis a los hombres sus ofensas, tampoco vuestro Padre os perdonará vuestras ofensas."\n\nPerdonar no es fácil, pero es esencial para nuestra libertad espiritual y emocional. Cuando guardamos rencor, somos nosotros los que sufrimos.\n\nPasos para perdonar:\n1. Reconoce el dolor - No minimices lo que pasó\n2. Decide perdonar - Es una decisión, no un sentimiento\n3. Busca ayuda de Dios - Él te dará la fuerza\n4. Libera el deseo de venganza - Deja que Dios sea el juez\n5. Ora por la persona - Esto transformará tu corazón\n\nRecuerda: perdonar no significa tolerar el abuso o no establecer límites. Significa liberar el rencor de tu corazón.	\N	Mateo 6:14-15	2024-01-21 00:00:00	Pastor Carlos Ruiz	demo-church	f	2025-08-30 22:13:49.774	2025-08-30 22:13:49.774
cmf76ch23000tugjfsrcikif9	El Amor Incondicional de Dios	Dios nos ama con un amor que no tiene condiciones ni límites. En Juan 3:16 vemos la mayor expresión de este amor: "Porque de tal manera amó Dios al mundo, que ha dado a su Hijo unigénito, para que todo aquel que en él cree, no se pierda, mas tenga vida eterna."\n\nEste amor no depende de nuestras acciones, nuestro estatus social, o nuestros errores del pasado. Es un amor que nos busca cuando estamos perdidos, nos levanta cuando caemos, y nos da esperanza cuando todo parece perdido.\n\nTres aspectos del amor de Dios:\n1. Es personal - Dios te conoce por nombre\n2. Es sacrificial - Dio a su Hijo por ti\n3. Es eterno - Nunca se acaba\n\nHoy puedes experimentar este amor. Solo tienes que abrir tu corazón y recibirlo.	\N	Juan 3:16	2024-01-07 00:00:00	Pastor Carlos Ruiz	demo-church	f	2025-09-05 18:34:28.059	2025-09-05 18:34:28.059
cmf76ch26000vugjfxfsihq05	Viviendo con Propósito	Cada persona fue creada con un propósito específico en el plan de Dios. En Jeremías 29:11 Dios nos dice: "Porque yo sé los pensamientos que tengo acerca de vosotros, dice Jehová, pensamientos de paz, y no de mal, para daros el fin que esperáis."\n\nNo estás aquí por casualidad. Tu vida tiene significado y valor. Dios tiene planes específicos para ti:\n\n1. Un plan de esperanza - No de destrucción sino de edificación\n2. Un plan de futuro - No solo para el presente sino para toda la vida\n3. Un plan de bien - Para tu beneficio y el de otros\n\nPara descubrir tu propósito:\n- Busca a Dios en oración\n- Estudia Su Palabra\n- Sirve a otros\n- Usa los dones que Él te ha dado\n\nTu propósito puede estar más cerca de lo que imaginas.	\N	Jeremías 29:11	2024-01-14 00:00:00	Pastor Carlos Ruiz	demo-church	f	2025-09-05 18:34:28.063	2025-09-05 18:34:28.063
cmf76ch28000xugjfc052p4xd	La Importancia del Perdón	El perdón es una de las enseñanzas más poderosas de Jesús. En Mateo 6:14-15 Él nos dice: "Porque si perdonáis a los hombres sus ofensas, os perdonará también a vosotros vuestro Padre celestial; mas si no perdonáis a los hombres sus ofensas, tampoco vuestro Padre os perdonará vuestras ofensas."\n\nPerdonar no es fácil, pero es esencial para nuestra libertad espiritual y emocional. Cuando guardamos rencor, somos nosotros los que sufrimos.\n\nPasos para perdonar:\n1. Reconoce el dolor - No minimices lo que pasó\n2. Decide perdonar - Es una decisión, no un sentimiento\n3. Busca ayuda de Dios - Él te dará la fuerza\n4. Libera el deseo de venganza - Deja que Dios sea el juez\n5. Ora por la persona - Esto transformará tu corazón\n\nRecuerda: perdonar no significa tolerar el abuso o no establecer límites. Significa liberar el rencor de tu corazón.	\N	Mateo 6:14-15	2024-01-21 00:00:00	Pastor Carlos Ruiz	demo-church	f	2025-09-05 18:34:28.064	2025-09-05 18:34:28.064
\.


--
-- TOC entry 4615 (class 0 OID 9480408)
-- Dependencies: 259
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sessions (id, "sessionToken", "userId", expires) FROM stdin;
\.


--
-- TOC entry 4602 (class 0 OID 9480284)
-- Dependencies: 246
-- Data for Name: social_media_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.social_media_accounts (id, platform, "accountId", username, "displayName", "accessToken", "refreshToken", "tokenExpiresAt", "isActive", "lastSync", "accountData", "churchId", "connectedBy", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4606 (class 0 OID 9480322)
-- Dependencies: 250
-- Data for Name: social_media_metrics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.social_media_metrics (id, "accountId", "postId", "campaignId", platform, "metricType", value, date, "periodType", metadata, "churchId", "collectedAt", "createdAt") FROM stdin;
\.


--
-- TOC entry 4603 (class 0 OID 9480293)
-- Dependencies: 247
-- Data for Name: social_media_posts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.social_media_posts (id, title, content, "mediaUrls", platforms, "accountIds", status, "scheduledAt", "publishedAt", "postIds", engagement, hashtags, mentions, "campaignId", "authorId", "churchId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4653 (class 0 OID 9480815)
-- Dependencies: 297
-- Data for Name: spiritual_gifts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.spiritual_gifts (id, name, category, description, "createdAt", "updatedAt") FROM stdin;
cmf4h2u170000pcnnkbr6rhwh	Liderazgo	Liderazgo	Capacidad divina para guiar, dirigir y organizar a otros hacia objetivos espirituales.	2025-09-03 21:11:35.563	2025-09-03 21:11:35.563
cmf4h2u1c0001pcnn7p99f6ee	Administración	Liderazgo	Don para organizar recursos y coordinar ministerios de manera efectiva.	2025-09-03 21:11:35.568	2025-09-03 21:11:35.568
cmf4h2u1d0002pcnnuzrve1po	Pastor	Liderazgo	Corazón para cuidar, proteger y nutrir espiritualmente a otros creyentes.	2025-09-03 21:11:35.57	2025-09-03 21:11:35.57
cmf4h2u1f0003pcnnzbmuvuf6	Enseñanza	Comunicación	Habilidad especial para explicar y transmitir verdades bíblicas de forma clara.	2025-09-03 21:11:35.572	2025-09-03 21:11:35.572
cmf4h2u1h0004pcnnxfjvmrm3	Predicación	Comunicación	Capacidad para proclamar la Palabra de Dios con autoridad y claridad.	2025-09-03 21:11:35.573	2025-09-03 21:11:35.573
cmf4h2u1i0005pcnnf9os4ctv	Evangelismo	Comunicación	Pasión y habilidad especial para compartir el evangelio con los no creyentes.	2025-09-03 21:11:35.575	2025-09-03 21:11:35.575
cmf4h2u1j0006pcnn29bpqcq2	Profecía	Comunicación	Don para hablar la palabra de Dios de manera directa y oportuna.	2025-09-03 21:11:35.576	2025-09-03 21:11:35.576
cmf4h2u1l0007pcnnn679uhv5	Servicio	Servicio	Corazón para ayudar y servir a otros de manera práctica y desinteresada.	2025-09-03 21:11:35.577	2025-09-03 21:11:35.577
cmf4h2u1m0008pcnn7t2exocb	Ayuda	Servicio	Capacidad para asistir y apoyar a otros en sus necesidades y ministerios.	2025-09-03 21:11:35.579	2025-09-03 21:11:35.579
cmf4h2u1o0009pcnnburgzbw6	Hospitalidad	Servicio	Don para recibir y atender a otros con calidez y generosidad.	2025-09-03 21:11:35.58	2025-09-03 21:11:35.58
cmf4h2u1p000apcnn57kkpkns	Misericordia	Servicio	Compasión especial para ministrar a los que sufren y están en necesidad.	2025-09-03 21:11:35.582	2025-09-03 21:11:35.582
cmf4h2u1r000bpcnndj4ykn7r	Música	Artístico	Talento musical para alabar a Dios y ministrar a través de la música.	2025-09-03 21:11:35.583	2025-09-03 21:11:35.583
cmf4h2u1s000cpcnnbjyidp3d	Arte y Creatividad	Artístico	Habilidades creativas para expresar la gloria de Dios a través del arte.	2025-09-03 21:11:35.585	2025-09-03 21:11:35.585
cmf4h2u1t000dpcnndwms12qb	Danza	Artístico	Capacidad para adorar y ministrar a través del movimiento y la danza.	2025-09-03 21:11:35.586	2025-09-03 21:11:35.586
cmf4h2u1v000epcnnmichua60	Intercesión	Espiritual	Don especial para orar efectivamente por otros y sus necesidades.	2025-09-03 21:11:35.587	2025-09-03 21:11:35.587
cmf4h2u1w000fpcnn1qd0g4xn	Discernimiento	Espiritual	Capacidad para distinguir entre la verdad y el error espiritual.	2025-09-03 21:11:35.588	2025-09-03 21:11:35.588
cmf4h2u1x000gpcnn5wkt32te	Fe	Espiritual	Confianza extraordinaria en Dios para cosas grandes y específicas.	2025-09-03 21:11:35.59	2025-09-03 21:11:35.59
cmf4h2u1z000hpcnn3cv3i1nx	Sanidad	Espiritual	Don para ser instrumento de Dios en la restauración física y emocional.	2025-09-03 21:11:35.591	2025-09-03 21:11:35.591
cmf4h2u20000ipcnnmr64xzj4	Consejería	Relacional	Sabiduría especial para guiar a otros en decisiones y problemas de vida.	2025-09-03 21:11:35.592	2025-09-03 21:11:35.592
cmf4h2u22000jpcnnxmplxtoy	Mentoreo	Relacional	Capacidad para discipular y formar espiritualmente a otros creyentes.	2025-09-03 21:11:35.595	2025-09-03 21:11:35.595
cmf4h2u23000kpcnn5rk09vll	Motivación	Relacional	Don para animar e inspirar a otros hacia el crecimiento espiritual.	2025-09-03 21:11:35.596	2025-09-03 21:11:35.596
cmf4h2u25000lpcnnxnftzg79	Tecnología	Técnico	Habilidades técnicas aplicadas al servicio del reino de Dios.	2025-09-03 21:11:35.597	2025-09-03 21:11:35.597
cmf4h2u26000mpcnnobihclkw	Comunicación Digital	Técnico	Capacidad para usar medios digitales para expandir el evangelio.	2025-09-03 21:11:35.598	2025-09-03 21:11:35.598
cmf4h2u27000npcnn1ip6rckz	Medios Audiovisuales	Técnico	Talento para producir contenido multimedia para el ministerio.	2025-09-03 21:11:35.6	2025-09-03 21:11:35.6
cmf4h2u29000opcnnym89nx9w	Trabajo con Niños	Ministerial	Corazón especial y habilidad para ministrar a los niños.	2025-09-03 21:11:35.601	2025-09-03 21:11:35.601
cmf4h2u2a000ppcnn2eeok3he	Trabajo Juvenil	Ministerial	Pasión y capacidad para conectar y ministrar a los jóvenes.	2025-09-03 21:11:35.602	2025-09-03 21:11:35.602
cmf4h2u2b000qpcnn62zhofei	Adultos Mayores	Ministerial	Don para ministrar y acompañar a la población de adultos mayores.	2025-09-03 21:11:35.604	2025-09-03 21:11:35.604
cmf4h2u2c000rpcnn37w506x3	Matrimonios y Familias	Ministerial	Sabiduría especial para fortalecer relaciones matrimoniales y familiares.	2025-09-03 21:11:35.605	2025-09-03 21:11:35.605
\.


--
-- TOC entry 4636 (class 0 OID 9480632)
-- Dependencies: 280
-- Data for Name: subscription_addons; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subscription_addons (id, key, name, description, "priceMonthly", "priceYearly", "billingType", "pricePerUnit", unit, "isActive", "createdAt", "updatedAt") FROM stdin;
cmeywczsj000jq8ed2hx367xl	sms_notifications	Notificaciones SMS	Envío de notificaciones por SMS a miembros	0	\N	PER_USE	50	SMS	t	2025-08-30 23:32:46.771	2025-08-31 00:53:53.981
cmeywczsj000lq8ed2pw0yk78	priority_support	Soporte Prioritario	Soporte 24/7 con respuesta en menos de 2 horas	60,000	64800000	MONTHLY	\N	\N	t	2025-08-30 23:32:46.771	2025-08-31 00:53:53.985
cmeywczsj000iq8ed4d0ey0ri	whatsapp_integration	Integración WhatsApp	Integración completa con WhatsApp Business API	50,000	54000000	MONTHLY	\N	\N	t	2025-08-30 23:32:46.771	2025-08-31 00:53:53.987
cmeywczsj000hq8ed91udx5c2	custom_branding	Marca Personalizada	Personalización completa de colores, logo y marca	30,000	32400000	MONTHLY	\N	\N	t	2025-08-30 23:32:46.771	2025-08-31 00:53:53.989
cmeywczsj000kq8ed0usw7hrz	advanced_analytics	Analytics Avanzados	Dashboards personalizados y métricas detalladas	40,000	43200000	MONTHLY	\N	\N	t	2025-08-30 23:32:46.771	2025-08-31 00:53:53.99
\.


--
-- TOC entry 4634 (class 0 OID 9480610)
-- Dependencies: 278
-- Data for Name: subscription_plans; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.subscription_plans (id, name, "displayName", description, "priceMonthly", "priceYearly", "maxChurches", "maxMembers", "maxUsers", "isActive", "sortOrder", features, "createdAt", "updatedAt") FROM stdin;
plan-enterprise	ENTERPRISE	Plan Enterprise	Solución completa para organizaciones grandes y redes de iglesias	599.00	5750.40	1	5000	20	t	3	["members_management", "events_management", "donations_basic", "basic_reports", "analytics_dashboard", "automation_rules", "advanced_reports", "communications", "volunteer_management", "api_access", "multi_church", "custom_branding", "priority_support", "advanced_integrations"]	2025-08-30 21:58:54.42	2025-09-10 20:05:09.097
plan-profesional	PROFESIONAL	Plan Profesional	Para iglesias medianas con necesidades avanzadas de gestión	299.00	3049.80	1	1000	10	t	2	["members_management", "events_management", "donations_basic", "basic_reports", "analytics_dashboard", "automation_rules", "advanced_reports", "communications", "volunteer_management"]	2025-08-30 21:58:54.416	2025-09-10 20:05:25.242
plan-basico	BÁSICO	Plan Básico	Perfecto para iglesias pequeñas que necesitan funcionalidades esenciales	149.00	1609.20	1	500	7	t	1	["members_management", "events_management", "donations_basic", "basic_reports"]	2025-08-30 21:58:54.413	2025-09-01 20:55:55.526
\.


--
-- TOC entry 4639 (class 0 OID 9480663)
-- Dependencies: 283
-- Data for Name: support_contact_info; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.support_contact_info (id, "whatsappNumber", "whatsappUrl", email, schedule, "companyName", location, website, "createdAt", "updatedAt") FROM stdin;
default	+57 302 123 4410	https://wa.me/573021234410	suport@khesed-tek.com	Lun-Vie 8AM-8PM (Colombia)	Khesed-tek Systems	Barranquilla Atlantico, Colombia	https://khesedtek.com	2025-08-30 21:59:51.067	2025-09-05 19:17:22.799
\.


--
-- TOC entry 4665 (class 0 OID 9579036)
-- Dependencies: 309
-- Data for Name: tenant_credentials; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tenant_credentials (id, "churchId", "loginEmail", "tempPassword", "isFirstLogin", "sentAt", "lastSentAt", "createdBy", "createdAt", "updatedAt") FROM stdin;
cmf8uew430008s101raaz9970	cmf8udnbz0000s101ohl648q7	tonypilarte@gmail.com	$2a$12$oN7EqVo6YPF7hKF3xRncc.ebliB1NLMN4FQMI9nJnSL9CX0Kmc9Xm	t	2025-09-06 22:35:57.843	2025-09-06 22:37:43.658	cmeytjgo10003q8fcortp6k60	2025-09-06 22:35:57.844	2025-09-06 22:37:43.659
\.


--
-- TOC entry 4651 (class 0 OID 9480795)
-- Dependencies: 295
-- Data for Name: testimony_forms; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.testimony_forms (id, name, description, fields, style, "isActive", "isPublic", slug, "churchId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4652 (class 0 OID 9480805)
-- Dependencies: 296
-- Data for Name: testimony_qr_codes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.testimony_qr_codes (id, name, description, "formId", code, design, "isActive", "scanCount", "lastScan", "churchId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4578 (class 0 OID 9480023)
-- Dependencies: 222
-- Data for Name: user_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_permissions (id, "userId", "permissionId", granted, conditions, "expiresAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4579 (class 0 OID 9480032)
-- Dependencies: 223
-- Data for Name: user_roles_advanced; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_roles_advanced (id, "userId", "roleId", "isActive", "expiresAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4624 (class 0 OID 9480493)
-- Dependencies: 268
-- Data for Name: user_theme_preferences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_theme_preferences (id, "userId", "churchId", "themeName", "themeMode", "primaryColor", "secondaryColor", "accentColor", "destructiveColor", "backgroundColor", "foregroundColor", "cardColor", "cardForegroundColor", "borderColor", "mutedColor", "mutedForegroundColor", "fontFamily", "fontSize", "borderRadius", "compactMode", "logoUrl", "faviconUrl", "brandName", "isActive", "isPublic", "createdAt", "updatedAt") FROM stdin;
cmf1gaq7p0001nt01ueno8n7n	cmeytjgo10003q8fcortp6k60	\N	default	light	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Inter	medium	0.5rem	f	\N	\N	\N	t	f	2025-09-01 18:26:25.717	2025-09-01 18:26:25.717
\.


--
-- TOC entry 4580 (class 0 OID 9480041)
-- Dependencies: 224
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, name, email, "emailVerified", image, password, role, "churchId", "isActive", "createdAt", "updatedAt") FROM stdin;
cmeyt1tky0002q8xy011u77r7	Test User	testuserzxerg65w@example.com	\N	\N	$2a$12$we32XLBkYEoe8bkfmZgRl.XiMWg9PcrsX//9KOdmCaZxxBEYuImP2	ADMIN_IGLESIA	cmeyt1tkw0000q8xyyr97bp74	t	2025-08-30 22:00:06.659	2025-08-30 22:00:06.659
cmeyt1tt30006q8xyi98u4d5x	John Doe	john@doe.com	\N	\N	$2a$12$oTIJduteG7gLTzCYhWX7v.CsGokaskpbwkrrkoZh7Te0LDPyiTg2G	ADMIN_IGLESIA	cmeyt1tkw0000q8xyyr97bp74	t	2025-08-30 22:00:06.951	2025-08-30 22:00:06.951
cmeytjgnx0001q8fctjc12b43	María González	admin@iglesiacentral.com	\N	\N	$2a$12$YW1cTrAP.UIkvllt8fVqdeJMKp0EWsm2RrtHZGeCBjDcXJU0c1A.y	ADMIN_IGLESIA	demo-church	t	2025-08-30 22:13:49.725	2025-08-30 22:13:49.725
cmeytjgo50007q8fce5bou6vw	Pastor Carlos Ruiz	pastor@iglesiacentral.com	\N	\N	$2a$12$YW1cTrAP.UIkvllt8fVqdeJMKp0EWsm2RrtHZGeCBjDcXJU0c1A.y	PASTOR	demo-church	t	2025-08-30 22:13:49.734	2025-08-30 22:13:49.734
cmeyulmq30002q88urqrs7sso	Test User	testusersafef8ul@example.com	\N	\N	$2a$12$6RkTQ1pkZR/EuHaVWSYJHun3ZGVpiRPghLhSAIOJ5QJuKCkN1D5Pa	ADMIN_IGLESIA	cmeyulmq10000q88uarsz29du	t	2025-08-30 22:43:30.508	2025-08-30 22:43:30.508
cmeywekr70002q8jz299u8hx6	Test User	testuser2b653kof@example.com	\N	\N	$2a$12$Nyz4GKi9OqwqVDZaTIemsuVsV3r0qiAgGgoqZe02pC0PffiXm3j8G	ADMIN_IGLESIA	cmeywekr50000q8jzbj0r3u0c	t	2025-08-30 23:34:00.595	2025-08-30 23:34:00.595
cmeyxxtrb0002q8xo63p8quq5	Test User	testuser8fysugzj@example.com	\N	\N	$2a$12$4URrdb9gf.67PbiPep864uMk6DNZQgfELTeXS2D.Udt6WxHDjzEoO	ADMIN_IGLESIA	cmeyxxtr90000q8xonjxhcvar	t	2025-08-31 00:16:58.343	2025-08-31 00:16:58.343
cmeyzngfp0002q8lenarome5b	Test User	testuser95h124yl@example.com	\N	\N	$2a$12$EtOEVYNNu2gqVBfmYgA8dO.MHkrdcHLJr.km.keEin5OF4L2LK/wa	ADMIN_IGLESIA	cmeyzngfn0000q8legh8qh70q	t	2025-08-31 01:04:53.749	2025-08-31 01:04:53.749
cmez0uqjd0004q8e3cgcx0bje	Test User	testusero0rh3sxs@example.com	\N	\N	$2a$12$ltK/Sw.srqyASYod7BAE/eer0VzdiKo.5arUwBwzIZWUoVQygYfnm	ADMIN_IGLESIA	cmez0uqja0000q8e3wiqkv9jx	t	2025-08-31 01:38:33.05	2025-08-31 01:38:33.05
cmez0yne2000bq8e3bds5v55t	Test Admin	securetest@example.com	\N	\N	$2a$12$TpVX5yFN4f2Y5VesGb0VgO1WAYzaDvBHTfC9b/Nip7KrEd8/Dixkq	ADMIN_IGLESIA	cmez0yndy0007q8e3s9i3852m	t	2025-08-31 01:41:35.594	2025-08-31 01:41:35.594
cmez0ysox000iq8e3q54o4h0o	Test Hacker	hacker@example.com	\N	\N	$2a$12$wp9MevCdP.p9vUYcSh/kH.T0SFIgXF9P.P89SPjK.V8k2PA2Ns7we	ADMIN_IGLESIA	cmez0ysov000eq8e399j8ucvk	t	2025-08-31 01:41:42.465	2025-08-31 01:41:42.465
cmez0yxq8000pq8e3ubhwam9m	Test Hacker	hacker2@example.com	\N	\N	$2a$12$E.2rT/m7ewFgWCPJd820tOdLLQiAoDZRgT6ZxLhIkV3MvUklStKdS	ADMIN_IGLESIA	cmez0yxq6000lq8e3x5yi4otw	t	2025-08-31 01:41:48.992	2025-08-31 01:41:48.992
cmez2v2yy0004q8giogx2btbp	Test User	testuserfvkx5grf@example.com	\N	\N	$2a$12$tSEXA4EzEoArZMi0F.h3p.XGc4.zPx5.nnKEA8lFhBvwbEpF7xK3e	ADMIN_IGLESIA	cmez2v2yv0000q8gib6m58u6b	t	2025-08-31 02:34:48.395	2025-08-31 02:34:48.395
cmez30ezi0004q86nsajzeei9	Test User	testuserx1avfqgm@example.com	\N	\N	$2a$12$Osx.tzBqOHlmPtseHqlq2OPiz6jE61e2XrCUlOzF.3U.ATqwtEWB6	ADMIN_IGLESIA	cmez30eze0000q86ntsvyk2iz	t	2025-08-31 02:38:57.246	2025-08-31 02:38:57.246
cmez33zdu000bq86n86p6l3sc	Dynamic User	dynamic@example.com	\N	\N	$2a$12$3ROrBSlTwfUdp1yYL8Ki6.U1ffoGSzEmfIL51G9D4u5S8Uyh32zb2	ADMIN_IGLESIA	cmez33zdr0007q86nr4tvl5ib	t	2025-08-31 02:41:43.651	2025-08-31 02:41:43.651
cmez3tbeo0004q8qsuiku97bf	Test User	testuserjatf5ado@example.com	\N	\N	$2a$12$Hca3haqg.IrGqG1qyq9Ztu.fnAyMOQS3HIIBAiW6DqrsLenIwgum2	ADMIN_IGLESIA	cmez3tbek0000q8qsrgyoaknu	t	2025-08-31 03:01:25.632	2025-08-31 03:01:25.632
cmf1jo2tl0004p2nvzfrg1uvc	Test User	testuser75zozdpq@example.com	\N	\N	$2a$12$8mGkUKakI1v/CIylHJJYoOXMOXMn8EjmdBEjP0MOXFi6H5zjGXf1u	ADMIN_IGLESIA	cmf1jo2tc0000p2nv3nbzeape	f	2025-09-01 20:00:47.433	2025-09-01 20:02:17.302
cmf1gcbtl0004s8mpvq47tw5j	Test User	testuserzofpgxao@example.com	\N	\N	$2a$12$NxtBrr/IJbId41VMPElbPuMSkaKfKOBLBrHleKmvayCkFW8MT6WA6	ADMIN_IGLESIA	cmf1gcbtg0000s8mpc4skc5rg	f	2025-09-01 18:27:40.378	2025-09-01 20:02:34.613
cmf1flwvl0004s84ov0htth73	Test User	testuser3dt7kv7j@example.com	\N	\N	$2a$12$59vntdUWzxRpVcpaXJMUTO.Y/JbL46dC8S/vZCsAouulJWFrElXT2	ADMIN_IGLESIA	cmf1flwvf0000s84oop1aeh96	f	2025-09-01 18:07:07.954	2025-09-01 20:02:42.391
cmf1euc2l0004s8e8t1ga8pag	Test User	testusero0yfg4gu@example.com	\N	\N	$2a$12$C/HMD3fbPm1zwxsli9HjZegRf81YImSKC7CAsC7rG.opc.hm/WZvy	ADMIN_IGLESIA	cmf1euc2f0000s8e8xk8pw7d9	f	2025-09-01 17:45:41.277	2025-09-01 20:02:46.082
cmf1cyh4x0004s8vhu11evdtw	Test User	testusery4n0qu6u@example.com	\N	\N	$2a$12$RFdepuIfvmCl08Gv6bshPO17QFS4YvSObISh.9bkx/BtusygjFeKa	ADMIN_IGLESIA	cmf1cyh4t0000s8vh9p0cerql	f	2025-09-01 16:52:55.233	2025-09-01 20:02:50.78
cmf1c9n760004s8wf7chikz3d	Test User	testuserunlw4ss4@example.com	\N	\N	$2a$12$v8RUmCQDhx0G/yRhl2cSVegu6XmBL7d80G5HABplA7ljtLzlc2D3y	ADMIN_IGLESIA	cmf1c9n6w0000s8wf57x68925	f	2025-09-01 16:33:36.69	2025-09-01 20:02:58.581
cmf1kqq850004p2gqggytnxgk	Test User	testuser5memlw9c@example.com	\N	\N	$2a$12$aVh7oK2aIh.mZEOAA/DkxuDXD8oablENWlD4ajQ99wd98wqtOhkpy	ADMIN_IGLESIA	cmf1kqq810000p2gq6eacddjl	t	2025-09-01 20:30:50.693	2025-09-01 20:30:50.693
cmf1mfqcb0004m2q1a3l5lce5	Test User	testuser8m6du67a@example.com	\N	\N	$2a$12$oTLX.AzS.2rEXJ4s3jury.UjIaK9mx0fBwh0NG1dVZZsOS63Xe4uG	ADMIN_IGLESIA	cmf1mfqc60000m2q1k2g3md5b	t	2025-09-01 21:18:16.859	2025-09-01 21:18:16.859
cmf1nzgzs0004m2lazg7xpkl5	Test User	testuserprvlnnuo@example.com	\N	\N	$2a$12$As2htrPEKx.mZ6woa2QBZuyIFzVU17GHJUMk5E5PrS5/E9Yp53UmS	ADMIN_IGLESIA	cmf1nzgzm0000m2ladrdl8007	t	2025-09-01 22:01:37.481	2025-09-01 22:01:37.481
cmf1ojkec0004m20oay0mo82g	Test User	testusernvfvl8xs@example.com	\N	\N	$2a$12$DXvGLFlMPOqXQDTbEsX6IeYNRAxcxBYbIFZybPYGQVN3NgsPskcVm	ADMIN_IGLESIA	cmf1ojke60000m20o274v44ch	t	2025-09-01 22:17:15.013	2025-09-01 22:17:15.013
cmf1p8bls0004m2qgd3hx3c43	Test User	testuser18p18myb@example.com	\N	\N	$2a$12$u3dDWLyPWTyjzRs5L6su2uE.pBuMDdcmgdH.8vg1dt4b2q/VvNpHC	ADMIN_IGLESIA	cmf1p8blo0000m2qg06rvrow4	t	2025-09-01 22:36:30.017	2025-09-01 22:36:30.017
cmf1q0nn40004m2g9zoe6ap0v	Test User	testuserf5nfjoyd@example.com	\N	\N	$2a$12$2ngZyCSFLQoBLEC1fpU5fuvf8ALbQbp10QSrT2ym62eO76t1fViLm	ADMIN_IGLESIA	cmf1q0nmy0000m2g97d1xzdx1	t	2025-09-01 22:58:31.985	2025-09-01 22:58:31.985
cmf1qpumn0004m2zue4x50h0r	Test User	testuserx0k6enav@example.com	\N	\N	$2a$12$xA/9xsOEy2uv/TNbBuf47udFLwW5AZWluv23pfJq0sPUJDewZs7By	ADMIN_IGLESIA	cmf1qpumf0000m2zuk31kulwc	t	2025-09-01 23:18:07.44	2025-09-01 23:18:07.44
cmf1ri0vo0004m2j6udkou737	Test User	testuserzycd9jgw@example.com	\N	\N	$2a$12$5jpN9hQDxGfepoFz6csyBuJuvc.iXnXnmlcF0e2avHshE5TeTWRtC	ADMIN_IGLESIA	cmf1ri0vj0000m2j6ic7bjkmi	t	2025-09-01 23:40:01.908	2025-09-01 23:40:01.908
cmf1s66fl0004of01jghyqn9j	Nelson Castro	saviatek.ia@gmail.com	\N	\N	$2a$12$aeOp3OCarb1CAETlWpSwYe6FndUiWVnrOhfftTyubd5uXWXkb.Fc.	ADMIN_IGLESIA	cmf1s66fe0000of019relorwd	t	2025-09-01 23:58:48.849	2025-09-01 23:58:48.849
cmf2lzze80004q7z8cyx2qfj3	Test User	testuser3c111a1b@example.com	\N	\N	$2a$12$nJvrsl5hDtEgEA3KSeECuu7FhUVrErJ.R2QGmXFZb1Vq5EJGrsmeS	ADMIN_IGLESIA	cmf2lzzdq0000q7z8kkfwdmol	t	2025-09-02 13:53:48.272	2025-09-02 13:53:48.272
cmf2nf3dp0004q7qzdl6cmew1	Test User	testuserruziv3ge@example.com	\N	\N	$2a$12$fqyaFALt/ClBFPub/Ni6SOTHQ2Q9PNyF3ffG8NVbR9jPqWQuWme9G	ADMIN_IGLESIA	cmf2nf3dd0000q7qzpg7bbuwz	t	2025-09-02 14:33:32.893	2025-09-02 14:33:32.893
cmf2o64sk0004q7hm8c9vc0k3	Test User	testuserm1inci4k@example.com	\N	\N	$2a$12$JvvFpKHKWtFfcpsSQDPmTuYLZj1MZHuQF/GlGB9Iyfck8X.zf4uZe	ADMIN_IGLESIA	cmf2o64sb0000q7hmquald4hd	t	2025-09-02 14:54:34.436	2025-09-02 14:54:34.436
cmf2owxbz0004q74h98qo2zdo	Test User	testuserjfnco12u@example.com	\N	\N	$2a$12$ED6Iu1UFfPN3Gta18huo4eEKFS6dfMra1RmB0VXnO6YEcaj1r0qJO	ADMIN_IGLESIA	cmf2owxbq0000q74hhyfjnsy0	t	2025-09-02 15:15:24.479	2025-09-02 15:15:24.479
cmf2px4jm0004q7ppsxn8v5ro	Test User	testuserb49m87je@example.com	\N	\N	$2a$12$VAQ/LACvVcFMZq3gh4TCEukPcb9clv2SF2cy7xHmzW5yODo9fxNqu	ADMIN_IGLESIA	cmf2px4jc0000q7pph68odq7g	t	2025-09-02 15:43:33.442	2025-09-02 15:43:33.442
cmf2rb4s40004q776tsngfsmy	Test User	testuserdmaf4tlw@example.com	\N	\N	$2a$12$uyLvi7HzugtVQPq2o9oOoeRnQBN1IwSwQQn6/2WImAI.2BkkC5dAu	ADMIN_IGLESIA	cmf2rb4ru0000q7763rck0uwj	t	2025-09-02 16:22:26.548	2025-09-02 16:22:26.548
cmf2tg7380004ntovupluuhg7	Test User	testuserqctgsfuc@example.com	\N	\N	$2a$12$mdXqu6PCCLb/COKT3iXUh.f8C077QYi3pasgFNAtB5V.rKcO5COI6	ADMIN_IGLESIA	cmf2tg72q0000ntovxmk4l8ti	t	2025-09-02 17:22:22.053	2025-09-02 17:22:22.053
cmf2uaqxu0004ntbfk1rvdzpl	Test User	testuser7nqztvhe@example.com	\N	\N	$2a$12$zQL5zShQQre5BHio0RBXnerKZxxYKPtRQLUuDrLIWVy629PevTO0y	ADMIN_IGLESIA	cmf2uaqxn0000ntbfywax1quq	t	2025-09-02 17:46:07.459	2025-09-02 17:46:07.459
cmf2vfy8u0004nt4gq6kg5lj1	Test User	testuser4y6s4tq9@example.com	\N	\N	$2a$12$M7FFSiYm2nrah.4nSczAWuh2XM68qzJP4cHtrXOpjPoLaSrkQtMRO	ADMIN_IGLESIA	cmf2vfy8l0000nt4gc5gz994q	t	2025-09-02 18:18:09.822	2025-09-02 18:18:09.822
cmf2wuna60004nt0ovhevs55l	Test User	testuserzgpwvfnt@example.com	\N	\N	$2a$12$iYynKLwIEoW2UUX1chb0HOfPmMJXzr/qnjhpk4HiM.xEJDbiDNCWy	ADMIN_IGLESIA	cmf2wun9w0000nt0oswz1q6px	t	2025-09-02 18:57:35.071	2025-09-02 18:57:35.071
cmf30f6pt0004vvono9yqoo1d	Test User	testuser03plhzzt@example.com	\N	\N	$2a$12$1fAWy4q90hNZXuFqxERkAOiLU.NwYupVTs/cugADvOJ0U19OCM4..	ADMIN_IGLESIA	cmf30f6pg0000vvoni6r15qoh	t	2025-09-02 20:37:32.226	2025-09-02 20:37:32.226
cmf318t6n0004vv7woxb6c3wr	Test User	testusernkvb4rk7@example.com	\N	\N	$2a$12$LUu37NYxpSOntMM/WmwU1.uhBvtFMeE997Pw4zvSg5hrM9PP1UEUC	ADMIN_IGLESIA	cmf318t6f0000vv7w2f1muqzg	t	2025-09-02 21:00:34.367	2025-09-02 21:00:34.367
cmf32jnwy0004vv3j5u43e47h	Test User	testuserbqq8jgp8@example.com	\N	\N	$2a$12$Jv4sckSuXin8wlUU1CqC9u6cp249vODXdJXDxrQR556hRaFMXP1W6	ADMIN_IGLESIA	cmf32jnwo0000vv3jilchdgw8	t	2025-09-02 21:37:00.371	2025-09-02 21:37:00.371
cmf341qge0004vv72atozt4dx	Test User	testuserrp400i0q@example.com	\N	\N	$2a$12$G13XiGuIK2j.al.NVA0txur3mfpM9e32VRtbl01ll9pjvTmoDfQKO	ADMIN_IGLESIA	cmf341qg40000vv723fg9he77	t	2025-09-02 22:19:03.086	2025-09-02 22:19:03.086
cmf34o6th0004vvrnkkiu34qh	Test User	testuserhg6stzwo@example.com	\N	\N	$2a$12$eSpZwsOC2qDAPY8KuyjXk.C4bwc.8gvBlg8A33merk8bOQ4X3s/gO	ADMIN_IGLESIA	cmf34o6td0000vvrndejb7y2p	t	2025-09-02 22:36:30.726	2025-09-02 22:36:30.726
cmf35jn7b0004vvuby7hm92fi	Test User	testuser9woizi4h@example.com	\N	\N	$2a$12$6UXz9cLjWCVM7e1cLNyl2O3RBKd5/RlE6PBAs78VdiOv9KDUS3XNW	ADMIN_IGLESIA	cmf35jn730000vvubhnnw4oxz	t	2025-09-02 23:00:58.295	2025-09-02 23:00:58.295
cmf35rkjo0004vvjtwx1149x0	Test User	testuser0yj001j4@example.com	\N	\N	$2a$12$Irn/fpVbnTDQ2tbBXgoL6uvT/l6qzse4kzNlJ8QAnBrdQEc1Pc.MG	ADMIN_IGLESIA	cmf35rkjj0000vvjt4pwsy0dz	t	2025-09-02 23:07:08.1	2025-09-02 23:07:08.1
cmf36kgal0004vv92yogrme7d	Test User	testuserz7b35k3f@example.com	\N	\N	$2a$12$TVrlapAmFWO7tCIVYDW0IOV6Wv38Bjvl6u9xBWFyoDR5WXc/V1g7q	ADMIN_IGLESIA	cmf36kgah0000vv92dg716icf	t	2025-09-02 23:29:35.614	2025-09-02 23:29:35.614
cmf474kot0004uqzv36d1rxov	Test User	testuserkh9lm4gh@example.com	\N	\N	$2a$12$8OiZSqGBqV9YV6QegjLQduhZfMNWuMyIB57q8PCCep7eF24zRZ93a	ADMIN_IGLESIA	cmf474koj0000uqzvlrfoxqtm	t	2025-09-03 16:33:00.605	2025-09-03 16:33:00.605
cmf47wdke0004uqost7eol10f	Test User	testuserz77hub6v@example.com	\N	\N	$2a$12$I56CjFU9dIaP/yk.CBA8BOF8q4KddmZaxhpNIvscIkWXu5PwQ4596	ADMIN_IGLESIA	cmf47wdk60000uqos0lkwharm	t	2025-09-03 16:54:37.742	2025-09-03 16:54:37.742
cmf48k96c0004uq91jtqy9355	Test User	testuser2tyjn47r@example.com	\N	\N	$2a$12$JkhfFofSHL2nFeWMUsLBZOZQiIWGR9HZUWnVdiU09dQlg5tCHOgj.	ADMIN_IGLESIA	cmf48k9650000uq91bnx3l1ma	t	2025-09-03 17:13:11.797	2025-09-03 17:13:11.797
cmf49g0vc0004uqpistrlzzec	Test User	testuser7b235mfh@example.com	\N	\N	$2a$12$f8lAHrH8zd0Qg8QbwFkUxuEPMED86q8yfYGqxmg3XsT/KBt3cdq3C	ADMIN_IGLESIA	cmf49g0v50000uqpiv19hw43t	t	2025-09-03 17:37:54.024	2025-09-03 17:37:54.024
cmf4a1dqw0004uq9nba8v3wkt	Test User	testuserg8o6in3k@example.com	\N	\N	$2a$12$hh4F0EJspGmQYAaPRUSC9uWeAzcIQijPuvWJu9swIrZcypav2ewnK	ADMIN_IGLESIA	cmf4a1dqs0000uq9npv695x49	t	2025-09-03 17:54:30.489	2025-09-03 17:54:30.489
cmf4an4q00004uqr2zenuktcn	Test User	testuserwzrr8tot@example.com	\N	\N	$2a$12$XwbCpwafBDsWJPMyZMUkgOJHnaJJFr.CfePbCHNdX3iXYoJGL/jMS	ADMIN_IGLESIA	cmf4an4pq0000uqr2r3vrslq2	t	2025-09-03 18:11:25.224	2025-09-03 18:11:25.224
cmf4befuo0004uqbl6y4c5pup	Test User	testuserfbnmn2zd@example.com	\N	\N	$2a$12$HreTwgExOx4uqThpfwlsbud2IC48jXfkbUI7plnCFtQxpGnlMEsoq	ADMIN_IGLESIA	cmf4befuj0000uqblsubhki3k	t	2025-09-03 18:32:39.361	2025-09-03 18:32:39.361
cmf5jm5hz0004s7ms2cxdt6xe	Test User	testuserhmo9le82@example.com	\N	\N	$2a$12$Mw9KUH78/ljjWgyJrQScXuup29tLk3IofjDOQZlA3kbvLxUNBKAcC	ADMIN_IGLESIA	cmf5jm5hl0000s7mstbgeeqmq	t	2025-09-04 15:10:22.295	2025-09-04 15:10:22.295
cmf5jyxt10004s7nllf6ca0gi	Test User	testuser4uq41lam@example.com	\N	\N	$2a$12$OQnzc021Q8pR.TT9vybn2OHn2Aft7CQxOQoPPF92cWC4d687TqsYO	ADMIN_IGLESIA	cmf5jyxsw0000s7nlvukvas4x	t	2025-09-04 15:20:18.853	2025-09-04 15:20:18.853
cmf5lu9a40004s7m6ruzwronq	Test User	testuserhr40pccw@example.com	\N	\N	$2a$12$5FhfxEJYb7tnlYK.owUSQuPe9HtmiCChRQcxhf7UtyqiuiKzZkH4y	ADMIN_IGLESIA	cmf5lu99r0000s7m69navda79	t	2025-09-04 16:12:39.677	2025-09-04 16:12:39.677
cmf5mgtf70004s71yg72c37lh	Test User	testuserpfos8hab@example.com	\N	\N	$2a$12$QBuqAH7TSlL.TdlGrpYR1.MVttZta5mBf7N2RKyY1MUKIOL58IHkO	ADMIN_IGLESIA	cmf5mgtf20000s71ymce0bf3w	t	2025-09-04 16:30:12.211	2025-09-04 16:30:12.211
cmf5o3quy0004s78razkcvbx8	Test User	testuser1pl0zw46@example.com	\N	\N	$2a$12$WTAPP/11SiR7ZK9KSi4TLOOpS.ZHjNiUOVnl10v13kUroSGpShZuu	ADMIN_IGLESIA	cmf5o3qut0000s78rgnu9t0ad	t	2025-09-04 17:16:01.595	2025-09-04 17:16:01.595
cmf5w9nqb0004vgrp4qnag1qd	Test User	testuser05oynv59@example.com	\N	\N	$2a$12$4Er2ur0bOyojQRq6U/kDL.QSIWef9E9mANhafhrpujlr3wS.eBk1a	ADMIN_IGLESIA	cmf5w9nq10000vgrptiufiw9h	t	2025-09-04 21:04:34.403	2025-09-04 21:04:34.403
cmf5xcqel0004vgkommke1h0l	Test User	testuserr45livxe@example.com	\N	\N	$2a$12$7zXzopq6Q/MDu6qs5U5ID.CU/Gxb6oqxMgS9s2x.Ys0oSEP2.Gxou	ADMIN_IGLESIA	cmf5xcqeh0000vgkovh9xdwem	t	2025-09-04 21:34:57.453	2025-09-04 21:34:57.453
cmf5y3lmt0004vgv9o5lxelwt	Test User	testuser5glsoruk@example.com	\N	\N	$2a$12$ckuDenUZZ/YE2r/g0KKmjud2JRY5f2LqcFS2JkVOrCmrJSoGtsv8S	ADMIN_IGLESIA	cmf5y3lmp0000vgv9am7u3vz5	t	2025-09-04 21:55:50.982	2025-09-04 21:55:50.982
cmf76r2x90004ug01gu81kvxt	Test User	testusersp2z60zb@example.com	\N	\N	$2a$12$mLmApadvCRB/6h.IwMBvDuFwX9nr2vBce/ETyATvM9v51QwOvMo2i	ADMIN_IGLESIA	cmf76r2x00000ug01ao08qy8m	t	2025-09-05 18:45:49.581	2025-09-05 18:45:49.581
cmf7b8e7a0004vubo6ha6kjiu	Test User	testuser6b33rmgy@example.com	\N	\N	$2a$12$5MV5K080IOKj9QNc65M/NOgAgw7ubTAlHiXx282N679.Hh4jso/wO	ADMIN_IGLESIA	cmf7b8e730000vubolitp5wub	t	2025-09-05 20:51:15.814	2025-09-05 20:51:15.814
cmf76ch0h0003ugjfb7z1mlui	Nelson Castro	soport@khesed-tek.com	\N	\N	$2a$12$5MtqtLTD0TesceInp5EAee70hGZjZXpBQIQCOVx.X.KF0TTUg.glO	SUPER_ADMIN	\N	t	2025-09-05 18:34:28.001	2025-09-05 18:57:51.809
cmf77xx0h0004ug7zysacjkgc	Test User	testuser9n6nmnub@example.com	\N	\N	$2a$12$AQaFFCytP2egQb3sZEpRZuxOEPahqHoDoHdfoUB7HixqKUrH6SvTW	ADMIN_IGLESIA	cmf77xx090000ug7zfogto5zs	t	2025-09-05 19:19:08.13	2025-09-05 19:19:08.13
cmeytjgo10003q8fcortp6k60	Nelson Castro	soporte@khesed-tek.com	\N	\N	$2a$12$nmzjKK/lFpsl2FM8ZSM.D.bL8zX8edeaBhXH0NcOo28R0Fie9TS3W	SUPER_ADMIN	\N	t	2025-08-30 22:13:49.73	2025-09-05 21:02:16.873
cmf8g5njz0004wm85ika2ru6m	Test User	testusera8880naj@example.com	\N	\N	$2a$12$ekOyOQ2YI.L7yWJ4yig3N.TCTU9rI/YPFhmRkjv4GQxDXk2m2D5Eq	ADMIN_IGLESIA	cmf8g5njq0000wm851h777hnb	t	2025-09-06 15:56:52.223	2025-09-06 15:56:52.223
cmf8jgltq0004wmkztpijorgj	Test User	testuserzcu4ddul@example.com	\N	\N	$2a$12$Ecd6bNKpv94DMRMr3AaoounEG9nkSvnLSaho8nIQDFFePIdj/AA.a	ADMIN_IGLESIA	cmf8jglte0000wmkzim9zee72	t	2025-09-06 17:29:22.047	2025-09-06 17:29:22.047
cmf8l2j8t0004zozzaq5r4nkb	Test User	testuseropogkkrl@example.com	\N	\N	$2a$12$XKQvzu9IXkNRshRp33JtP.2JW1o61wFtCU15VLN4NR1AF6kU64/7C	ADMIN_IGLESIA	cmf8l2j8l0000zozzbth9kmum	t	2025-09-06 18:14:24.75	2025-09-06 18:14:24.75
cmf8m09xc0004zol2ydc81v2g	Test User	testuser4ov75bfy@example.com	\N	\N	$2a$12$gwAgwYui/h721pDhtTy4uuOVUP1zKdUFWplNJyk.MfrFbjI0dGoLe	ADMIN_IGLESIA	cmf8m09x30000zol2oia50lkd	t	2025-09-06 18:40:38.976	2025-09-06 18:40:38.976
cmf8nkc790004zobhq4n0ntu2	Test User	testusereoy3ir7y@example.com	\N	\N	$2a$12$CTxhUBavomZ.sHUxIW6EPen.dfcrXpJGDPb1NeakqexZdG1XagGeu	ADMIN_IGLESIA	cmf8nkc6y0000zobhy1ybl7hk	t	2025-09-06 19:24:14.661	2025-09-06 19:24:14.661
cmf8rb93y0002mt01krrj2h2i	PEDRO CARRERA	PEDROCARRERA@GMAIL.COM	2025-09-06 21:09:09.214	\N	$2a$12$Du33OXQ7P5Mi4kooo9H4hOwQg8STPkJXcapRD9prEhEfbJirm2Ttm	ADMIN_IGLESIA	cmf8rb8v60000mt0148xslbte	t	2025-09-06 21:09:09.215	2025-09-06 21:09:09.215
cmf8se6jg00040hrdwvqrmqsw	Test User	testuserd3hruwvn@example.com	\N	\N	$2a$12$JLU4x5u6ukZsyCostokFLuzaHLPPk1YwZkunIekobceiEALAIfH5m	ADMIN_IGLESIA	cmf8se6j700000hrdcsgpog77	t	2025-09-06 21:39:25.469	2025-09-06 21:39:25.469
cmf8tfub500040hp15c8ne7vv	Test User	testuser26wdw5m4@example.com	\N	\N	$2a$12$wd5MSb2vgEMn8qDGDMDWi.Q9vP.x6yVvJYPSyq1Kc9ZDccbz/ASvK	ADMIN_IGLESIA	cmf8tfuaw00000hp1oen710io	t	2025-09-06 22:08:42.545	2025-09-06 22:08:42.545
cmf8tw0j000040he1ioisk2dh	Test User	testuserrv3inksy@example.com	\N	\N	$2a$12$Vr/v5YiHKD1aCXNGTMnXJediOOHxYHssy8Se9xpmLQokYe41qSBQ6	ADMIN_IGLESIA	cmf8tw0iv00000he1hsz6dsju	t	2025-09-06 22:21:17.101	2025-09-06 22:21:17.101
cmf8udnku0002s101efrwt89o	TONY PILARTE	tonypilarte@gmail.com	2025-09-06 22:35:00.126	\N	$2a$12$oN7EqVo6YPF7hKF3xRncc.ebliB1NLMN4FQMI9nJnSL9CX0Kmc9Xm	ADMIN_IGLESIA	cmf8udnbz0000s101ohl648q7	t	2025-09-06 22:35:00.127	2025-09-06 22:37:43.669
cmf8vhaxa00040h49izdznzpf	Test User	testuserzin8wqmi@example.com	\N	\N	$2a$12$IExGULBjr784K.w/w6EC1OoQ4nvpNiOTrO4xT.OBiLs3ToHdYm222	ADMIN_IGLESIA	cmf8vhax200000h49hwrlwkdt	t	2025-09-06 23:05:49.966	2025-09-06 23:05:49.966
cmf8vpiqo00040hl3troihuhi	Test User	testuser5nt3htkw@example.com	\N	\N	$2a$12$qcYGsUR46.TNcOjRyDORvew6Hb02CimDndxH3Iv8VZJ1hSMaH/ipu	ADMIN_IGLESIA	cmf8vpiqk00000hl309k0bgkh	t	2025-09-06 23:12:13.344	2025-09-06 23:12:13.344
cmf8x48zo00040hlxwguog6hm	Test User	testuser58lxhn98@example.com	\N	\N	$2a$12$wImzOgp7jwsURDjkz/NRjuRn2vJcSODSpXqODzylQ.ZOq.B9Gdvoa	ADMIN_IGLESIA	cmf8x48zg00000hlxgyjpc7e0	t	2025-09-06 23:51:40.165	2025-09-06 23:51:40.165
cmf8olij60004zow4r1ijv63b	Test User	testuserc795l7q7@example.com	\N	\N	$2a$12$omr4C9.MYjLGWsQxvlDcseoC2haWMyZgogUKCPFkHy/pCgulo/dyO	ADMIN_IGLESIA	cmf8oliiw0000zow4q4zq31ez	f	2025-09-06 19:53:09.138	2025-09-07 00:17:57.26
cmf8qt52z00040hqrxxc7kzxk	Test User	testuser7sr4vmzx@example.com	\N	\N	$2a$12$jIYi5i4ojRCTpUYUkyFZO.oj59hraR.YIeiEw/NQ6uDrBKah.vJZi	ADMIN_IGLESIA	cmf8qt52p00000hqreyjwk5al	f	2025-09-06 20:55:04.187	2025-09-07 00:18:09.421
cmfbf4e0f0004tyrp9t6e37s8	Test User	testuser8l3xnyvn@example.com	\N	\N	$2a$12$OR9e7vkvefX0v/h/qivhve0lLNLbtXSBNQs4GmkukHuYEbnO2OE86	ADMIN_IGLESIA	cmfbf4e020000tyrpgns0kbnq	t	2025-09-08 17:51:12.112	2025-09-08 17:51:12.112
cmfbfxla00004tybmrpkk9hz2	Test User	testuserxrmhq8dm@example.com	\N	\N	$2a$12$lHQBd7RijCBr/en4waPJGu5.Coe.J/jVk4u0WgIoH/yh.GaX./RtW	ADMIN_IGLESIA	cmfbfxl9q0000tybm5bfrp0mc	t	2025-09-08 18:13:54.553	2025-09-08 18:13:54.553
cmfbmddi30004uyyztt4kp4gw	Test User	testuser1yvruf1d@example.com	\N	\N	$2a$12$B22QWXXYNDcW3niwIvmbyOzZKB/yX88GY3UcRa9ahC0od0vfDaouK	ADMIN_IGLESIA	cmfbmddhx0000uyyzzgmhz09z	t	2025-09-08 21:14:08.667	2025-09-08 21:14:08.667
cmfbnh7t40004uylnxhovzmsj	Test User	testuser29229t3p@example.com	\N	\N	$2a$12$iXbAjkd1ratJp74LNMe7N.82c2E0dIybpt1pCPOAeIpEhorAFSYR.	ADMIN_IGLESIA	cmfbnh7sv0000uylnq5rdr1qp	t	2025-09-08 21:45:07.529	2025-09-08 21:45:07.529
cmfbocb0t0004uynzu2mfqr65	Test User	testuser663wtknw@example.com	\N	\N	$2a$12$Wj8K7qALhTPFsRWG4ete0uiEuBOn4mAgQ6N5kNHf3DXa/mX9nzBmS	ADMIN_IGLESIA	cmfbocb0p0000uynz5m7l3i6s	t	2025-09-08 22:09:18.029	2025-09-08 22:09:18.029
cmfbp2ui00004uywtwcf6ihnk	Test User	testusersf16e6ah@example.com	\N	\N	$2a$12$3yXtbn0sbDtuge7OmkvLJ.sC6kpMh3hUs.e3OAQVOnWRQu.rfoxaW	ADMIN_IGLESIA	cmfbp2uhv0000uywtp2b8d1wn	t	2025-09-08 22:29:56.328	2025-09-08 22:29:56.328
cmfh1xpat0004vux17ltnpkex	Test User	testuserzmih6oxi@example.com	\N	\N	$2a$12$de8rf5KJhe2/bZKOg15MT.yMB0RTREsvjmMWv.Pos1r8FJYuOG47C	ADMIN_IGLESIA	cmfh1xpac0000vux1gz7o2nwp	t	2025-09-12 16:28:42.197	2025-09-12 16:28:42.197
\.


--
-- TOC entry 4616 (class 0 OID 9480415)
-- Dependencies: 260
-- Data for Name: verification_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.verification_tokens (identifier, token, expires) FROM stdin;
\.


--
-- TOC entry 4587 (class 0 OID 9480114)
-- Dependencies: 231
-- Data for Name: visitor_follow_ups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.visitor_follow_ups (id, "checkInId", "followUpType", status, "scheduledAt", "completedAt", notes, "assignedTo", "churchId", "createdAt", "updatedAt", "automationRuleId", priority, category, "touchSequence", "responseReceived", "responseData", "nextActionDue", "ministryMatch") FROM stdin;
cmeytjgq9001gq8fcicjidnaz	cmeytjgq6001aq8fcolds131w	EMAIL	COMPLETADO	2025-08-31 22:13:49.809	2025-08-30 22:13:49.809	Email de bienvenida enviado exitosamente	cmeytjgo50007q8fce5bou6vw	demo-church	2025-08-30 22:13:49.81	2025-08-30 22:13:49.81	\N	MEDIUM	\N	\N	f	\N	\N	\N
cmeytjgq9001hq8fcloeakn6i	cmeytjgq6001aq8fcolds131w	LLAMADA	PENDIENTE	2025-09-02 22:13:49.809	\N	Llamada de seguimiento programada para 3 días después	cmeytjgo50007q8fce5bou6vw	demo-church	2025-08-30 22:13:49.81	2025-08-30 22:13:49.81	\N	MEDIUM	\N	\N	f	\N	\N	\N
cmeytjgq9001jq8fca4pmzvuf	cmeytjgq6001bq8fc8m84k534	EMAIL	PENDIENTE	2025-08-31 22:13:49.809	\N	Email de bienvenida programado	\N	demo-church	2025-08-30 22:13:49.81	2025-08-30 22:13:49.81	\N	MEDIUM	\N	\N	f	\N	\N	\N
cmeytjgqm001lq8fcqil9z8mr	cmeytjgq6001bq8fc8m84k534	LLAMADA	PENDIENTE	2025-09-01 22:13:49.809	\N	Llamada de seguimiento programada	cmeytjgnx0001q8fctjc12b43	demo-church	2025-08-30 22:13:49.81	2025-08-30 22:13:49.81	\N	MEDIUM	\N	\N	f	\N	\N	\N
cmf76ch3h001iugjfglydo2ki	cmf76ch3c001bugjf1jhx3mik	EMAIL	COMPLETADO	2025-09-06 18:34:28.109	2025-09-05 18:34:28.109	Email de bienvenida enviado exitosamente	cmeytjgo50007q8fce5bou6vw	demo-church	2025-09-05 18:34:28.11	2025-09-05 18:34:28.11	\N	MEDIUM	\N	\N	f	\N	\N	\N
cmf76ch3h001jugjf43qpvyp0	cmf76ch3c001cugjful753i6y	EMAIL	PENDIENTE	2025-09-06 18:34:28.109	\N	Email de bienvenida programado	\N	demo-church	2025-09-05 18:34:28.11	2025-09-05 18:34:28.11	\N	MEDIUM	\N	\N	f	\N	\N	\N
cmf76ch3h001hugjf4m9gnh8x	cmf76ch3c001bugjf1jhx3mik	LLAMADA	PENDIENTE	2025-09-08 18:34:28.109	\N	Llamada de seguimiento programada para 3 días después	cmeytjgo50007q8fce5bou6vw	demo-church	2025-09-05 18:34:28.11	2025-09-05 18:34:28.11	\N	MEDIUM	\N	\N	f	\N	\N	\N
cmf76ch3v001lugjfdumuwan7	cmf76ch3c001cugjful753i6y	LLAMADA	PENDIENTE	2025-09-07 18:34:28.109	\N	Llamada de seguimiento programada	cmeytjgnx0001q8fctjc12b43	demo-church	2025-09-05 18:34:28.11	2025-09-05 18:34:28.11	\N	MEDIUM	\N	\N	f	\N	\N	\N
cmfcreugz0003lr0163al5cq1	cmfcreugh0001lr01q6sgpju4	EMAIL	PENDIENTE	2025-09-10 16:23:01.571	\N	Email de bienvenida automático	\N	demo-church	2025-09-09 16:23:01.571	2025-09-09 16:23:01.571	\N	MEDIUM	\N	\N	f	\N	\N	\N
cmfcreuh40005lr012scpj4n0	cmfcreugh0001lr01q6sgpju4	LLAMADA	PENDIENTE	2025-09-12 16:23:01.576	\N	Llamada de seguimiento para visitante por primera vez	\N	demo-church	2025-09-09 16:23:01.576	2025-09-09 16:23:01.576	\N	MEDIUM	\N	\N	f	\N	\N	\N
cmfcrffyz0009lr014yppzzo6	cmfcrffyu0007lr01dmkxkr9e	EMAIL	PENDIENTE	2025-09-10 16:23:29.435	\N	Email de bienvenida automático	\N	demo-church	2025-09-09 16:23:29.435	2025-09-09 16:23:29.435	\N	MEDIUM	\N	\N	f	\N	\N	\N
cmfcrffz1000blr01ehowqz19	cmfcrffyu0007lr01dmkxkr9e	LLAMADA	PENDIENTE	2025-09-12 16:23:29.437	\N	Llamada de seguimiento para visitante por primera vez	\N	demo-church	2025-09-09 16:23:29.437	2025-09-09 16:23:29.437	\N	MEDIUM	\N	\N	f	\N	\N	\N
cmfcrfngn000flr010ekzn1fc	cmfcrfngi000dlr01gk0d1c2r	EMAIL	PENDIENTE	2025-09-10 16:23:39.143	\N	Email de bienvenida automático	\N	demo-church	2025-09-09 16:23:39.144	2025-09-09 16:23:39.144	\N	MEDIUM	\N	\N	f	\N	\N	\N
cmfcrfngp000hlr01c36wstz3	cmfcrfngi000dlr01gk0d1c2r	LLAMADA	PENDIENTE	2025-09-12 16:23:39.145	\N	Llamada de seguimiento para visitante por primera vez	\N	demo-church	2025-09-09 16:23:39.146	2025-09-09 16:23:39.146	\N	MEDIUM	\N	\N	f	\N	\N	\N
cmfe3dxct0003lb01mdxdgux8	cmfe3dxcb0001lb01tichkdfr	EMAIL	PENDIENTE	2025-09-11 14:46:00.221	\N	Email de bienvenida automático	\N	demo-church	2025-09-10 14:46:00.222	2025-09-10 14:46:00.222	\N	MEDIUM	\N	\N	f	\N	\N	\N
cmfe3dxcy0005lb01oa90nueo	cmfe3dxcb0001lb01tichkdfr	LLAMADA	PENDIENTE	2025-09-13 14:46:00.226	\N	Llamada de seguimiento para visitante por primera vez	\N	demo-church	2025-09-10 14:46:00.227	2025-09-10 14:46:00.227	\N	MEDIUM	\N	\N	f	\N	\N	\N
\.


--
-- TOC entry 4585 (class 0 OID 9480092)
-- Dependencies: 229
-- Data for Name: volunteer_assignments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.volunteer_assignments (id, "volunteerId", "eventId", title, description, date, "startTime", "endTime", status, notes, "churchId", "createdAt", "updatedAt") FROM stdin;
cmeytjgq30016q8fcyrs9z6l5	volunteer-2	cmeytjgpc000zq8fc1o1bpb12	Técnico de Sonido	Operar el equipo de sonido durante el servicio	2025-09-06 22:13:49.802	08:30	11:00	CONFIRMADO	\N	demo-church	2025-08-30 22:13:49.803	2025-08-30 22:13:49.803
cmeytjgq30017q8fc6j6ygwgc	volunteer-1	cmeytjgpc000zq8fc1o1bpb12	Líder de Adoración	Dirigir la adoración durante el servicio dominical	2025-09-06 22:13:49.802	09:00	10:30	ASIGNADO	\N	demo-church	2025-08-30 22:13:49.803	2025-08-30 22:13:49.803
cmf31sxr10001o401rg2y8m23	cmf3100fp0001t301a2tspj98	\N	LIDER DE JOVENES	JOVENES DE 15 A 18	2025-09-02 00:00:00	08:15	17:16	ASIGNADO		demo-church	2025-09-02 21:16:13.405	2025-09-02 21:16:13.405
cmf4ipqps0001pe01uwpoefrt	cmf3100fp0001t301a2tspj98	\N	MUSICO		2025-09-02 00:00:00	19:00	21:00	ASIGNADO		demo-church	2025-09-03 21:57:23.968	2025-09-03 21:57:23.968
cmf4ji73j0001o201i5ewmcyp	cmf3100fp0001t301a2tspj98	\N	MUSICO		2025-09-02 00:00:00	19:20	21:20	ASIGNADO		demo-church	2025-09-03 22:19:31.568	2025-09-03 22:19:31.568
cmf76ch360016ugjfzyiz8387	volunteer-2	cmf76ch2a000zugjfkkjhyq7c	Técnico de Sonido	Operar el equipo de sonido durante el servicio	2025-09-12 18:34:28.098	08:30	11:00	CONFIRMADO	\N	demo-church	2025-09-05 18:34:28.099	2025-09-05 18:34:28.099
cmf76ch360017ugjfvxx2moiy	volunteer-1	cmf76ch2a000zugjfkkjhyq7c	Líder de Adoración	Dirigir la adoración durante el servicio dominical	2025-09-12 18:34:28.098	09:00	10:30	ASIGNADO	\N	demo-church	2025-09-05 18:34:28.099	2025-09-05 18:34:28.099
\.


--
-- TOC entry 4658 (class 0 OID 9480866)
-- Dependencies: 302
-- Data for Name: volunteer_engagement_scores; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.volunteer_engagement_scores (id, "volunteerId", "currentScore", "participationRate", "consistencyScore", "feedbackScore", "growthTrend", "lastActivityDate", "burnoutRisk", "recommendedActions", "calculatedAt", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4656 (class 0 OID 9480845)
-- Dependencies: 300
-- Data for Name: volunteer_recommendations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.volunteer_recommendations (id, "memberId", "ministryId", "eventId", "recommendationType", "matchScore", reasoning, status, priority, "validUntil", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4584 (class 0 OID 9480083)
-- Dependencies: 228
-- Data for Name: volunteers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.volunteers (id, "memberId", "firstName", "lastName", email, phone, skills, availability, "ministryId", "churchId", "isActive", "createdAt", "updatedAt") FROM stdin;
volunteer-1	\N	Ana	García	ana@email.com	+1234567891	["Música","Coro","Piano"]	{"domingo":["09:00-12:00"],"miercoles":["19:00-21:00"]}	ministry-ministerio-de-alabanza	demo-church	t	2025-08-30 22:13:49.783	2025-08-30 22:13:49.783
volunteer-3	\N	Sofia	López	sofia@email.com	+1234567893	["Niños","Enseñanza","Manualidades"]	{"domingo":["09:30-11:30"],"jueves":["18:00-20:00"]}	ministry-ministerio-de-niños	demo-church	t	2025-08-30 22:13:49.783	2025-08-30 22:13:49.783
volunteer-2	\N	Pedro	Martínez	pedro@email.com	+1234567892	["Sonido","Tecnología","Proyección"]	{"domingo":["08:00-13:00"],"sabado":["18:00-22:00"]}	ministry-ministerio-de-jóvenes	demo-church	t	2025-08-30 22:13:49.783	2025-08-30 22:13:49.783
cmf3100fp0001t301a2tspj98	cmf2zrjok0001qt01lpqehwa4	JUAN 	PACHANGA			\N	\N	\N	demo-church	t	2025-09-02 20:53:43.861	2025-09-02 20:53:43.861
cmf4hm5wd0003n001c4ia9ism	cmeytjgp2000rq8fczh09q392	Carlos	Ruiz	pastor@iglesiacentral.com	+1234567891	\N	\N	\N	demo-church	t	2025-09-03 21:26:37.406	2025-09-03 21:26:37.406
cmfe5gucf0001qj01y7l1kd47	cmf76ch1t000nugjfxhh83umo	Roberto	Jiménez	roberto.jimenez@email.com	+1234567808	\N	\N	\N	demo-church	t	2025-09-10 15:44:15.519	2025-09-10 15:44:15.519
cmfe5inph0003qj01p2frkzxr	cmf76ch1r000lugjfrv8nchlt	Lucía	Morales	lucia.morales@email.com	+1234567807	\N	\N	\N	demo-church	t	2025-09-10 15:45:40.229	2025-09-10 15:45:40.229
cmfe5iqei0005qj01mx3qo213	cmf76ch1p000jugjfjnipq8qd	David	Hernández	david.hernandez@email.com	+1234567806	\N	\N	\N	demo-church	t	2025-09-10 15:45:43.722	2025-09-10 15:45:43.722
cmfe5isvo0007qj01vy9mtgim	cmf76ch1m000hugjf2r3hkr2h	Carmen	Rodríguez	carmen.rodriguez@email.com	+1234567805	\N	\N	\N	demo-church	t	2025-09-10 15:45:46.932	2025-09-10 15:45:46.932
cmfe5ivtl0009qj01bkek7hc6	cmf76ch1k000fugjfjb1xk65k	Miguel	Torres	miguel.torres@email.com	+1234567804	\N	\N	\N	demo-church	t	2025-09-10 15:45:50.746	2025-09-10 15:45:50.746
cmfe5iy1y000bqj01mxkhylgf	cmf76ch1i000dugjfcpgf5ciw	Sofia	García	sofia.garcia@email.com	+1234567803	\N	\N	\N	demo-church	t	2025-09-10 15:45:53.638	2025-09-10 15:45:53.638
cmfe5j0k3000dqj010bb4snzd	cmf76ch1g000bugjf3rsuewh0	Pedro	López	pedro.lopez@email.com	+1234567802	\N	\N	\N	demo-church	t	2025-09-10 15:45:56.883	2025-09-10 15:45:56.883
cmfe5j3i1000fqj014m4dursv	cmf76ch1b0009ugjfx5mjzfpb	Ana	Martínez	ana.martinez@email.com	+1234567801	\N	\N	\N	demo-church	t	2025-09-10 15:46:00.698	2025-09-10 15:46:00.698
cmfe5j5oy000hqj01xze3sts4	cmeytjgoz000pq8fcbtvgzby4	María	González	admin@iglesiacentral.com	+1234567890	\N	\N	\N	demo-church	t	2025-09-10 15:46:03.539	2025-09-10 15:46:03.539
cmfe5j8gp000jqj01r5vbqay6	cmeytjgox000nq8fcuc6hmdvf	Roberto	Jiménez	roberto.jimenez@email.com	+1234567808	\N	\N	\N	demo-church	t	2025-09-10 15:46:07.129	2025-09-10 15:46:07.129
cmfe5jb8m000lqj01otfpy2o4	cmeytjgov000lq8fcnlwz6v5m	Lucía	Morales	lucia.morales@email.com	+1234567807	\N	\N	\N	demo-church	t	2025-09-10 15:46:10.726	2025-09-10 15:46:10.726
cmfe5jdv8000nqj01z47wy2pi	cmeytjgot000jq8fcj6k0yvkf	David	Hernández	david.hernandez@email.com	+1234567806	\N	\N	\N	demo-church	t	2025-09-10 15:46:14.132	2025-09-10 15:46:14.132
cmfe5jipz000pqj011r9v30ki	cmeytjgor000hq8fct2xw3j65	Carmen	Rodríguez	carmen.rodriguez@email.com	+1234567805	\N	\N	\N	demo-church	t	2025-09-10 15:46:20.423	2025-09-10 15:46:20.423
cmfe5jkqq000rqj0109l93fp6	cmeytjgoq000fq8fc9pyni8we	Miguel	Torres	miguel.torres@email.com	+1234567804	\N	\N	\N	demo-church	t	2025-09-10 15:46:23.043	2025-09-10 15:46:23.043
cmfe5jn30000tqj01x1f2w0uw	cmeytjgoo000dq8fctigwv6sc	Sofia	García	sofia.garcia@email.com	+1234567803	\N	\N	\N	demo-church	t	2025-09-10 15:46:26.076	2025-09-10 15:46:26.076
cmfe5jpje000vqj01tska096l	cmeytjgom000bq8fcnvp6sn6u	Pedro	López	pedro.lopez@email.com	+1234567802	\N	\N	\N	demo-church	t	2025-09-10 15:46:29.258	2025-09-10 15:46:29.258
cmfe5jrrk000xqj0174msewv8	cmeytjgok0009q8fc9cvk8h87	Ana	Martínez	ana.martinez@email.com	+1234567801	\N	\N	\N	demo-church	t	2025-09-10 15:46:32.145	2025-09-10 15:46:32.145
\.


--
-- TOC entry 4619 (class 0 OID 9480445)
-- Dependencies: 263
-- Data for Name: web_page_sections; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.web_page_sections (id, type, content, "order", "isVisible", "pageId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4618 (class 0 OID 9480434)
-- Dependencies: 262
-- Data for Name: web_pages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.web_pages (id, title, slug, content, "metaTitle", "metaDescription", "metaImage", "isHomePage", "isPublished", "order", "websiteId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4623 (class 0 OID 9480482)
-- Dependencies: 267
-- Data for Name: website_analytics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.website_analytics (id, "pageViews", "uniqueVisitors", "bounceRate", "avgSessionDuration", referrer, page, date, "websiteId", "createdAt") FROM stdin;
\.


--
-- TOC entry 4659 (class 0 OID 9480881)
-- Dependencies: 303
-- Data for Name: website_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.website_requests (id, "churchId", "requestType", "projectName", description, status, priority, "contactEmail", phone, "estimatedPrice", "finalPrice", "estimatedCompletion", "completedAt", "adminNotes", metadata, "existingWebsiteId", "resultingWebsiteId", "assignedTo", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4617 (class 0 OID 9480420)
-- Dependencies: 261
-- Data for Name: websites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.websites (id, name, slug, domain, description, theme, "primaryColor", "secondaryColor", "accentColor", "fontFamily", "metaTitle", "metaDescription", "metaImage", metadata, "isPublished", "isActive", "churchId", "createdAt", "updatedAt") FROM stdin;
\.


--
-- TOC entry 4107 (class 2606 OID 9480407)
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- TOC entry 4105 (class 2606 OID 9480400)
-- Name: analytics_cache analytics_cache_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.analytics_cache
    ADD CONSTRAINT analytics_cache_pkey PRIMARY KEY (id);


--
-- TOC entry 4098 (class 2606 OID 9480370)
-- Name: analytics_dashboards analytics_dashboards_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.analytics_dashboards
    ADD CONSTRAINT analytics_dashboards_pkey PRIMARY KEY (id);


--
-- TOC entry 4155 (class 2606 OID 9480570)
-- Name: automation_actions automation_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_actions
    ADD CONSTRAINT automation_actions_pkey PRIMARY KEY (id);


--
-- TOC entry 4150 (class 2606 OID 9480558)
-- Name: automation_conditions automation_conditions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_conditions
    ADD CONSTRAINT automation_conditions_pkey PRIMARY KEY (id);


--
-- TOC entry 4077 (class 2606 OID 9480283)
-- Name: automation_executions automation_executions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_executions
    ADD CONSTRAINT automation_executions_pkey PRIMARY KEY (id);


--
-- TOC entry 4160 (class 2606 OID 9480579)
-- Name: automation_rule_executions automation_rule_executions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_rule_executions
    ADD CONSTRAINT automation_rule_executions_pkey PRIMARY KEY (id);


--
-- TOC entry 4141 (class 2606 OID 9480537)
-- Name: automation_rules automation_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_rules
    ADD CONSTRAINT automation_rules_pkey PRIMARY KEY (id);


--
-- TOC entry 4166 (class 2606 OID 9480590)
-- Name: automation_templates automation_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_templates
    ADD CONSTRAINT automation_templates_pkey PRIMARY KEY (id);


--
-- TOC entry 4145 (class 2606 OID 9480547)
-- Name: automation_triggers automation_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_triggers
    ADD CONSTRAINT automation_triggers_pkey PRIMARY KEY (id);


--
-- TOC entry 4075 (class 2606 OID 9480274)
-- Name: automations automations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automations
    ADD CONSTRAINT automations_pkey PRIMARY KEY (id);


--
-- TOC entry 4248 (class 2606 OID 9480844)
-- Name: availability_matrices availability_matrices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.availability_matrices
    ADD CONSTRAINT availability_matrices_pkey PRIMARY KEY (id);


--
-- TOC entry 4043 (class 2606 OID 9480113)
-- Name: check_ins check_ins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.check_ins
    ADD CONSTRAINT check_ins_pkey PRIMARY KEY (id);


--
-- TOC entry 4048 (class 2606 OID 9480139)
-- Name: children_check_ins children_check_ins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.children_check_ins
    ADD CONSTRAINT children_check_ins_pkey PRIMARY KEY (id);


--
-- TOC entry 4281 (class 2606 OID 9671099)
-- Name: church_qualification_settings church_qualification_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.church_qualification_settings
    ADD CONSTRAINT church_qualification_settings_pkey PRIMARY KEY (id);


--
-- TOC entry 4195 (class 2606 OID 9480662)
-- Name: church_subscription_addons church_subscription_addons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.church_subscription_addons
    ADD CONSTRAINT church_subscription_addons_pkey PRIMARY KEY (id);


--
-- TOC entry 4191 (class 2606 OID 9480652)
-- Name: church_subscriptions church_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.church_subscriptions
    ADD CONSTRAINT church_subscriptions_pkey PRIMARY KEY (id);


--
-- TOC entry 4137 (class 2606 OID 9480525)
-- Name: church_themes church_themes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.church_themes
    ADD CONSTRAINT church_themes_pkey PRIMARY KEY (id);


--
-- TOC entry 4009 (class 2606 OID 9479985)
-- Name: churches churches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.churches
    ADD CONSTRAINT churches_pkey PRIMARY KEY (id);


--
-- TOC entry 4067 (class 2606 OID 9480238)
-- Name: communication_templates communication_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_templates
    ADD CONSTRAINT communication_templates_pkey PRIMARY KEY (id);


--
-- TOC entry 4065 (class 2606 OID 9480229)
-- Name: communications communications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communications
    ADD CONSTRAINT communications_pkey PRIMARY KEY (id);


--
-- TOC entry 4092 (class 2606 OID 9480342)
-- Name: custom_reports custom_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_reports
    ADD CONSTRAINT custom_reports_pkey PRIMARY KEY (id);


--
-- TOC entry 4100 (class 2606 OID 9480380)
-- Name: dashboard_widgets dashboard_widgets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_widgets
    ADD CONSTRAINT dashboard_widgets_pkey PRIMARY KEY (id);


--
-- TOC entry 4210 (class 2606 OID 9480711)
-- Name: donation_campaigns donation_campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.donation_campaigns
    ADD CONSTRAINT donation_campaigns_pkey PRIMARY KEY (id);


--
-- TOC entry 4051 (class 2606 OID 9480148)
-- Name: donation_categories donation_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.donation_categories
    ADD CONSTRAINT donation_categories_pkey PRIMARY KEY (id);


--
-- TOC entry 4055 (class 2606 OID 9480170)
-- Name: donations donations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.donations
    ADD CONSTRAINT donations_pkey PRIMARY KEY (id);


--
-- TOC entry 4071 (class 2606 OID 9480256)
-- Name: event_resource_reservations event_resource_reservations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_resource_reservations
    ADD CONSTRAINT event_resource_reservations_pkey PRIMARY KEY (id);


--
-- TOC entry 4069 (class 2606 OID 9480247)
-- Name: event_resources event_resources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_resources
    ADD CONSTRAINT event_resources_pkey PRIMARY KEY (id);


--
-- TOC entry 4037 (class 2606 OID 9480082)
-- Name: events events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- TOC entry 4129 (class 2606 OID 9480481)
-- Name: funnel_conversions funnel_conversions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.funnel_conversions
    ADD CONSTRAINT funnel_conversions_pkey PRIMARY KEY (id);


--
-- TOC entry 4127 (class 2606 OID 9480473)
-- Name: funnel_steps funnel_steps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.funnel_steps
    ADD CONSTRAINT funnel_steps_pkey PRIMARY KEY (id);


--
-- TOC entry 4123 (class 2606 OID 9480464)
-- Name: funnels funnels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.funnels
    ADD CONSTRAINT funnels_pkey PRIMARY KEY (id);


--
-- TOC entry 4073 (class 2606 OID 9480265)
-- Name: integration_configs integration_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.integration_configs
    ADD CONSTRAINT integration_configs_pkey PRIMARY KEY (id);


--
-- TOC entry 4274 (class 2606 OID 9579035)
-- Name: invoice_communications invoice_communications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_communications
    ADD CONSTRAINT invoice_communications_pkey PRIMARY KEY (id);


--
-- TOC entry 4268 (class 2606 OID 9579017)
-- Name: invoice_line_items invoice_line_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_line_items
    ADD CONSTRAINT invoice_line_items_pkey PRIMARY KEY (id);


--
-- TOC entry 4271 (class 2606 OID 9579026)
-- Name: invoice_payments invoice_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_payments
    ADD CONSTRAINT invoice_payments_pkey PRIMARY KEY (id);


--
-- TOC entry 4265 (class 2606 OID 9579008)
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- TOC entry 4102 (class 2606 OID 9480392)
-- Name: kpi_metrics kpi_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kpi_metrics
    ADD CONSTRAINT kpi_metrics_pkey PRIMARY KEY (id);


--
-- TOC entry 4087 (class 2606 OID 9480321)
-- Name: marketing_campaign_posts marketing_campaign_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.marketing_campaign_posts
    ADD CONSTRAINT marketing_campaign_posts_pkey PRIMARY KEY (id);


--
-- TOC entry 4084 (class 2606 OID 9480311)
-- Name: marketing_campaigns marketing_campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.marketing_campaigns
    ADD CONSTRAINT marketing_campaigns_pkey PRIMARY KEY (id);


--
-- TOC entry 4245 (class 2606 OID 9480833)
-- Name: member_spiritual_profiles member_spiritual_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_spiritual_profiles
    ADD CONSTRAINT member_spiritual_profiles_pkey PRIMARY KEY (id);


--
-- TOC entry 4032 (class 2606 OID 9480064)
-- Name: members members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_pkey PRIMARY KEY (id);


--
-- TOC entry 4011 (class 2606 OID 9479994)
-- Name: ministries ministries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ministries
    ADD CONSTRAINT ministries_pkey PRIMARY KEY (id);


--
-- TOC entry 4252 (class 2606 OID 9480865)
-- Name: ministry_gap_analyses ministry_gap_analyses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ministry_gap_analyses
    ADD CONSTRAINT ministry_gap_analyses_pkey PRIMARY KEY (id);


--
-- TOC entry 4059 (class 2606 OID 9480208)
-- Name: notification_preferences notification_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_pkey PRIMARY KEY (id);


--
-- TOC entry 4063 (class 2606 OID 9480220)
-- Name: notification_templates notification_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_templates
    ADD CONSTRAINT notification_templates_pkey PRIMARY KEY (id);


--
-- TOC entry 4057 (class 2606 OID 9480181)
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- TOC entry 4204 (class 2606 OID 9480689)
-- Name: online_payments online_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.online_payments
    ADD CONSTRAINT online_payments_pkey PRIMARY KEY (id);


--
-- TOC entry 4208 (class 2606 OID 9480699)
-- Name: payment_gateway_configs payment_gateway_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_gateway_configs
    ADD CONSTRAINT payment_gateway_configs_pkey PRIMARY KEY (id);


--
-- TOC entry 4053 (class 2606 OID 9480158)
-- Name: payment_methods payment_methods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_methods
    ADD CONSTRAINT payment_methods_pkey PRIMARY KEY (id);


--
-- TOC entry 4014 (class 2606 OID 9480003)
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- TOC entry 4184 (class 2606 OID 9480631)
-- Name: plan_features plan_features_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_features
    ADD CONSTRAINT plan_features_pkey PRIMARY KEY (id);


--
-- TOC entry 4259 (class 2606 OID 9480907)
-- Name: platform_settings platform_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.platform_settings
    ADD CONSTRAINT platform_settings_pkey PRIMARY KEY (id);


--
-- TOC entry 4224 (class 2606 OID 9480761)
-- Name: prayer_approvals prayer_approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_approvals
    ADD CONSTRAINT prayer_approvals_pkey PRIMARY KEY (id);


--
-- TOC entry 4214 (class 2606 OID 9480720)
-- Name: prayer_categories prayer_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_categories
    ADD CONSTRAINT prayer_categories_pkey PRIMARY KEY (id);


--
-- TOC entry 4220 (class 2606 OID 9480741)
-- Name: prayer_contacts prayer_contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_contacts
    ADD CONSTRAINT prayer_contacts_pkey PRIMARY KEY (id);


--
-- TOC entry 4227 (class 2606 OID 9480771)
-- Name: prayer_forms prayer_forms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_forms
    ADD CONSTRAINT prayer_forms_pkey PRIMARY KEY (id);


--
-- TOC entry 4231 (class 2606 OID 9480781)
-- Name: prayer_qr_codes prayer_qr_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_qr_codes
    ADD CONSTRAINT prayer_qr_codes_pkey PRIMARY KEY (id);


--
-- TOC entry 4222 (class 2606 OID 9480752)
-- Name: prayer_requests prayer_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_requests
    ADD CONSTRAINT prayer_requests_pkey PRIMARY KEY (id);


--
-- TOC entry 4216 (class 2606 OID 9480730)
-- Name: prayer_response_templates prayer_response_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_response_templates
    ADD CONSTRAINT prayer_response_templates_pkey PRIMARY KEY (id);


--
-- TOC entry 4233 (class 2606 OID 9480794)
-- Name: prayer_testimonies prayer_testimonies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_testimonies
    ADD CONSTRAINT prayer_testimonies_pkey PRIMARY KEY (id);


--
-- TOC entry 4176 (class 2606 OID 9480609)
-- Name: push_notification_logs push_notification_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_notification_logs
    ADD CONSTRAINT push_notification_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 4170 (class 2606 OID 9480599)
-- Name: push_subscriptions push_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT push_subscriptions_pkey PRIMARY KEY (id);


--
-- TOC entry 4096 (class 2606 OID 9480360)
-- Name: report_executions report_executions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_executions
    ADD CONSTRAINT report_executions_pkey PRIMARY KEY (id);


--
-- TOC entry 4094 (class 2606 OID 9480352)
-- Name: report_schedules report_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_schedules
    ADD CONSTRAINT report_schedules_pkey PRIMARY KEY (id);


--
-- TOC entry 4020 (class 2606 OID 9480022)
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (id);


--
-- TOC entry 4018 (class 2606 OID 9480014)
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- TOC entry 4035 (class 2606 OID 9480073)
-- Name: sermons sermons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sermons
    ADD CONSTRAINT sermons_pkey PRIMARY KEY (id);


--
-- TOC entry 4110 (class 2606 OID 9480414)
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- TOC entry 4079 (class 2606 OID 9480292)
-- Name: social_media_accounts social_media_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_media_accounts
    ADD CONSTRAINT social_media_accounts_pkey PRIMARY KEY (id);


--
-- TOC entry 4090 (class 2606 OID 9480331)
-- Name: social_media_metrics social_media_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_media_metrics
    ADD CONSTRAINT social_media_metrics_pkey PRIMARY KEY (id);


--
-- TOC entry 4082 (class 2606 OID 9480301)
-- Name: social_media_posts social_media_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_media_posts
    ADD CONSTRAINT social_media_posts_pkey PRIMARY KEY (id);


--
-- TOC entry 4242 (class 2606 OID 9480822)
-- Name: spiritual_gifts spiritual_gifts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spiritual_gifts
    ADD CONSTRAINT spiritual_gifts_pkey PRIMARY KEY (id);


--
-- TOC entry 4187 (class 2606 OID 9480641)
-- Name: subscription_addons subscription_addons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_addons
    ADD CONSTRAINT subscription_addons_pkey PRIMARY KEY (id);


--
-- TOC entry 4181 (class 2606 OID 9480622)
-- Name: subscription_plans subscription_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_pkey PRIMARY KEY (id);


--
-- TOC entry 4198 (class 2606 OID 9480678)
-- Name: support_contact_info support_contact_info_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_contact_info
    ADD CONSTRAINT support_contact_info_pkey PRIMARY KEY (id);


--
-- TOC entry 4278 (class 2606 OID 9579044)
-- Name: tenant_credentials tenant_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenant_credentials
    ADD CONSTRAINT tenant_credentials_pkey PRIMARY KEY (id);


--
-- TOC entry 4235 (class 2606 OID 9480804)
-- Name: testimony_forms testimony_forms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.testimony_forms
    ADD CONSTRAINT testimony_forms_pkey PRIMARY KEY (id);


--
-- TOC entry 4239 (class 2606 OID 9480814)
-- Name: testimony_qr_codes testimony_qr_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.testimony_qr_codes
    ADD CONSTRAINT testimony_qr_codes_pkey PRIMARY KEY (id);


--
-- TOC entry 4023 (class 2606 OID 9480031)
-- Name: user_permissions user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_pkey PRIMARY KEY (id);


--
-- TOC entry 4026 (class 2606 OID 9480040)
-- Name: user_roles_advanced user_roles_advanced_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles_advanced
    ADD CONSTRAINT user_roles_advanced_pkey PRIMARY KEY (id);


--
-- TOC entry 4133 (class 2606 OID 9480508)
-- Name: user_theme_preferences user_theme_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_theme_preferences
    ADD CONSTRAINT user_theme_preferences_pkey PRIMARY KEY (id);


--
-- TOC entry 4030 (class 2606 OID 9480050)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 4046 (class 2606 OID 9480124)
-- Name: visitor_follow_ups visitor_follow_ups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visitor_follow_ups
    ADD CONSTRAINT visitor_follow_ups_pkey PRIMARY KEY (id);


--
-- TOC entry 4041 (class 2606 OID 9480100)
-- Name: volunteer_assignments volunteer_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.volunteer_assignments
    ADD CONSTRAINT volunteer_assignments_pkey PRIMARY KEY (id);


--
-- TOC entry 4254 (class 2606 OID 9480880)
-- Name: volunteer_engagement_scores volunteer_engagement_scores_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.volunteer_engagement_scores
    ADD CONSTRAINT volunteer_engagement_scores_pkey PRIMARY KEY (id);


--
-- TOC entry 4250 (class 2606 OID 9480854)
-- Name: volunteer_recommendations volunteer_recommendations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.volunteer_recommendations
    ADD CONSTRAINT volunteer_recommendations_pkey PRIMARY KEY (id);


--
-- TOC entry 4039 (class 2606 OID 9480091)
-- Name: volunteers volunteers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.volunteers
    ADD CONSTRAINT volunteers_pkey PRIMARY KEY (id);


--
-- TOC entry 4121 (class 2606 OID 9480454)
-- Name: web_page_sections web_page_sections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.web_page_sections
    ADD CONSTRAINT web_page_sections_pkey PRIMARY KEY (id);


--
-- TOC entry 4118 (class 2606 OID 9480444)
-- Name: web_pages web_pages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.web_pages
    ADD CONSTRAINT web_pages_pkey PRIMARY KEY (id);


--
-- TOC entry 4131 (class 2606 OID 9480492)
-- Name: website_analytics website_analytics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.website_analytics
    ADD CONSTRAINT website_analytics_pkey PRIMARY KEY (id);


--
-- TOC entry 4257 (class 2606 OID 9480890)
-- Name: website_requests website_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.website_requests
    ADD CONSTRAINT website_requests_pkey PRIMARY KEY (id);


--
-- TOC entry 4115 (class 2606 OID 9480433)
-- Name: websites websites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.websites
    ADD CONSTRAINT websites_pkey PRIMARY KEY (id);


--
-- TOC entry 4108 (class 1259 OID 9480924)
-- Name: accounts_provider_providerAccountId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "accounts_provider_providerAccountId_key" ON public.accounts USING btree (provider, "providerAccountId");


--
-- TOC entry 4103 (class 1259 OID 9480923)
-- Name: analytics_cache_cacheKey_churchId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "analytics_cache_cacheKey_churchId_key" ON public.analytics_cache USING btree ("cacheKey", "churchId");


--
-- TOC entry 4153 (class 1259 OID 9480945)
-- Name: automation_actions_orderIndex_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "automation_actions_orderIndex_idx" ON public.automation_actions USING btree ("orderIndex");


--
-- TOC entry 4156 (class 1259 OID 9480943)
-- Name: automation_actions_ruleId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "automation_actions_ruleId_idx" ON public.automation_actions USING btree ("ruleId");


--
-- TOC entry 4157 (class 1259 OID 9480944)
-- Name: automation_actions_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX automation_actions_type_idx ON public.automation_actions USING btree (type);


--
-- TOC entry 4148 (class 1259 OID 9480942)
-- Name: automation_conditions_groupId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "automation_conditions_groupId_idx" ON public.automation_conditions USING btree ("groupId");


--
-- TOC entry 4151 (class 1259 OID 9480940)
-- Name: automation_conditions_ruleId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "automation_conditions_ruleId_idx" ON public.automation_conditions USING btree ("ruleId");


--
-- TOC entry 4152 (class 1259 OID 9480941)
-- Name: automation_conditions_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX automation_conditions_type_idx ON public.automation_conditions USING btree (type);


--
-- TOC entry 4158 (class 1259 OID 9480948)
-- Name: automation_rule_executions_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "automation_rule_executions_createdAt_idx" ON public.automation_rule_executions USING btree ("createdAt");


--
-- TOC entry 4161 (class 1259 OID 9480946)
-- Name: automation_rule_executions_ruleId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "automation_rule_executions_ruleId_idx" ON public.automation_rule_executions USING btree ("ruleId");


--
-- TOC entry 4162 (class 1259 OID 9480947)
-- Name: automation_rule_executions_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX automation_rule_executions_status_idx ON public.automation_rule_executions USING btree (status);


--
-- TOC entry 4138 (class 1259 OID 9480934)
-- Name: automation_rules_churchId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "automation_rules_churchId_idx" ON public.automation_rules USING btree ("churchId");


--
-- TOC entry 4139 (class 1259 OID 9480935)
-- Name: automation_rules_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "automation_rules_isActive_idx" ON public.automation_rules USING btree ("isActive");


--
-- TOC entry 4142 (class 1259 OID 9480936)
-- Name: automation_rules_priority_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX automation_rules_priority_idx ON public.automation_rules USING btree (priority);


--
-- TOC entry 4163 (class 1259 OID 9480949)
-- Name: automation_templates_category_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX automation_templates_category_idx ON public.automation_templates USING btree (category);


--
-- TOC entry 4164 (class 1259 OID 9480950)
-- Name: automation_templates_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "automation_templates_isActive_idx" ON public.automation_templates USING btree ("isActive");


--
-- TOC entry 4143 (class 1259 OID 9480939)
-- Name: automation_triggers_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "automation_triggers_isActive_idx" ON public.automation_triggers USING btree ("isActive");


--
-- TOC entry 4146 (class 1259 OID 9480937)
-- Name: automation_triggers_ruleId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "automation_triggers_ruleId_idx" ON public.automation_triggers USING btree ("ruleId");


--
-- TOC entry 4147 (class 1259 OID 9480938)
-- Name: automation_triggers_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX automation_triggers_type_idx ON public.automation_triggers USING btree (type);


--
-- TOC entry 4246 (class 1259 OID 9480984)
-- Name: availability_matrices_memberId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "availability_matrices_memberId_key" ON public.availability_matrices USING btree ("memberId");


--
-- TOC entry 4044 (class 1259 OID 9480916)
-- Name: check_ins_qrCode_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "check_ins_qrCode_key" ON public.check_ins USING btree ("qrCode");


--
-- TOC entry 4049 (class 1259 OID 9480917)
-- Name: children_check_ins_qrCode_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "children_check_ins_qrCode_key" ON public.children_check_ins USING btree ("qrCode");


--
-- TOC entry 4279 (class 1259 OID 9671100)
-- Name: church_qualification_settings_churchId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "church_qualification_settings_churchId_key" ON public.church_qualification_settings USING btree ("churchId");


--
-- TOC entry 4196 (class 1259 OID 9480966)
-- Name: church_subscription_addons_subscriptionId_addonId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "church_subscription_addons_subscriptionId_addonId_key" ON public.church_subscription_addons USING btree ("subscriptionId", "addonId");


--
-- TOC entry 4188 (class 1259 OID 9480963)
-- Name: church_subscriptions_churchId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "church_subscriptions_churchId_idx" ON public.church_subscriptions USING btree ("churchId");


--
-- TOC entry 4189 (class 1259 OID 9480962)
-- Name: church_subscriptions_churchId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "church_subscriptions_churchId_key" ON public.church_subscriptions USING btree ("churchId");


--
-- TOC entry 4192 (class 1259 OID 9480964)
-- Name: church_subscriptions_planId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "church_subscriptions_planId_idx" ON public.church_subscriptions USING btree ("planId");


--
-- TOC entry 4193 (class 1259 OID 9480965)
-- Name: church_subscriptions_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX church_subscriptions_status_idx ON public.church_subscriptions USING btree (status);


--
-- TOC entry 4135 (class 1259 OID 9480933)
-- Name: church_themes_churchId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "church_themes_churchId_key" ON public.church_themes USING btree ("churchId");


--
-- TOC entry 4211 (class 1259 OID 9480973)
-- Name: donation_campaigns_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX donation_campaigns_slug_key ON public.donation_campaigns USING btree (slug);


--
-- TOC entry 4125 (class 1259 OID 9480931)
-- Name: funnel_steps_funnelId_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "funnel_steps_funnelId_slug_key" ON public.funnel_steps USING btree ("funnelId", slug);


--
-- TOC entry 4124 (class 1259 OID 9480930)
-- Name: funnels_websiteId_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "funnels_websiteId_slug_key" ON public.funnels USING btree ("websiteId", slug);


--
-- TOC entry 4272 (class 1259 OID 9579051)
-- Name: invoice_communications_invoiceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "invoice_communications_invoiceId_idx" ON public.invoice_communications USING btree ("invoiceId");


--
-- TOC entry 4275 (class 1259 OID 9579052)
-- Name: invoice_communications_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX invoice_communications_type_idx ON public.invoice_communications USING btree (type);


--
-- TOC entry 4269 (class 1259 OID 9579050)
-- Name: invoice_payments_invoiceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "invoice_payments_invoiceId_idx" ON public.invoice_payments USING btree ("invoiceId");


--
-- TOC entry 4260 (class 1259 OID 9579046)
-- Name: invoices_churchId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "invoices_churchId_idx" ON public.invoices USING btree ("churchId");


--
-- TOC entry 4261 (class 1259 OID 9579048)
-- Name: invoices_dueDate_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "invoices_dueDate_idx" ON public.invoices USING btree ("dueDate");


--
-- TOC entry 4262 (class 1259 OID 9579049)
-- Name: invoices_invoiceNumber_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "invoices_invoiceNumber_idx" ON public.invoices USING btree ("invoiceNumber");


--
-- TOC entry 4263 (class 1259 OID 9579045)
-- Name: invoices_invoiceNumber_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "invoices_invoiceNumber_key" ON public.invoices USING btree ("invoiceNumber");


--
-- TOC entry 4266 (class 1259 OID 9579047)
-- Name: invoices_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX invoices_status_idx ON public.invoices USING btree (status);


--
-- TOC entry 4085 (class 1259 OID 9480921)
-- Name: marketing_campaign_posts_campaignId_postId_accountId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "marketing_campaign_posts_campaignId_postId_accountId_key" ON public.marketing_campaign_posts USING btree ("campaignId", "postId", "accountId");


--
-- TOC entry 4243 (class 1259 OID 9480983)
-- Name: member_spiritual_profiles_memberId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "member_spiritual_profiles_memberId_key" ON public.member_spiritual_profiles USING btree ("memberId");


--
-- TOC entry 4033 (class 1259 OID 9480915)
-- Name: members_userId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "members_userId_key" ON public.members USING btree ("userId");


--
-- TOC entry 4060 (class 1259 OID 9480918)
-- Name: notification_preferences_userId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "notification_preferences_userId_key" ON public.notification_preferences USING btree ("userId");


--
-- TOC entry 4061 (class 1259 OID 9480919)
-- Name: notification_templates_name_churchId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "notification_templates_name_churchId_key" ON public.notification_templates USING btree (name, "churchId");


--
-- TOC entry 4199 (class 1259 OID 9480971)
-- Name: online_payments_churchId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "online_payments_churchId_idx" ON public.online_payments USING btree ("churchId");


--
-- TOC entry 4200 (class 1259 OID 9480968)
-- Name: online_payments_donationId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "online_payments_donationId_key" ON public.online_payments USING btree ("donationId");


--
-- TOC entry 4201 (class 1259 OID 9480969)
-- Name: online_payments_paymentId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "online_payments_paymentId_idx" ON public.online_payments USING btree ("paymentId");


--
-- TOC entry 4202 (class 1259 OID 9480967)
-- Name: online_payments_paymentId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "online_payments_paymentId_key" ON public.online_payments USING btree ("paymentId");


--
-- TOC entry 4205 (class 1259 OID 9480970)
-- Name: online_payments_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX online_payments_status_idx ON public.online_payments USING btree (status);


--
-- TOC entry 4206 (class 1259 OID 9480972)
-- Name: payment_gateway_configs_churchId_gatewayType_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "payment_gateway_configs_churchId_gatewayType_key" ON public.payment_gateway_configs USING btree ("churchId", "gatewayType");


--
-- TOC entry 4012 (class 1259 OID 9480908)
-- Name: permissions_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX permissions_name_key ON public.permissions USING btree (name);


--
-- TOC entry 4015 (class 1259 OID 9480909)
-- Name: permissions_resource_action_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX permissions_resource_action_key ON public.permissions USING btree (resource, action);


--
-- TOC entry 4182 (class 1259 OID 9480960)
-- Name: plan_features_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX plan_features_key_key ON public.plan_features USING btree (key);


--
-- TOC entry 4225 (class 1259 OID 9480977)
-- Name: prayer_approvals_requestId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "prayer_approvals_requestId_key" ON public.prayer_approvals USING btree ("requestId");


--
-- TOC entry 4212 (class 1259 OID 9480974)
-- Name: prayer_categories_churchId_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "prayer_categories_churchId_name_key" ON public.prayer_categories USING btree ("churchId", name);


--
-- TOC entry 4217 (class 1259 OID 9480976)
-- Name: prayer_contacts_churchId_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "prayer_contacts_churchId_email_key" ON public.prayer_contacts USING btree ("churchId", email);


--
-- TOC entry 4218 (class 1259 OID 9480975)
-- Name: prayer_contacts_churchId_phone_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "prayer_contacts_churchId_phone_key" ON public.prayer_contacts USING btree ("churchId", phone);


--
-- TOC entry 4228 (class 1259 OID 9480978)
-- Name: prayer_forms_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX prayer_forms_slug_key ON public.prayer_forms USING btree (slug);


--
-- TOC entry 4229 (class 1259 OID 9480979)
-- Name: prayer_qr_codes_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX prayer_qr_codes_code_key ON public.prayer_qr_codes USING btree (code);


--
-- TOC entry 4173 (class 1259 OID 9480955)
-- Name: push_notification_logs_churchId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "push_notification_logs_churchId_idx" ON public.push_notification_logs USING btree ("churchId");


--
-- TOC entry 4174 (class 1259 OID 9480958)
-- Name: push_notification_logs_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "push_notification_logs_createdAt_idx" ON public.push_notification_logs USING btree ("createdAt");


--
-- TOC entry 4177 (class 1259 OID 9480957)
-- Name: push_notification_logs_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX push_notification_logs_status_idx ON public.push_notification_logs USING btree (status);


--
-- TOC entry 4178 (class 1259 OID 9480956)
-- Name: push_notification_logs_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "push_notification_logs_userId_idx" ON public.push_notification_logs USING btree ("userId");


--
-- TOC entry 4167 (class 1259 OID 9480952)
-- Name: push_subscriptions_churchId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "push_subscriptions_churchId_idx" ON public.push_subscriptions USING btree ("churchId");


--
-- TOC entry 4168 (class 1259 OID 9480953)
-- Name: push_subscriptions_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "push_subscriptions_isActive_idx" ON public.push_subscriptions USING btree ("isActive");


--
-- TOC entry 4171 (class 1259 OID 9480954)
-- Name: push_subscriptions_userId_endpoint_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "push_subscriptions_userId_endpoint_key" ON public.push_subscriptions USING btree ("userId", endpoint);


--
-- TOC entry 4172 (class 1259 OID 9480951)
-- Name: push_subscriptions_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "push_subscriptions_userId_idx" ON public.push_subscriptions USING btree ("userId");


--
-- TOC entry 4021 (class 1259 OID 9480911)
-- Name: role_permissions_roleId_permissionId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "role_permissions_roleId_permissionId_key" ON public.role_permissions USING btree ("roleId", "permissionId");


--
-- TOC entry 4016 (class 1259 OID 9480910)
-- Name: roles_name_churchId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "roles_name_churchId_key" ON public.roles USING btree (name, "churchId");


--
-- TOC entry 4111 (class 1259 OID 9480925)
-- Name: sessions_sessionToken_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "sessions_sessionToken_key" ON public.sessions USING btree ("sessionToken");


--
-- TOC entry 4080 (class 1259 OID 9480920)
-- Name: social_media_accounts_platform_accountId_churchId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "social_media_accounts_platform_accountId_churchId_key" ON public.social_media_accounts USING btree (platform, "accountId", "churchId");


--
-- TOC entry 4088 (class 1259 OID 9480922)
-- Name: social_media_metrics_accountId_postId_metricType_date_perio_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "social_media_metrics_accountId_postId_metricType_date_perio_key" ON public.social_media_metrics USING btree ("accountId", "postId", "metricType", date, "periodType");


--
-- TOC entry 4240 (class 1259 OID 9480982)
-- Name: spiritual_gifts_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX spiritual_gifts_name_key ON public.spiritual_gifts USING btree (name);


--
-- TOC entry 4185 (class 1259 OID 9480961)
-- Name: subscription_addons_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX subscription_addons_key_key ON public.subscription_addons USING btree (key);


--
-- TOC entry 4179 (class 1259 OID 9480959)
-- Name: subscription_plans_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX subscription_plans_name_key ON public.subscription_plans USING btree (name);


--
-- TOC entry 4276 (class 1259 OID 9579053)
-- Name: tenant_credentials_churchId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "tenant_credentials_churchId_key" ON public.tenant_credentials USING btree ("churchId");


--
-- TOC entry 4236 (class 1259 OID 9480980)
-- Name: testimony_forms_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX testimony_forms_slug_key ON public.testimony_forms USING btree (slug);


--
-- TOC entry 4237 (class 1259 OID 9480981)
-- Name: testimony_qr_codes_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX testimony_qr_codes_code_key ON public.testimony_qr_codes USING btree (code);


--
-- TOC entry 4024 (class 1259 OID 9480912)
-- Name: user_permissions_userId_permissionId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "user_permissions_userId_permissionId_key" ON public.user_permissions USING btree ("userId", "permissionId");


--
-- TOC entry 4027 (class 1259 OID 9480913)
-- Name: user_roles_advanced_userId_roleId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "user_roles_advanced_userId_roleId_key" ON public.user_roles_advanced USING btree ("userId", "roleId");


--
-- TOC entry 4134 (class 1259 OID 9480932)
-- Name: user_theme_preferences_userId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "user_theme_preferences_userId_key" ON public.user_theme_preferences USING btree ("userId");


--
-- TOC entry 4028 (class 1259 OID 9480914)
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- TOC entry 4112 (class 1259 OID 9480927)
-- Name: verification_tokens_identifier_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX verification_tokens_identifier_token_key ON public.verification_tokens USING btree (identifier, token);


--
-- TOC entry 4113 (class 1259 OID 9480926)
-- Name: verification_tokens_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX verification_tokens_token_key ON public.verification_tokens USING btree (token);


--
-- TOC entry 4255 (class 1259 OID 9480985)
-- Name: volunteer_engagement_scores_volunteerId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "volunteer_engagement_scores_volunteerId_key" ON public.volunteer_engagement_scores USING btree ("volunteerId");


--
-- TOC entry 4119 (class 1259 OID 9480929)
-- Name: web_pages_websiteId_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "web_pages_websiteId_slug_key" ON public.web_pages USING btree ("websiteId", slug);


--
-- TOC entry 4116 (class 1259 OID 9480928)
-- Name: websites_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX websites_slug_key ON public.websites USING btree (slug);


--
-- TOC entry 4350 (class 2606 OID 9481326)
-- Name: accounts accounts_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT "accounts_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4349 (class 2606 OID 9481321)
-- Name: analytics_cache analytics_cache_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.analytics_cache
    ADD CONSTRAINT "analytics_cache_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4345 (class 2606 OID 9481301)
-- Name: analytics_dashboards analytics_dashboards_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.analytics_dashboards
    ADD CONSTRAINT "analytics_dashboards_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4367 (class 2606 OID 9481411)
-- Name: automation_actions automation_actions_ruleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_actions
    ADD CONSTRAINT "automation_actions_ruleId_fkey" FOREIGN KEY ("ruleId") REFERENCES public.automation_rules(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4366 (class 2606 OID 9481406)
-- Name: automation_conditions automation_conditions_ruleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_conditions
    ADD CONSTRAINT "automation_conditions_ruleId_fkey" FOREIGN KEY ("ruleId") REFERENCES public.automation_rules(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4328 (class 2606 OID 9481216)
-- Name: automation_executions automation_executions_automationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_executions
    ADD CONSTRAINT "automation_executions_automationId_fkey" FOREIGN KEY ("automationId") REFERENCES public.automations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4329 (class 2606 OID 9481221)
-- Name: automation_executions automation_executions_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_executions
    ADD CONSTRAINT "automation_executions_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4368 (class 2606 OID 9481416)
-- Name: automation_rule_executions automation_rule_executions_ruleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_rule_executions
    ADD CONSTRAINT "automation_rule_executions_ruleId_fkey" FOREIGN KEY ("ruleId") REFERENCES public.automation_rules(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4363 (class 2606 OID 9481391)
-- Name: automation_rules automation_rules_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_rules
    ADD CONSTRAINT "automation_rules_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4364 (class 2606 OID 9481396)
-- Name: automation_rules automation_rules_createdBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_rules
    ADD CONSTRAINT "automation_rules_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 4369 (class 2606 OID 9481421)
-- Name: automation_templates automation_templates_createdBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_templates
    ADD CONSTRAINT "automation_templates_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4365 (class 2606 OID 9481401)
-- Name: automation_triggers automation_triggers_ruleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_triggers
    ADD CONSTRAINT "automation_triggers_ruleId_fkey" FOREIGN KEY ("ruleId") REFERENCES public.automation_rules(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4327 (class 2606 OID 9481211)
-- Name: automations automations_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automations
    ADD CONSTRAINT "automations_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4406 (class 2606 OID 9481606)
-- Name: availability_matrices availability_matrices_memberId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.availability_matrices
    ADD CONSTRAINT "availability_matrices_memberId_fkey" FOREIGN KEY ("memberId") REFERENCES public.members(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4301 (class 2606 OID 9481081)
-- Name: check_ins check_ins_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.check_ins
    ADD CONSTRAINT "check_ins_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4302 (class 2606 OID 9481086)
-- Name: check_ins check_ins_eventId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.check_ins
    ADD CONSTRAINT "check_ins_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES public.events(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4306 (class 2606 OID 9481106)
-- Name: children_check_ins children_check_ins_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.children_check_ins
    ADD CONSTRAINT "children_check_ins_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4307 (class 2606 OID 9481111)
-- Name: children_check_ins children_check_ins_eventId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.children_check_ins
    ADD CONSTRAINT "children_check_ins_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES public.events(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4427 (class 2606 OID 9671101)
-- Name: church_qualification_settings church_qualification_settings_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.church_qualification_settings
    ADD CONSTRAINT "church_qualification_settings_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4376 (class 2606 OID 9481456)
-- Name: church_subscription_addons church_subscription_addons_addonId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.church_subscription_addons
    ADD CONSTRAINT "church_subscription_addons_addonId_fkey" FOREIGN KEY ("addonId") REFERENCES public.subscription_addons(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 4377 (class 2606 OID 9481461)
-- Name: church_subscription_addons church_subscription_addons_subscriptionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.church_subscription_addons
    ADD CONSTRAINT "church_subscription_addons_subscriptionId_fkey" FOREIGN KEY ("subscriptionId") REFERENCES public.church_subscriptions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4374 (class 2606 OID 9481446)
-- Name: church_subscriptions church_subscriptions_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.church_subscriptions
    ADD CONSTRAINT "church_subscriptions_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4375 (class 2606 OID 9481451)
-- Name: church_subscriptions church_subscriptions_planId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.church_subscriptions
    ADD CONSTRAINT "church_subscriptions_planId_fkey" FOREIGN KEY ("planId") REFERENCES public.subscription_plans(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 4362 (class 2606 OID 9481386)
-- Name: church_themes church_themes_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.church_themes
    ADD CONSTRAINT "church_themes_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4321 (class 2606 OID 9481181)
-- Name: communication_templates communication_templates_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_templates
    ADD CONSTRAINT "communication_templates_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4319 (class 2606 OID 9481171)
-- Name: communications communications_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communications
    ADD CONSTRAINT "communications_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4320 (class 2606 OID 9481176)
-- Name: communications communications_templateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communications
    ADD CONSTRAINT "communications_templateId_fkey" FOREIGN KEY ("templateId") REFERENCES public.communication_templates(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4340 (class 2606 OID 9481276)
-- Name: custom_reports custom_reports_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_reports
    ADD CONSTRAINT "custom_reports_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4346 (class 2606 OID 9481306)
-- Name: dashboard_widgets dashboard_widgets_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_widgets
    ADD CONSTRAINT "dashboard_widgets_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4347 (class 2606 OID 9481311)
-- Name: dashboard_widgets dashboard_widgets_dashboardId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_widgets
    ADD CONSTRAINT "dashboard_widgets_dashboardId_fkey" FOREIGN KEY ("dashboardId") REFERENCES public.analytics_dashboards(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4382 (class 2606 OID 9481486)
-- Name: donation_campaigns donation_campaigns_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.donation_campaigns
    ADD CONSTRAINT "donation_campaigns_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.donation_categories(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4383 (class 2606 OID 9481491)
-- Name: donation_campaigns donation_campaigns_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.donation_campaigns
    ADD CONSTRAINT "donation_campaigns_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4308 (class 2606 OID 9481116)
-- Name: donation_categories donation_categories_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.donation_categories
    ADD CONSTRAINT "donation_categories_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4310 (class 2606 OID 9481126)
-- Name: donations donations_campaignId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.donations
    ADD CONSTRAINT "donations_campaignId_fkey" FOREIGN KEY ("campaignId") REFERENCES public.donation_campaigns(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4311 (class 2606 OID 9481131)
-- Name: donations donations_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.donations
    ADD CONSTRAINT "donations_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.donation_categories(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 4312 (class 2606 OID 9481136)
-- Name: donations donations_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.donations
    ADD CONSTRAINT "donations_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4313 (class 2606 OID 9481141)
-- Name: donations donations_memberId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.donations
    ADD CONSTRAINT "donations_memberId_fkey" FOREIGN KEY ("memberId") REFERENCES public.members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4314 (class 2606 OID 9481146)
-- Name: donations donations_paymentMethodId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.donations
    ADD CONSTRAINT "donations_paymentMethodId_fkey" FOREIGN KEY ("paymentMethodId") REFERENCES public.payment_methods(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 4323 (class 2606 OID 9481191)
-- Name: event_resource_reservations event_resource_reservations_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_resource_reservations
    ADD CONSTRAINT "event_resource_reservations_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4324 (class 2606 OID 9481196)
-- Name: event_resource_reservations event_resource_reservations_eventId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_resource_reservations
    ADD CONSTRAINT "event_resource_reservations_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES public.events(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4325 (class 2606 OID 9481201)
-- Name: event_resource_reservations event_resource_reservations_resourceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_resource_reservations
    ADD CONSTRAINT "event_resource_reservations_resourceId_fkey" FOREIGN KEY ("resourceId") REFERENCES public.event_resources(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4322 (class 2606 OID 9481186)
-- Name: event_resources event_resources_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_resources
    ADD CONSTRAINT "event_resources_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4295 (class 2606 OID 9481051)
-- Name: events events_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT "events_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4357 (class 2606 OID 9481361)
-- Name: funnel_conversions funnel_conversions_funnelId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.funnel_conversions
    ADD CONSTRAINT "funnel_conversions_funnelId_fkey" FOREIGN KEY ("funnelId") REFERENCES public.funnels(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4358 (class 2606 OID 9481366)
-- Name: funnel_conversions funnel_conversions_stepId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.funnel_conversions
    ADD CONSTRAINT "funnel_conversions_stepId_fkey" FOREIGN KEY ("stepId") REFERENCES public.funnel_steps(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4356 (class 2606 OID 9481356)
-- Name: funnel_steps funnel_steps_funnelId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.funnel_steps
    ADD CONSTRAINT "funnel_steps_funnelId_fkey" FOREIGN KEY ("funnelId") REFERENCES public.funnels(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4355 (class 2606 OID 9481351)
-- Name: funnels funnels_websiteId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.funnels
    ADD CONSTRAINT "funnels_websiteId_fkey" FOREIGN KEY ("websiteId") REFERENCES public.websites(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4326 (class 2606 OID 9481206)
-- Name: integration_configs integration_configs_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.integration_configs
    ADD CONSTRAINT "integration_configs_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4423 (class 2606 OID 9579084)
-- Name: invoice_communications invoice_communications_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_communications
    ADD CONSTRAINT "invoice_communications_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public.invoices(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4424 (class 2606 OID 9579089)
-- Name: invoice_communications invoice_communications_sentBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_communications
    ADD CONSTRAINT "invoice_communications_sentBy_fkey" FOREIGN KEY ("sentBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4420 (class 2606 OID 9579069)
-- Name: invoice_line_items invoice_line_items_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_line_items
    ADD CONSTRAINT "invoice_line_items_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public.invoices(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4421 (class 2606 OID 9579074)
-- Name: invoice_payments invoice_payments_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_payments
    ADD CONSTRAINT "invoice_payments_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public.invoices(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4422 (class 2606 OID 9579079)
-- Name: invoice_payments invoice_payments_verifiedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_payments
    ADD CONSTRAINT "invoice_payments_verifiedBy_fkey" FOREIGN KEY ("verifiedBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4417 (class 2606 OID 9579054)
-- Name: invoices invoices_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4418 (class 2606 OID 9579064)
-- Name: invoices invoices_createdBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 4419 (class 2606 OID 9579059)
-- Name: invoices invoices_subscriptionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_subscriptionId_fkey" FOREIGN KEY ("subscriptionId") REFERENCES public.church_subscriptions(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4348 (class 2606 OID 9481316)
-- Name: kpi_metrics kpi_metrics_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kpi_metrics
    ADD CONSTRAINT "kpi_metrics_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4334 (class 2606 OID 9481246)
-- Name: marketing_campaign_posts marketing_campaign_posts_accountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.marketing_campaign_posts
    ADD CONSTRAINT "marketing_campaign_posts_accountId_fkey" FOREIGN KEY ("accountId") REFERENCES public.social_media_accounts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4335 (class 2606 OID 9481251)
-- Name: marketing_campaign_posts marketing_campaign_posts_campaignId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.marketing_campaign_posts
    ADD CONSTRAINT "marketing_campaign_posts_campaignId_fkey" FOREIGN KEY ("campaignId") REFERENCES public.marketing_campaigns(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4336 (class 2606 OID 9481256)
-- Name: marketing_campaign_posts marketing_campaign_posts_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.marketing_campaign_posts
    ADD CONSTRAINT "marketing_campaign_posts_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4337 (class 2606 OID 9481261)
-- Name: marketing_campaign_posts marketing_campaign_posts_postId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.marketing_campaign_posts
    ADD CONSTRAINT "marketing_campaign_posts_postId_fkey" FOREIGN KEY ("postId") REFERENCES public.social_media_posts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4333 (class 2606 OID 9481241)
-- Name: marketing_campaigns marketing_campaigns_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.marketing_campaigns
    ADD CONSTRAINT "marketing_campaigns_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4405 (class 2606 OID 9481601)
-- Name: member_spiritual_profiles member_spiritual_profiles_memberId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_spiritual_profiles
    ADD CONSTRAINT "member_spiritual_profiles_memberId_fkey" FOREIGN KEY ("memberId") REFERENCES public.members(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4291 (class 2606 OID 9481031)
-- Name: members members_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT "members_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4292 (class 2606 OID 9481036)
-- Name: members members_ministryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT "members_ministryId_fkey" FOREIGN KEY ("ministryId") REFERENCES public.ministries(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4293 (class 2606 OID 9481041)
-- Name: members members_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT "members_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4282 (class 2606 OID 9480986)
-- Name: ministries ministries_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ministries
    ADD CONSTRAINT "ministries_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4410 (class 2606 OID 9481631)
-- Name: ministry_gap_analyses ministry_gap_analyses_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ministry_gap_analyses
    ADD CONSTRAINT "ministry_gap_analyses_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4411 (class 2606 OID 9481626)
-- Name: ministry_gap_analyses ministry_gap_analyses_ministryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ministry_gap_analyses
    ADD CONSTRAINT "ministry_gap_analyses_ministryId_fkey" FOREIGN KEY ("ministryId") REFERENCES public.ministries(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4317 (class 2606 OID 9481161)
-- Name: notification_preferences notification_preferences_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT "notification_preferences_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4318 (class 2606 OID 9481166)
-- Name: notification_templates notification_templates_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_templates
    ADD CONSTRAINT "notification_templates_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4315 (class 2606 OID 9481151)
-- Name: notifications notifications_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT "notifications_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4316 (class 2606 OID 9481156)
-- Name: notifications notifications_createdBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT "notifications_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4378 (class 2606 OID 9481466)
-- Name: online_payments online_payments_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.online_payments
    ADD CONSTRAINT "online_payments_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.donation_categories(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4379 (class 2606 OID 9481471)
-- Name: online_payments online_payments_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.online_payments
    ADD CONSTRAINT "online_payments_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4380 (class 2606 OID 9481476)
-- Name: online_payments online_payments_donationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.online_payments
    ADD CONSTRAINT "online_payments_donationId_fkey" FOREIGN KEY ("donationId") REFERENCES public.donations(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4381 (class 2606 OID 9481481)
-- Name: payment_gateway_configs payment_gateway_configs_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_gateway_configs
    ADD CONSTRAINT "payment_gateway_configs_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4309 (class 2606 OID 9481121)
-- Name: payment_methods payment_methods_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_methods
    ADD CONSTRAINT "payment_methods_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4391 (class 2606 OID 9481531)
-- Name: prayer_approvals prayer_approvals_approvedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_approvals
    ADD CONSTRAINT "prayer_approvals_approvedBy_fkey" FOREIGN KEY ("approvedBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 4392 (class 2606 OID 9481536)
-- Name: prayer_approvals prayer_approvals_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_approvals
    ADD CONSTRAINT "prayer_approvals_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4393 (class 2606 OID 9481541)
-- Name: prayer_approvals prayer_approvals_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_approvals
    ADD CONSTRAINT "prayer_approvals_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public.prayer_contacts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4394 (class 2606 OID 9481546)
-- Name: prayer_approvals prayer_approvals_requestId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_approvals
    ADD CONSTRAINT "prayer_approvals_requestId_fkey" FOREIGN KEY ("requestId") REFERENCES public.prayer_requests(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4384 (class 2606 OID 9481496)
-- Name: prayer_categories prayer_categories_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_categories
    ADD CONSTRAINT "prayer_categories_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4387 (class 2606 OID 9481511)
-- Name: prayer_contacts prayer_contacts_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_contacts
    ADD CONSTRAINT "prayer_contacts_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4395 (class 2606 OID 9481551)
-- Name: prayer_forms prayer_forms_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_forms
    ADD CONSTRAINT "prayer_forms_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4396 (class 2606 OID 9481556)
-- Name: prayer_qr_codes prayer_qr_codes_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_qr_codes
    ADD CONSTRAINT "prayer_qr_codes_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4397 (class 2606 OID 9481561)
-- Name: prayer_qr_codes prayer_qr_codes_formId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_qr_codes
    ADD CONSTRAINT "prayer_qr_codes_formId_fkey" FOREIGN KEY ("formId") REFERENCES public.prayer_forms(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4388 (class 2606 OID 9481516)
-- Name: prayer_requests prayer_requests_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_requests
    ADD CONSTRAINT "prayer_requests_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.prayer_categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4389 (class 2606 OID 9481521)
-- Name: prayer_requests prayer_requests_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_requests
    ADD CONSTRAINT "prayer_requests_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4390 (class 2606 OID 9481526)
-- Name: prayer_requests prayer_requests_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_requests
    ADD CONSTRAINT "prayer_requests_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public.prayer_contacts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4385 (class 2606 OID 9481501)
-- Name: prayer_response_templates prayer_response_templates_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_response_templates
    ADD CONSTRAINT "prayer_response_templates_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.prayer_categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4386 (class 2606 OID 9481506)
-- Name: prayer_response_templates prayer_response_templates_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_response_templates
    ADD CONSTRAINT "prayer_response_templates_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4398 (class 2606 OID 9481581)
-- Name: prayer_testimonies prayer_testimonies_approvedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_testimonies
    ADD CONSTRAINT "prayer_testimonies_approvedBy_fkey" FOREIGN KEY ("approvedBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4399 (class 2606 OID 9481566)
-- Name: prayer_testimonies prayer_testimonies_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_testimonies
    ADD CONSTRAINT "prayer_testimonies_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4400 (class 2606 OID 9481571)
-- Name: prayer_testimonies prayer_testimonies_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_testimonies
    ADD CONSTRAINT "prayer_testimonies_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public.prayer_contacts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4401 (class 2606 OID 9481576)
-- Name: prayer_testimonies prayer_testimonies_prayerRequestId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_testimonies
    ADD CONSTRAINT "prayer_testimonies_prayerRequestId_fkey" FOREIGN KEY ("prayerRequestId") REFERENCES public.prayer_requests(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4372 (class 2606 OID 9481436)
-- Name: push_notification_logs push_notification_logs_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_notification_logs
    ADD CONSTRAINT "push_notification_logs_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4373 (class 2606 OID 9481441)
-- Name: push_notification_logs push_notification_logs_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_notification_logs
    ADD CONSTRAINT "push_notification_logs_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4370 (class 2606 OID 9481426)
-- Name: push_subscriptions push_subscriptions_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT "push_subscriptions_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4371 (class 2606 OID 9481431)
-- Name: push_subscriptions push_subscriptions_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT "push_subscriptions_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4343 (class 2606 OID 9481291)
-- Name: report_executions report_executions_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_executions
    ADD CONSTRAINT "report_executions_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4344 (class 2606 OID 9481296)
-- Name: report_executions report_executions_reportId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_executions
    ADD CONSTRAINT "report_executions_reportId_fkey" FOREIGN KEY ("reportId") REFERENCES public.custom_reports(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4341 (class 2606 OID 9481281)
-- Name: report_schedules report_schedules_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_schedules
    ADD CONSTRAINT "report_schedules_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4342 (class 2606 OID 9481286)
-- Name: report_schedules report_schedules_reportId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_schedules
    ADD CONSTRAINT "report_schedules_reportId_fkey" FOREIGN KEY ("reportId") REFERENCES public.custom_reports(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4284 (class 2606 OID 9480996)
-- Name: role_permissions role_permissions_permissionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT "role_permissions_permissionId_fkey" FOREIGN KEY ("permissionId") REFERENCES public.permissions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4285 (class 2606 OID 9481001)
-- Name: role_permissions role_permissions_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT "role_permissions_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public.roles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4283 (class 2606 OID 9480991)
-- Name: roles roles_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT "roles_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4294 (class 2606 OID 9481046)
-- Name: sermons sermons_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sermons
    ADD CONSTRAINT "sermons_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4351 (class 2606 OID 9481331)
-- Name: sessions sessions_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT "sessions_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4330 (class 2606 OID 9481226)
-- Name: social_media_accounts social_media_accounts_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_media_accounts
    ADD CONSTRAINT "social_media_accounts_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4338 (class 2606 OID 9481266)
-- Name: social_media_metrics social_media_metrics_accountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_media_metrics
    ADD CONSTRAINT "social_media_metrics_accountId_fkey" FOREIGN KEY ("accountId") REFERENCES public.social_media_accounts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4339 (class 2606 OID 9481271)
-- Name: social_media_metrics social_media_metrics_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_media_metrics
    ADD CONSTRAINT "social_media_metrics_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4331 (class 2606 OID 9481231)
-- Name: social_media_posts social_media_posts_campaignId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_media_posts
    ADD CONSTRAINT "social_media_posts_campaignId_fkey" FOREIGN KEY ("campaignId") REFERENCES public.marketing_campaigns(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4332 (class 2606 OID 9481236)
-- Name: social_media_posts social_media_posts_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_media_posts
    ADD CONSTRAINT "social_media_posts_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4425 (class 2606 OID 9579094)
-- Name: tenant_credentials tenant_credentials_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenant_credentials
    ADD CONSTRAINT "tenant_credentials_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4426 (class 2606 OID 9579099)
-- Name: tenant_credentials tenant_credentials_createdBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenant_credentials
    ADD CONSTRAINT "tenant_credentials_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 4402 (class 2606 OID 9481586)
-- Name: testimony_forms testimony_forms_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.testimony_forms
    ADD CONSTRAINT "testimony_forms_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4403 (class 2606 OID 9481591)
-- Name: testimony_qr_codes testimony_qr_codes_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.testimony_qr_codes
    ADD CONSTRAINT "testimony_qr_codes_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4404 (class 2606 OID 9481596)
-- Name: testimony_qr_codes testimony_qr_codes_formId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.testimony_qr_codes
    ADD CONSTRAINT "testimony_qr_codes_formId_fkey" FOREIGN KEY ("formId") REFERENCES public.testimony_forms(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4286 (class 2606 OID 9481006)
-- Name: user_permissions user_permissions_permissionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT "user_permissions_permissionId_fkey" FOREIGN KEY ("permissionId") REFERENCES public.permissions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4287 (class 2606 OID 9481011)
-- Name: user_permissions user_permissions_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT "user_permissions_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4288 (class 2606 OID 9481016)
-- Name: user_roles_advanced user_roles_advanced_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles_advanced
    ADD CONSTRAINT "user_roles_advanced_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public.roles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4289 (class 2606 OID 9481021)
-- Name: user_roles_advanced user_roles_advanced_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles_advanced
    ADD CONSTRAINT "user_roles_advanced_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4360 (class 2606 OID 9481376)
-- Name: user_theme_preferences user_theme_preferences_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_theme_preferences
    ADD CONSTRAINT "user_theme_preferences_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4361 (class 2606 OID 9481381)
-- Name: user_theme_preferences user_theme_preferences_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_theme_preferences
    ADD CONSTRAINT "user_theme_preferences_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4290 (class 2606 OID 9481026)
-- Name: users users_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "users_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4303 (class 2606 OID 9481091)
-- Name: visitor_follow_ups visitor_follow_ups_assignedTo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visitor_follow_ups
    ADD CONSTRAINT "visitor_follow_ups_assignedTo_fkey" FOREIGN KEY ("assignedTo") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4304 (class 2606 OID 9481096)
-- Name: visitor_follow_ups visitor_follow_ups_checkInId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visitor_follow_ups
    ADD CONSTRAINT "visitor_follow_ups_checkInId_fkey" FOREIGN KEY ("checkInId") REFERENCES public.check_ins(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4305 (class 2606 OID 9481101)
-- Name: visitor_follow_ups visitor_follow_ups_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visitor_follow_ups
    ADD CONSTRAINT "visitor_follow_ups_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4299 (class 2606 OID 9481071)
-- Name: volunteer_assignments volunteer_assignments_eventId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.volunteer_assignments
    ADD CONSTRAINT "volunteer_assignments_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES public.events(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4300 (class 2606 OID 9481076)
-- Name: volunteer_assignments volunteer_assignments_volunteerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.volunteer_assignments
    ADD CONSTRAINT "volunteer_assignments_volunteerId_fkey" FOREIGN KEY ("volunteerId") REFERENCES public.volunteers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4412 (class 2606 OID 9481636)
-- Name: volunteer_engagement_scores volunteer_engagement_scores_volunteerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.volunteer_engagement_scores
    ADD CONSTRAINT "volunteer_engagement_scores_volunteerId_fkey" FOREIGN KEY ("volunteerId") REFERENCES public.volunteers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4407 (class 2606 OID 9481621)
-- Name: volunteer_recommendations volunteer_recommendations_eventId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.volunteer_recommendations
    ADD CONSTRAINT "volunteer_recommendations_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES public.events(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4408 (class 2606 OID 9481611)
-- Name: volunteer_recommendations volunteer_recommendations_memberId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.volunteer_recommendations
    ADD CONSTRAINT "volunteer_recommendations_memberId_fkey" FOREIGN KEY ("memberId") REFERENCES public.members(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4409 (class 2606 OID 9481616)
-- Name: volunteer_recommendations volunteer_recommendations_ministryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.volunteer_recommendations
    ADD CONSTRAINT "volunteer_recommendations_ministryId_fkey" FOREIGN KEY ("ministryId") REFERENCES public.ministries(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4296 (class 2606 OID 9481056)
-- Name: volunteers volunteers_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.volunteers
    ADD CONSTRAINT "volunteers_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4297 (class 2606 OID 9481061)
-- Name: volunteers volunteers_memberId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.volunteers
    ADD CONSTRAINT "volunteers_memberId_fkey" FOREIGN KEY ("memberId") REFERENCES public.members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4298 (class 2606 OID 9481066)
-- Name: volunteers volunteers_ministryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.volunteers
    ADD CONSTRAINT "volunteers_ministryId_fkey" FOREIGN KEY ("ministryId") REFERENCES public.ministries(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4354 (class 2606 OID 9481346)
-- Name: web_page_sections web_page_sections_pageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.web_page_sections
    ADD CONSTRAINT "web_page_sections_pageId_fkey" FOREIGN KEY ("pageId") REFERENCES public.web_pages(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4353 (class 2606 OID 9481341)
-- Name: web_pages web_pages_websiteId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.web_pages
    ADD CONSTRAINT "web_pages_websiteId_fkey" FOREIGN KEY ("websiteId") REFERENCES public.websites(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4359 (class 2606 OID 9481371)
-- Name: website_analytics website_analytics_websiteId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.website_analytics
    ADD CONSTRAINT "website_analytics_websiteId_fkey" FOREIGN KEY ("websiteId") REFERENCES public.websites(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4413 (class 2606 OID 9481656)
-- Name: website_requests website_requests_assignedTo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.website_requests
    ADD CONSTRAINT "website_requests_assignedTo_fkey" FOREIGN KEY ("assignedTo") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4414 (class 2606 OID 9481641)
-- Name: website_requests website_requests_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.website_requests
    ADD CONSTRAINT "website_requests_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4415 (class 2606 OID 9481646)
-- Name: website_requests website_requests_existingWebsiteId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.website_requests
    ADD CONSTRAINT "website_requests_existingWebsiteId_fkey" FOREIGN KEY ("existingWebsiteId") REFERENCES public.websites(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4416 (class 2606 OID 9481651)
-- Name: website_requests website_requests_resultingWebsiteId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.website_requests
    ADD CONSTRAINT "website_requests_resultingWebsiteId_fkey" FOREIGN KEY ("resultingWebsiteId") REFERENCES public.websites(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4352 (class 2606 OID 9481336)
-- Name: websites websites_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.websites
    ADD CONSTRAINT "websites_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


-- Completed on 2025-09-13 15:19:42 UTC

--
-- PostgreSQL database dump complete
--

\unrestrict eCvEe4fwoi3QBaFrY1XnJWVjEa7W3D4S1SSgNwJdyIHkPmrdkmmo8giU22BfHxb

