--
-- PostgreSQL database dump
--

\restrict B3jLODoHhVKSjfpotVRHbM1L7ybdKC8dB9UpLxw3b0EVKJfIRVZN0ftssiU86fc

-- Dumped from database version 17.4 (Ubuntu 17.4-1.pgdg24.04+2)
-- Dumped by pg_dump version 17.6 (Ubuntu 17.6-1.pgdg22.04+1)

-- Started on 2025-09-13 15:19:55 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.websites DROP CONSTRAINT IF EXISTS "websites_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.website_requests DROP CONSTRAINT IF EXISTS "website_requests_resultingWebsiteId_fkey";
ALTER TABLE IF EXISTS ONLY public.website_requests DROP CONSTRAINT IF EXISTS "website_requests_existingWebsiteId_fkey";
ALTER TABLE IF EXISTS ONLY public.website_requests DROP CONSTRAINT IF EXISTS "website_requests_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.website_requests DROP CONSTRAINT IF EXISTS "website_requests_assignedTo_fkey";
ALTER TABLE IF EXISTS ONLY public.website_analytics DROP CONSTRAINT IF EXISTS "website_analytics_websiteId_fkey";
ALTER TABLE IF EXISTS ONLY public.web_pages DROP CONSTRAINT IF EXISTS "web_pages_websiteId_fkey";
ALTER TABLE IF EXISTS ONLY public.web_page_sections DROP CONSTRAINT IF EXISTS "web_page_sections_pageId_fkey";
ALTER TABLE IF EXISTS ONLY public.volunteers DROP CONSTRAINT IF EXISTS "volunteers_ministryId_fkey";
ALTER TABLE IF EXISTS ONLY public.volunteers DROP CONSTRAINT IF EXISTS "volunteers_memberId_fkey";
ALTER TABLE IF EXISTS ONLY public.volunteers DROP CONSTRAINT IF EXISTS "volunteers_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.volunteer_recommendations DROP CONSTRAINT IF EXISTS "volunteer_recommendations_ministryId_fkey";
ALTER TABLE IF EXISTS ONLY public.volunteer_recommendations DROP CONSTRAINT IF EXISTS "volunteer_recommendations_memberId_fkey";
ALTER TABLE IF EXISTS ONLY public.volunteer_recommendations DROP CONSTRAINT IF EXISTS "volunteer_recommendations_eventId_fkey";
ALTER TABLE IF EXISTS ONLY public.volunteer_engagement_scores DROP CONSTRAINT IF EXISTS "volunteer_engagement_scores_volunteerId_fkey";
ALTER TABLE IF EXISTS ONLY public.volunteer_assignments DROP CONSTRAINT IF EXISTS "volunteer_assignments_volunteerId_fkey";
ALTER TABLE IF EXISTS ONLY public.volunteer_assignments DROP CONSTRAINT IF EXISTS "volunteer_assignments_eventId_fkey";
ALTER TABLE IF EXISTS ONLY public.visitor_follow_ups DROP CONSTRAINT IF EXISTS "visitor_follow_ups_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.visitor_follow_ups DROP CONSTRAINT IF EXISTS "visitor_follow_ups_checkInId_fkey";
ALTER TABLE IF EXISTS ONLY public.visitor_follow_ups DROP CONSTRAINT IF EXISTS "visitor_follow_ups_assignedTo_fkey";
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS "users_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.user_theme_preferences DROP CONSTRAINT IF EXISTS "user_theme_preferences_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.user_theme_preferences DROP CONSTRAINT IF EXISTS "user_theme_preferences_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.user_roles_advanced DROP CONSTRAINT IF EXISTS "user_roles_advanced_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.user_roles_advanced DROP CONSTRAINT IF EXISTS "user_roles_advanced_roleId_fkey";
ALTER TABLE IF EXISTS ONLY public.user_permissions DROP CONSTRAINT IF EXISTS "user_permissions_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.user_permissions DROP CONSTRAINT IF EXISTS "user_permissions_permissionId_fkey";
ALTER TABLE IF EXISTS ONLY public.testimony_qr_codes DROP CONSTRAINT IF EXISTS "testimony_qr_codes_formId_fkey";
ALTER TABLE IF EXISTS ONLY public.testimony_qr_codes DROP CONSTRAINT IF EXISTS "testimony_qr_codes_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.testimony_forms DROP CONSTRAINT IF EXISTS "testimony_forms_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.tenant_credentials DROP CONSTRAINT IF EXISTS "tenant_credentials_createdBy_fkey";
ALTER TABLE IF EXISTS ONLY public.tenant_credentials DROP CONSTRAINT IF EXISTS "tenant_credentials_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.social_media_posts DROP CONSTRAINT IF EXISTS "social_media_posts_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.social_media_posts DROP CONSTRAINT IF EXISTS "social_media_posts_campaignId_fkey";
ALTER TABLE IF EXISTS ONLY public.social_media_metrics DROP CONSTRAINT IF EXISTS "social_media_metrics_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.social_media_metrics DROP CONSTRAINT IF EXISTS "social_media_metrics_accountId_fkey";
ALTER TABLE IF EXISTS ONLY public.social_media_accounts DROP CONSTRAINT IF EXISTS "social_media_accounts_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.sessions DROP CONSTRAINT IF EXISTS "sessions_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.sermons DROP CONSTRAINT IF EXISTS "sermons_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.roles DROP CONSTRAINT IF EXISTS "roles_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.role_permissions DROP CONSTRAINT IF EXISTS "role_permissions_roleId_fkey";
ALTER TABLE IF EXISTS ONLY public.role_permissions DROP CONSTRAINT IF EXISTS "role_permissions_permissionId_fkey";
ALTER TABLE IF EXISTS ONLY public.report_schedules DROP CONSTRAINT IF EXISTS "report_schedules_reportId_fkey";
ALTER TABLE IF EXISTS ONLY public.report_schedules DROP CONSTRAINT IF EXISTS "report_schedules_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.report_executions DROP CONSTRAINT IF EXISTS "report_executions_reportId_fkey";
ALTER TABLE IF EXISTS ONLY public.report_executions DROP CONSTRAINT IF EXISTS "report_executions_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.push_subscriptions DROP CONSTRAINT IF EXISTS "push_subscriptions_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.push_subscriptions DROP CONSTRAINT IF EXISTS "push_subscriptions_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.push_notification_logs DROP CONSTRAINT IF EXISTS "push_notification_logs_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.push_notification_logs DROP CONSTRAINT IF EXISTS "push_notification_logs_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.prayer_testimonies DROP CONSTRAINT IF EXISTS "prayer_testimonies_prayerRequestId_fkey";
ALTER TABLE IF EXISTS ONLY public.prayer_testimonies DROP CONSTRAINT IF EXISTS "prayer_testimonies_contactId_fkey";
ALTER TABLE IF EXISTS ONLY public.prayer_testimonies DROP CONSTRAINT IF EXISTS "prayer_testimonies_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.prayer_testimonies DROP CONSTRAINT IF EXISTS "prayer_testimonies_approvedBy_fkey";
ALTER TABLE IF EXISTS ONLY public.prayer_response_templates DROP CONSTRAINT IF EXISTS "prayer_response_templates_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.prayer_response_templates DROP CONSTRAINT IF EXISTS "prayer_response_templates_categoryId_fkey";
ALTER TABLE IF EXISTS ONLY public.prayer_requests DROP CONSTRAINT IF EXISTS "prayer_requests_contactId_fkey";
ALTER TABLE IF EXISTS ONLY public.prayer_requests DROP CONSTRAINT IF EXISTS "prayer_requests_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.prayer_requests DROP CONSTRAINT IF EXISTS "prayer_requests_categoryId_fkey";
ALTER TABLE IF EXISTS ONLY public.prayer_qr_codes DROP CONSTRAINT IF EXISTS "prayer_qr_codes_formId_fkey";
ALTER TABLE IF EXISTS ONLY public.prayer_qr_codes DROP CONSTRAINT IF EXISTS "prayer_qr_codes_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.prayer_forms DROP CONSTRAINT IF EXISTS "prayer_forms_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.prayer_contacts DROP CONSTRAINT IF EXISTS "prayer_contacts_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.prayer_categories DROP CONSTRAINT IF EXISTS "prayer_categories_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.prayer_approvals DROP CONSTRAINT IF EXISTS "prayer_approvals_requestId_fkey";
ALTER TABLE IF EXISTS ONLY public.prayer_approvals DROP CONSTRAINT IF EXISTS "prayer_approvals_contactId_fkey";
ALTER TABLE IF EXISTS ONLY public.prayer_approvals DROP CONSTRAINT IF EXISTS "prayer_approvals_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.prayer_approvals DROP CONSTRAINT IF EXISTS "prayer_approvals_approvedBy_fkey";
ALTER TABLE IF EXISTS ONLY public.payment_methods DROP CONSTRAINT IF EXISTS "payment_methods_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.payment_gateway_configs DROP CONSTRAINT IF EXISTS "payment_gateway_configs_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.online_payments DROP CONSTRAINT IF EXISTS "online_payments_donationId_fkey";
ALTER TABLE IF EXISTS ONLY public.online_payments DROP CONSTRAINT IF EXISTS "online_payments_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.online_payments DROP CONSTRAINT IF EXISTS "online_payments_categoryId_fkey";
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS "notifications_createdBy_fkey";
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS "notifications_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.notification_templates DROP CONSTRAINT IF EXISTS "notification_templates_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.notification_preferences DROP CONSTRAINT IF EXISTS "notification_preferences_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.ministry_gap_analyses DROP CONSTRAINT IF EXISTS "ministry_gap_analyses_ministryId_fkey";
ALTER TABLE IF EXISTS ONLY public.ministry_gap_analyses DROP CONSTRAINT IF EXISTS "ministry_gap_analyses_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.ministries DROP CONSTRAINT IF EXISTS "ministries_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.members DROP CONSTRAINT IF EXISTS "members_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.members DROP CONSTRAINT IF EXISTS "members_ministryId_fkey";
ALTER TABLE IF EXISTS ONLY public.members DROP CONSTRAINT IF EXISTS "members_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.member_spiritual_profiles DROP CONSTRAINT IF EXISTS "member_spiritual_profiles_memberId_fkey";
ALTER TABLE IF EXISTS ONLY public.marketing_campaigns DROP CONSTRAINT IF EXISTS "marketing_campaigns_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.marketing_campaign_posts DROP CONSTRAINT IF EXISTS "marketing_campaign_posts_postId_fkey";
ALTER TABLE IF EXISTS ONLY public.marketing_campaign_posts DROP CONSTRAINT IF EXISTS "marketing_campaign_posts_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.marketing_campaign_posts DROP CONSTRAINT IF EXISTS "marketing_campaign_posts_campaignId_fkey";
ALTER TABLE IF EXISTS ONLY public.marketing_campaign_posts DROP CONSTRAINT IF EXISTS "marketing_campaign_posts_accountId_fkey";
ALTER TABLE IF EXISTS ONLY public.kpi_metrics DROP CONSTRAINT IF EXISTS "kpi_metrics_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.invoices DROP CONSTRAINT IF EXISTS "invoices_subscriptionId_fkey";
ALTER TABLE IF EXISTS ONLY public.invoices DROP CONSTRAINT IF EXISTS "invoices_createdBy_fkey";
ALTER TABLE IF EXISTS ONLY public.invoices DROP CONSTRAINT IF EXISTS "invoices_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.invoice_payments DROP CONSTRAINT IF EXISTS "invoice_payments_verifiedBy_fkey";
ALTER TABLE IF EXISTS ONLY public.invoice_payments DROP CONSTRAINT IF EXISTS "invoice_payments_invoiceId_fkey";
ALTER TABLE IF EXISTS ONLY public.invoice_line_items DROP CONSTRAINT IF EXISTS "invoice_line_items_invoiceId_fkey";
ALTER TABLE IF EXISTS ONLY public.invoice_communications DROP CONSTRAINT IF EXISTS "invoice_communications_sentBy_fkey";
ALTER TABLE IF EXISTS ONLY public.invoice_communications DROP CONSTRAINT IF EXISTS "invoice_communications_invoiceId_fkey";
ALTER TABLE IF EXISTS ONLY public.integration_configs DROP CONSTRAINT IF EXISTS "integration_configs_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.funnels DROP CONSTRAINT IF EXISTS "funnels_websiteId_fkey";
ALTER TABLE IF EXISTS ONLY public.funnel_steps DROP CONSTRAINT IF EXISTS "funnel_steps_funnelId_fkey";
ALTER TABLE IF EXISTS ONLY public.funnel_conversions DROP CONSTRAINT IF EXISTS "funnel_conversions_stepId_fkey";
ALTER TABLE IF EXISTS ONLY public.funnel_conversions DROP CONSTRAINT IF EXISTS "funnel_conversions_funnelId_fkey";
ALTER TABLE IF EXISTS ONLY public.events DROP CONSTRAINT IF EXISTS "events_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.event_resources DROP CONSTRAINT IF EXISTS "event_resources_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.event_resource_reservations DROP CONSTRAINT IF EXISTS "event_resource_reservations_resourceId_fkey";
ALTER TABLE IF EXISTS ONLY public.event_resource_reservations DROP CONSTRAINT IF EXISTS "event_resource_reservations_eventId_fkey";
ALTER TABLE IF EXISTS ONLY public.event_resource_reservations DROP CONSTRAINT IF EXISTS "event_resource_reservations_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.donations DROP CONSTRAINT IF EXISTS "donations_paymentMethodId_fkey";
ALTER TABLE IF EXISTS ONLY public.donations DROP CONSTRAINT IF EXISTS "donations_memberId_fkey";
ALTER TABLE IF EXISTS ONLY public.donations DROP CONSTRAINT IF EXISTS "donations_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.donations DROP CONSTRAINT IF EXISTS "donations_categoryId_fkey";
ALTER TABLE IF EXISTS ONLY public.donations DROP CONSTRAINT IF EXISTS "donations_campaignId_fkey";
ALTER TABLE IF EXISTS ONLY public.donation_categories DROP CONSTRAINT IF EXISTS "donation_categories_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.donation_campaigns DROP CONSTRAINT IF EXISTS "donation_campaigns_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.donation_campaigns DROP CONSTRAINT IF EXISTS "donation_campaigns_categoryId_fkey";
ALTER TABLE IF EXISTS ONLY public.dashboard_widgets DROP CONSTRAINT IF EXISTS "dashboard_widgets_dashboardId_fkey";
ALTER TABLE IF EXISTS ONLY public.dashboard_widgets DROP CONSTRAINT IF EXISTS "dashboard_widgets_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.custom_reports DROP CONSTRAINT IF EXISTS "custom_reports_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.communications DROP CONSTRAINT IF EXISTS "communications_templateId_fkey";
ALTER TABLE IF EXISTS ONLY public.communications DROP CONSTRAINT IF EXISTS "communications_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.communication_templates DROP CONSTRAINT IF EXISTS "communication_templates_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.church_themes DROP CONSTRAINT IF EXISTS "church_themes_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.church_subscriptions DROP CONSTRAINT IF EXISTS "church_subscriptions_planId_fkey";
ALTER TABLE IF EXISTS ONLY public.church_subscriptions DROP CONSTRAINT IF EXISTS "church_subscriptions_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.church_subscription_addons DROP CONSTRAINT IF EXISTS "church_subscription_addons_subscriptionId_fkey";
ALTER TABLE IF EXISTS ONLY public.church_subscription_addons DROP CONSTRAINT IF EXISTS "church_subscription_addons_addonId_fkey";
ALTER TABLE IF EXISTS ONLY public.church_qualification_settings DROP CONSTRAINT IF EXISTS "church_qualification_settings_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.children_check_ins DROP CONSTRAINT IF EXISTS "children_check_ins_eventId_fkey";
ALTER TABLE IF EXISTS ONLY public.children_check_ins DROP CONSTRAINT IF EXISTS "children_check_ins_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.check_ins DROP CONSTRAINT IF EXISTS "check_ins_eventId_fkey";
ALTER TABLE IF EXISTS ONLY public.check_ins DROP CONSTRAINT IF EXISTS "check_ins_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.availability_matrices DROP CONSTRAINT IF EXISTS "availability_matrices_memberId_fkey";
ALTER TABLE IF EXISTS ONLY public.automations DROP CONSTRAINT IF EXISTS "automations_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.automation_triggers DROP CONSTRAINT IF EXISTS "automation_triggers_ruleId_fkey";
ALTER TABLE IF EXISTS ONLY public.automation_templates DROP CONSTRAINT IF EXISTS "automation_templates_createdBy_fkey";
ALTER TABLE IF EXISTS ONLY public.automation_rules DROP CONSTRAINT IF EXISTS "automation_rules_createdBy_fkey";
ALTER TABLE IF EXISTS ONLY public.automation_rules DROP CONSTRAINT IF EXISTS "automation_rules_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.automation_rule_executions DROP CONSTRAINT IF EXISTS "automation_rule_executions_ruleId_fkey";
ALTER TABLE IF EXISTS ONLY public.automation_executions DROP CONSTRAINT IF EXISTS "automation_executions_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.automation_executions DROP CONSTRAINT IF EXISTS "automation_executions_automationId_fkey";
ALTER TABLE IF EXISTS ONLY public.automation_conditions DROP CONSTRAINT IF EXISTS "automation_conditions_ruleId_fkey";
ALTER TABLE IF EXISTS ONLY public.automation_actions DROP CONSTRAINT IF EXISTS "automation_actions_ruleId_fkey";
ALTER TABLE IF EXISTS ONLY public.analytics_dashboards DROP CONSTRAINT IF EXISTS "analytics_dashboards_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.analytics_cache DROP CONSTRAINT IF EXISTS "analytics_cache_churchId_fkey";
ALTER TABLE IF EXISTS ONLY public.accounts DROP CONSTRAINT IF EXISTS "accounts_userId_fkey";
DROP INDEX IF EXISTS public.websites_slug_key;
DROP INDEX IF EXISTS public."web_pages_websiteId_slug_key";
DROP INDEX IF EXISTS public."volunteer_engagement_scores_volunteerId_key";
DROP INDEX IF EXISTS public.verification_tokens_token_key;
DROP INDEX IF EXISTS public.verification_tokens_identifier_token_key;
DROP INDEX IF EXISTS public.users_email_key;
DROP INDEX IF EXISTS public."user_theme_preferences_userId_key";
DROP INDEX IF EXISTS public."user_roles_advanced_userId_roleId_key";
DROP INDEX IF EXISTS public."user_permissions_userId_permissionId_key";
DROP INDEX IF EXISTS public.testimony_qr_codes_code_key;
DROP INDEX IF EXISTS public.testimony_forms_slug_key;
DROP INDEX IF EXISTS public."tenant_credentials_churchId_key";
DROP INDEX IF EXISTS public.subscription_plans_name_key;
DROP INDEX IF EXISTS public.subscription_addons_key_key;
DROP INDEX IF EXISTS public.spiritual_gifts_name_key;
DROP INDEX IF EXISTS public."social_media_metrics_accountId_postId_metricType_date_perio_key";
DROP INDEX IF EXISTS public."social_media_accounts_platform_accountId_churchId_key";
DROP INDEX IF EXISTS public."sessions_sessionToken_key";
DROP INDEX IF EXISTS public."roles_name_churchId_key";
DROP INDEX IF EXISTS public."role_permissions_roleId_permissionId_key";
DROP INDEX IF EXISTS public."push_subscriptions_userId_idx";
DROP INDEX IF EXISTS public."push_subscriptions_userId_endpoint_key";
DROP INDEX IF EXISTS public."push_subscriptions_isActive_idx";
DROP INDEX IF EXISTS public."push_subscriptions_churchId_idx";
DROP INDEX IF EXISTS public."push_notification_logs_userId_idx";
DROP INDEX IF EXISTS public.push_notification_logs_status_idx;
DROP INDEX IF EXISTS public."push_notification_logs_createdAt_idx";
DROP INDEX IF EXISTS public."push_notification_logs_churchId_idx";
DROP INDEX IF EXISTS public.prayer_qr_codes_code_key;
DROP INDEX IF EXISTS public.prayer_forms_slug_key;
DROP INDEX IF EXISTS public."prayer_contacts_churchId_phone_key";
DROP INDEX IF EXISTS public."prayer_contacts_churchId_email_key";
DROP INDEX IF EXISTS public."prayer_categories_churchId_name_key";
DROP INDEX IF EXISTS public."prayer_approvals_requestId_key";
DROP INDEX IF EXISTS public.plan_features_key_key;
DROP INDEX IF EXISTS public.permissions_resource_action_key;
DROP INDEX IF EXISTS public.permissions_name_key;
DROP INDEX IF EXISTS public."payment_gateway_configs_churchId_gatewayType_key";
DROP INDEX IF EXISTS public.online_payments_status_idx;
DROP INDEX IF EXISTS public."online_payments_paymentId_key";
DROP INDEX IF EXISTS public."online_payments_paymentId_idx";
DROP INDEX IF EXISTS public."online_payments_donationId_key";
DROP INDEX IF EXISTS public."online_payments_churchId_idx";
DROP INDEX IF EXISTS public."notification_templates_name_churchId_key";
DROP INDEX IF EXISTS public."notification_preferences_userId_key";
DROP INDEX IF EXISTS public."members_userId_key";
DROP INDEX IF EXISTS public."member_spiritual_profiles_memberId_key";
DROP INDEX IF EXISTS public."marketing_campaign_posts_campaignId_postId_accountId_key";
DROP INDEX IF EXISTS public.invoices_status_idx;
DROP INDEX IF EXISTS public."invoices_invoiceNumber_key";
DROP INDEX IF EXISTS public."invoices_invoiceNumber_idx";
DROP INDEX IF EXISTS public."invoices_dueDate_idx";
DROP INDEX IF EXISTS public."invoices_churchId_idx";
DROP INDEX IF EXISTS public."invoice_payments_invoiceId_idx";
DROP INDEX IF EXISTS public.invoice_communications_type_idx;
DROP INDEX IF EXISTS public."invoice_communications_invoiceId_idx";
DROP INDEX IF EXISTS public."funnels_websiteId_slug_key";
DROP INDEX IF EXISTS public."funnel_steps_funnelId_slug_key";
DROP INDEX IF EXISTS public.donation_campaigns_slug_key;
DROP INDEX IF EXISTS public."church_themes_churchId_key";
DROP INDEX IF EXISTS public.church_subscriptions_status_idx;
DROP INDEX IF EXISTS public."church_subscriptions_planId_idx";
DROP INDEX IF EXISTS public."church_subscriptions_churchId_key";
DROP INDEX IF EXISTS public."church_subscriptions_churchId_idx";
DROP INDEX IF EXISTS public."church_subscription_addons_subscriptionId_addonId_key";
DROP INDEX IF EXISTS public."church_qualification_settings_churchId_key";
DROP INDEX IF EXISTS public."children_check_ins_qrCode_key";
DROP INDEX IF EXISTS public."check_ins_qrCode_key";
DROP INDEX IF EXISTS public."availability_matrices_memberId_key";
DROP INDEX IF EXISTS public.automation_triggers_type_idx;
DROP INDEX IF EXISTS public."automation_triggers_ruleId_idx";
DROP INDEX IF EXISTS public."automation_triggers_isActive_idx";
DROP INDEX IF EXISTS public."automation_templates_isActive_idx";
DROP INDEX IF EXISTS public.automation_templates_category_idx;
DROP INDEX IF EXISTS public.automation_rules_priority_idx;
DROP INDEX IF EXISTS public."automation_rules_isActive_idx";
DROP INDEX IF EXISTS public."automation_rules_churchId_idx";
DROP INDEX IF EXISTS public.automation_rule_executions_status_idx;
DROP INDEX IF EXISTS public."automation_rule_executions_ruleId_idx";
DROP INDEX IF EXISTS public."automation_rule_executions_createdAt_idx";
DROP INDEX IF EXISTS public.automation_conditions_type_idx;
DROP INDEX IF EXISTS public."automation_conditions_ruleId_idx";
DROP INDEX IF EXISTS public."automation_conditions_groupId_idx";
DROP INDEX IF EXISTS public.automation_actions_type_idx;
DROP INDEX IF EXISTS public."automation_actions_ruleId_idx";
DROP INDEX IF EXISTS public."automation_actions_orderIndex_idx";
DROP INDEX IF EXISTS public."analytics_cache_cacheKey_churchId_key";
DROP INDEX IF EXISTS public."accounts_provider_providerAccountId_key";
ALTER TABLE IF EXISTS ONLY public.websites DROP CONSTRAINT IF EXISTS websites_pkey;
ALTER TABLE IF EXISTS ONLY public.website_requests DROP CONSTRAINT IF EXISTS website_requests_pkey;
ALTER TABLE IF EXISTS ONLY public.website_analytics DROP CONSTRAINT IF EXISTS website_analytics_pkey;
ALTER TABLE IF EXISTS ONLY public.web_pages DROP CONSTRAINT IF EXISTS web_pages_pkey;
ALTER TABLE IF EXISTS ONLY public.web_page_sections DROP CONSTRAINT IF EXISTS web_page_sections_pkey;
ALTER TABLE IF EXISTS ONLY public.volunteers DROP CONSTRAINT IF EXISTS volunteers_pkey;
ALTER TABLE IF EXISTS ONLY public.volunteer_recommendations DROP CONSTRAINT IF EXISTS volunteer_recommendations_pkey;
ALTER TABLE IF EXISTS ONLY public.volunteer_engagement_scores DROP CONSTRAINT IF EXISTS volunteer_engagement_scores_pkey;
ALTER TABLE IF EXISTS ONLY public.volunteer_assignments DROP CONSTRAINT IF EXISTS volunteer_assignments_pkey;
ALTER TABLE IF EXISTS ONLY public.visitor_follow_ups DROP CONSTRAINT IF EXISTS visitor_follow_ups_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.user_theme_preferences DROP CONSTRAINT IF EXISTS user_theme_preferences_pkey;
ALTER TABLE IF EXISTS ONLY public.user_roles_advanced DROP CONSTRAINT IF EXISTS user_roles_advanced_pkey;
ALTER TABLE IF EXISTS ONLY public.user_permissions DROP CONSTRAINT IF EXISTS user_permissions_pkey;
ALTER TABLE IF EXISTS ONLY public.testimony_qr_codes DROP CONSTRAINT IF EXISTS testimony_qr_codes_pkey;
ALTER TABLE IF EXISTS ONLY public.testimony_forms DROP CONSTRAINT IF EXISTS testimony_forms_pkey;
ALTER TABLE IF EXISTS ONLY public.tenant_credentials DROP CONSTRAINT IF EXISTS tenant_credentials_pkey;
ALTER TABLE IF EXISTS ONLY public.support_contact_info DROP CONSTRAINT IF EXISTS support_contact_info_pkey;
ALTER TABLE IF EXISTS ONLY public.subscription_plans DROP CONSTRAINT IF EXISTS subscription_plans_pkey;
ALTER TABLE IF EXISTS ONLY public.subscription_addons DROP CONSTRAINT IF EXISTS subscription_addons_pkey;
ALTER TABLE IF EXISTS ONLY public.spiritual_gifts DROP CONSTRAINT IF EXISTS spiritual_gifts_pkey;
ALTER TABLE IF EXISTS ONLY public.social_media_posts DROP CONSTRAINT IF EXISTS social_media_posts_pkey;
ALTER TABLE IF EXISTS ONLY public.social_media_metrics DROP CONSTRAINT IF EXISTS social_media_metrics_pkey;
ALTER TABLE IF EXISTS ONLY public.social_media_accounts DROP CONSTRAINT IF EXISTS social_media_accounts_pkey;
ALTER TABLE IF EXISTS ONLY public.sessions DROP CONSTRAINT IF EXISTS sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.sermons DROP CONSTRAINT IF EXISTS sermons_pkey;
ALTER TABLE IF EXISTS ONLY public.roles DROP CONSTRAINT IF EXISTS roles_pkey;
ALTER TABLE IF EXISTS ONLY public.role_permissions DROP CONSTRAINT IF EXISTS role_permissions_pkey;
ALTER TABLE IF EXISTS ONLY public.report_schedules DROP CONSTRAINT IF EXISTS report_schedules_pkey;
ALTER TABLE IF EXISTS ONLY public.report_executions DROP CONSTRAINT IF EXISTS report_executions_pkey;
ALTER TABLE IF EXISTS ONLY public.push_subscriptions DROP CONSTRAINT IF EXISTS push_subscriptions_pkey;
ALTER TABLE IF EXISTS ONLY public.push_notification_logs DROP CONSTRAINT IF EXISTS push_notification_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.prayer_testimonies DROP CONSTRAINT IF EXISTS prayer_testimonies_pkey;
ALTER TABLE IF EXISTS ONLY public.prayer_response_templates DROP CONSTRAINT IF EXISTS prayer_response_templates_pkey;
ALTER TABLE IF EXISTS ONLY public.prayer_requests DROP CONSTRAINT IF EXISTS prayer_requests_pkey;
ALTER TABLE IF EXISTS ONLY public.prayer_qr_codes DROP CONSTRAINT IF EXISTS prayer_qr_codes_pkey;
ALTER TABLE IF EXISTS ONLY public.prayer_forms DROP CONSTRAINT IF EXISTS prayer_forms_pkey;
ALTER TABLE IF EXISTS ONLY public.prayer_contacts DROP CONSTRAINT IF EXISTS prayer_contacts_pkey;
ALTER TABLE IF EXISTS ONLY public.prayer_categories DROP CONSTRAINT IF EXISTS prayer_categories_pkey;
ALTER TABLE IF EXISTS ONLY public.prayer_approvals DROP CONSTRAINT IF EXISTS prayer_approvals_pkey;
ALTER TABLE IF EXISTS ONLY public.platform_settings DROP CONSTRAINT IF EXISTS platform_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.plan_features DROP CONSTRAINT IF EXISTS plan_features_pkey;
ALTER TABLE IF EXISTS ONLY public.permissions DROP CONSTRAINT IF EXISTS permissions_pkey;
ALTER TABLE IF EXISTS ONLY public.payment_methods DROP CONSTRAINT IF EXISTS payment_methods_pkey;
ALTER TABLE IF EXISTS ONLY public.payment_gateway_configs DROP CONSTRAINT IF EXISTS payment_gateway_configs_pkey;
ALTER TABLE IF EXISTS ONLY public.online_payments DROP CONSTRAINT IF EXISTS online_payments_pkey;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_pkey;
ALTER TABLE IF EXISTS ONLY public.notification_templates DROP CONSTRAINT IF EXISTS notification_templates_pkey;
ALTER TABLE IF EXISTS ONLY public.notification_preferences DROP CONSTRAINT IF EXISTS notification_preferences_pkey;
ALTER TABLE IF EXISTS ONLY public.ministry_gap_analyses DROP CONSTRAINT IF EXISTS ministry_gap_analyses_pkey;
ALTER TABLE IF EXISTS ONLY public.ministries DROP CONSTRAINT IF EXISTS ministries_pkey;
ALTER TABLE IF EXISTS ONLY public.members DROP CONSTRAINT IF EXISTS members_pkey;
ALTER TABLE IF EXISTS ONLY public.member_spiritual_profiles DROP CONSTRAINT IF EXISTS member_spiritual_profiles_pkey;
ALTER TABLE IF EXISTS ONLY public.marketing_campaigns DROP CONSTRAINT IF EXISTS marketing_campaigns_pkey;
ALTER TABLE IF EXISTS ONLY public.marketing_campaign_posts DROP CONSTRAINT IF EXISTS marketing_campaign_posts_pkey;
ALTER TABLE IF EXISTS ONLY public.kpi_metrics DROP CONSTRAINT IF EXISTS kpi_metrics_pkey;
ALTER TABLE IF EXISTS ONLY public.invoices DROP CONSTRAINT IF EXISTS invoices_pkey;
ALTER TABLE IF EXISTS ONLY public.invoice_payments DROP CONSTRAINT IF EXISTS invoice_payments_pkey;
ALTER TABLE IF EXISTS ONLY public.invoice_line_items DROP CONSTRAINT IF EXISTS invoice_line_items_pkey;
ALTER TABLE IF EXISTS ONLY public.invoice_communications DROP CONSTRAINT IF EXISTS invoice_communications_pkey;
ALTER TABLE IF EXISTS ONLY public.integration_configs DROP CONSTRAINT IF EXISTS integration_configs_pkey;
ALTER TABLE IF EXISTS ONLY public.funnels DROP CONSTRAINT IF EXISTS funnels_pkey;
ALTER TABLE IF EXISTS ONLY public.funnel_steps DROP CONSTRAINT IF EXISTS funnel_steps_pkey;
ALTER TABLE IF EXISTS ONLY public.funnel_conversions DROP CONSTRAINT IF EXISTS funnel_conversions_pkey;
ALTER TABLE IF EXISTS ONLY public.events DROP CONSTRAINT IF EXISTS events_pkey;
ALTER TABLE IF EXISTS ONLY public.event_resources DROP CONSTRAINT IF EXISTS event_resources_pkey;
ALTER TABLE IF EXISTS ONLY public.event_resource_reservations DROP CONSTRAINT IF EXISTS event_resource_reservations_pkey;
ALTER TABLE IF EXISTS ONLY public.donations DROP CONSTRAINT IF EXISTS donations_pkey;
ALTER TABLE IF EXISTS ONLY public.donation_categories DROP CONSTRAINT IF EXISTS donation_categories_pkey;
ALTER TABLE IF EXISTS ONLY public.donation_campaigns DROP CONSTRAINT IF EXISTS donation_campaigns_pkey;
ALTER TABLE IF EXISTS ONLY public.dashboard_widgets DROP CONSTRAINT IF EXISTS dashboard_widgets_pkey;
ALTER TABLE IF EXISTS ONLY public.custom_reports DROP CONSTRAINT IF EXISTS custom_reports_pkey;
ALTER TABLE IF EXISTS ONLY public.communications DROP CONSTRAINT IF EXISTS communications_pkey;
ALTER TABLE IF EXISTS ONLY public.communication_templates DROP CONSTRAINT IF EXISTS communication_templates_pkey;
ALTER TABLE IF EXISTS ONLY public.churches DROP CONSTRAINT IF EXISTS churches_pkey;
ALTER TABLE IF EXISTS ONLY public.church_themes DROP CONSTRAINT IF EXISTS church_themes_pkey;
ALTER TABLE IF EXISTS ONLY public.church_subscriptions DROP CONSTRAINT IF EXISTS church_subscriptions_pkey;
ALTER TABLE IF EXISTS ONLY public.church_subscription_addons DROP CONSTRAINT IF EXISTS church_subscription_addons_pkey;
ALTER TABLE IF EXISTS ONLY public.church_qualification_settings DROP CONSTRAINT IF EXISTS church_qualification_settings_pkey;
ALTER TABLE IF EXISTS ONLY public.children_check_ins DROP CONSTRAINT IF EXISTS children_check_ins_pkey;
ALTER TABLE IF EXISTS ONLY public.check_ins DROP CONSTRAINT IF EXISTS check_ins_pkey;
ALTER TABLE IF EXISTS ONLY public.availability_matrices DROP CONSTRAINT IF EXISTS availability_matrices_pkey;
ALTER TABLE IF EXISTS ONLY public.automations DROP CONSTRAINT IF EXISTS automations_pkey;
ALTER TABLE IF EXISTS ONLY public.automation_triggers DROP CONSTRAINT IF EXISTS automation_triggers_pkey;
ALTER TABLE IF EXISTS ONLY public.automation_templates DROP CONSTRAINT IF EXISTS automation_templates_pkey;
ALTER TABLE IF EXISTS ONLY public.automation_rules DROP CONSTRAINT IF EXISTS automation_rules_pkey;
ALTER TABLE IF EXISTS ONLY public.automation_rule_executions DROP CONSTRAINT IF EXISTS automation_rule_executions_pkey;
ALTER TABLE IF EXISTS ONLY public.automation_executions DROP CONSTRAINT IF EXISTS automation_executions_pkey;
ALTER TABLE IF EXISTS ONLY public.automation_conditions DROP CONSTRAINT IF EXISTS automation_conditions_pkey;
ALTER TABLE IF EXISTS ONLY public.automation_actions DROP CONSTRAINT IF EXISTS automation_actions_pkey;
ALTER TABLE IF EXISTS ONLY public.analytics_dashboards DROP CONSTRAINT IF EXISTS analytics_dashboards_pkey;
ALTER TABLE IF EXISTS ONLY public.analytics_cache DROP CONSTRAINT IF EXISTS analytics_cache_pkey;
ALTER TABLE IF EXISTS ONLY public.accounts DROP CONSTRAINT IF EXISTS accounts_pkey;
DROP TABLE IF EXISTS public.websites;
DROP TABLE IF EXISTS public.website_requests;
DROP TABLE IF EXISTS public.website_analytics;
DROP TABLE IF EXISTS public.web_pages;
DROP TABLE IF EXISTS public.web_page_sections;
DROP TABLE IF EXISTS public.volunteers;
DROP TABLE IF EXISTS public.volunteer_recommendations;
DROP TABLE IF EXISTS public.volunteer_engagement_scores;
DROP TABLE IF EXISTS public.volunteer_assignments;
DROP TABLE IF EXISTS public.visitor_follow_ups;
DROP TABLE IF EXISTS public.verification_tokens;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.user_theme_preferences;
DROP TABLE IF EXISTS public.user_roles_advanced;
DROP TABLE IF EXISTS public.user_permissions;
DROP TABLE IF EXISTS public.testimony_qr_codes;
DROP TABLE IF EXISTS public.testimony_forms;
DROP TABLE IF EXISTS public.tenant_credentials;
DROP TABLE IF EXISTS public.support_contact_info;
DROP TABLE IF EXISTS public.subscription_plans;
DROP TABLE IF EXISTS public.subscription_addons;
DROP TABLE IF EXISTS public.spiritual_gifts;
DROP TABLE IF EXISTS public.social_media_posts;
DROP TABLE IF EXISTS public.social_media_metrics;
DROP TABLE IF EXISTS public.social_media_accounts;
DROP TABLE IF EXISTS public.sessions;
DROP TABLE IF EXISTS public.sermons;
DROP TABLE IF EXISTS public.roles;
DROP TABLE IF EXISTS public.role_permissions;
DROP TABLE IF EXISTS public.report_schedules;
DROP TABLE IF EXISTS public.report_executions;
DROP TABLE IF EXISTS public.push_subscriptions;
DROP TABLE IF EXISTS public.push_notification_logs;
DROP TABLE IF EXISTS public.prayer_testimonies;
DROP TABLE IF EXISTS public.prayer_response_templates;
DROP TABLE IF EXISTS public.prayer_requests;
DROP TABLE IF EXISTS public.prayer_qr_codes;
DROP TABLE IF EXISTS public.prayer_forms;
DROP TABLE IF EXISTS public.prayer_contacts;
DROP TABLE IF EXISTS public.prayer_categories;
DROP TABLE IF EXISTS public.prayer_approvals;
DROP TABLE IF EXISTS public.platform_settings;
DROP TABLE IF EXISTS public.plan_features;
DROP TABLE IF EXISTS public.permissions;
DROP TABLE IF EXISTS public.payment_methods;
DROP TABLE IF EXISTS public.payment_gateway_configs;
DROP TABLE IF EXISTS public.online_payments;
DROP TABLE IF EXISTS public.notifications;
DROP TABLE IF EXISTS public.notification_templates;
DROP TABLE IF EXISTS public.notification_preferences;
DROP TABLE IF EXISTS public.ministry_gap_analyses;
DROP TABLE IF EXISTS public.ministries;
DROP TABLE IF EXISTS public.members;
DROP TABLE IF EXISTS public.member_spiritual_profiles;
DROP TABLE IF EXISTS public.marketing_campaigns;
DROP TABLE IF EXISTS public.marketing_campaign_posts;
DROP TABLE IF EXISTS public.kpi_metrics;
DROP TABLE IF EXISTS public.invoices;
DROP TABLE IF EXISTS public.invoice_payments;
DROP TABLE IF EXISTS public.invoice_line_items;
DROP TABLE IF EXISTS public.invoice_communications;
DROP TABLE IF EXISTS public.integration_configs;
DROP TABLE IF EXISTS public.funnels;
DROP TABLE IF EXISTS public.funnel_steps;
DROP TABLE IF EXISTS public.funnel_conversions;
DROP TABLE IF EXISTS public.events;
DROP TABLE IF EXISTS public.event_resources;
DROP TABLE IF EXISTS public.event_resource_reservations;
DROP TABLE IF EXISTS public.donations;
DROP TABLE IF EXISTS public.donation_categories;
DROP TABLE IF EXISTS public.donation_campaigns;
DROP TABLE IF EXISTS public.dashboard_widgets;
DROP TABLE IF EXISTS public.custom_reports;
DROP TABLE IF EXISTS public.communications;
DROP TABLE IF EXISTS public.communication_templates;
DROP TABLE IF EXISTS public.churches;
DROP TABLE IF EXISTS public.church_themes;
DROP TABLE IF EXISTS public.church_subscriptions;
DROP TABLE IF EXISTS public.church_subscription_addons;
DROP TABLE IF EXISTS public.church_qualification_settings;
DROP TABLE IF EXISTS public.children_check_ins;
DROP TABLE IF EXISTS public.check_ins;
DROP TABLE IF EXISTS public.availability_matrices;
DROP TABLE IF EXISTS public.automations;
DROP TABLE IF EXISTS public.automation_triggers;
DROP TABLE IF EXISTS public.automation_templates;
DROP TABLE IF EXISTS public.automation_rules;
DROP TABLE IF EXISTS public.automation_rule_executions;
DROP TABLE IF EXISTS public.automation_executions;
DROP TABLE IF EXISTS public.automation_conditions;
DROP TABLE IF EXISTS public.automation_actions;
DROP TABLE IF EXISTS public.analytics_dashboards;
DROP TABLE IF EXISTS public.analytics_cache;
DROP TABLE IF EXISTS public.accounts;
DROP TYPE IF EXISTS public."UserRole";
DROP TYPE IF EXISTS public."FunnelType";
DROP TYPE IF EXISTS public."FunnelStepType";
DROP TYPE IF EXISTS public."AutomationTriggerType";
DROP TYPE IF EXISTS public."AutomationConditionType";
DROP TYPE IF EXISTS public."AutomationActionType";
-- *not* dropping schema, since initdb creates it
--
-- TOC entry 5 (class 2615 OID 9479856)
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


--
-- TOC entry 4578 (class 0 OID 0)
-- Dependencies: 5
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS '';


--
-- TOC entry 954 (class 1247 OID 9479958)
-- Name: AutomationActionType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AutomationActionType" AS ENUM (
    'SEND_NOTIFICATION',
    'SEND_EMAIL',
    'SEND_PUSH',
    'SEND_SMS',
    'CREATE_FOLLOW_UP',
    'ASSIGN_VOLUNTEER',
    'UPDATE_MEMBER',
    'CREATE_EVENT',
    'CUSTOM_WEBHOOK'
);


--
-- TOC entry 951 (class 1247 OID 9479924)
-- Name: AutomationConditionType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AutomationConditionType" AS ENUM (
    'EQUALS',
    'NOT_EQUALS',
    'GREATER_THAN',
    'LESS_THAN',
    'CONTAINS',
    'NOT_CONTAINS',
    'IN',
    'NOT_IN',
    'EXISTS',
    'NOT_EXISTS',
    'DATE_BEFORE',
    'DATE_AFTER',
    'DATE_BETWEEN',
    'TIME_BEFORE',
    'TIME_AFTER',
    'CUSTOM'
);


--
-- TOC entry 948 (class 1247 OID 9479898)
-- Name: AutomationTriggerType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."AutomationTriggerType" AS ENUM (
    'MEMBER_JOINED',
    'DONATION_RECEIVED',
    'EVENT_CREATED',
    'EVENT_UPDATED',
    'ATTENDANCE_RECORDED',
    'VOLUNTEER_ASSIGNED',
    'BIRTHDAY',
    'ANNIVERSARY',
    'SERMON_PUBLISHED',
    'COMMUNICATION_SENT',
    'FOLLOW_UP_DUE',
    'CUSTOM_EVENT'
);


--
-- TOC entry 945 (class 1247 OID 9479882)
-- Name: FunnelStepType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."FunnelStepType" AS ENUM (
    'LANDING_PAGE',
    'OPT_IN',
    'THANK_YOU',
    'SALES_PAGE',
    'CHECKOUT',
    'CONFIRMATION',
    'CUSTOM'
);


--
-- TOC entry 942 (class 1247 OID 9479870)
-- Name: FunnelType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."FunnelType" AS ENUM (
    'LEAD_GENERATION',
    'EVENT_REGISTRATION',
    'DONATION',
    'NEWSLETTER',
    'CUSTOM'
);


--
-- TOC entry 939 (class 1247 OID 9479858)
-- Name: UserRole; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."UserRole" AS ENUM (
    'SUPER_ADMIN',
    'ADMIN_IGLESIA',
    'PASTOR',
    'LIDER',
    'MIEMBRO'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 258 (class 1259 OID 9480401)
-- Name: accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.accounts (
    id text NOT NULL,
    "userId" text NOT NULL,
    type text NOT NULL,
    provider text NOT NULL,
    "providerAccountId" text NOT NULL,
    refresh_token text,
    access_token text,
    expires_at integer,
    token_type text,
    scope text,
    id_token text,
    session_state text
);


--
-- TOC entry 257 (class 1259 OID 9480393)
-- Name: analytics_cache; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.analytics_cache (
    id text NOT NULL,
    "cacheKey" text NOT NULL,
    "dataType" text NOT NULL,
    data text NOT NULL,
    parameters text,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 254 (class 1259 OID 9480361)
-- Name: analytics_dashboards; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.analytics_dashboards (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    layout text NOT NULL,
    "isDefault" boolean DEFAULT false NOT NULL,
    "isPublic" boolean DEFAULT false NOT NULL,
    "userRole" text,
    "createdBy" text NOT NULL,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 273 (class 1259 OID 9480559)
-- Name: automation_actions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.automation_actions (
    id text NOT NULL,
    "ruleId" text NOT NULL,
    type public."AutomationActionType" NOT NULL,
    configuration jsonb DEFAULT '{}'::jsonb NOT NULL,
    "orderIndex" integer DEFAULT 0 NOT NULL,
    delay integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 272 (class 1259 OID 9480548)
-- Name: automation_conditions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.automation_conditions (
    id text NOT NULL,
    "ruleId" text NOT NULL,
    type public."AutomationConditionType" NOT NULL,
    field text NOT NULL,
    operator text NOT NULL,
    value jsonb NOT NULL,
    "logicalOperator" text DEFAULT 'AND'::text NOT NULL,
    "groupId" text,
    "orderIndex" integer DEFAULT 0 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 245 (class 1259 OID 9480275)
-- Name: automation_executions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.automation_executions (
    id text NOT NULL,
    "automationId" text NOT NULL,
    "triggerData" text,
    status text DEFAULT 'EJECUTANDO'::text NOT NULL,
    results text,
    "executedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "completedAt" timestamp(3) without time zone,
    "churchId" text NOT NULL
);


--
-- TOC entry 274 (class 1259 OID 9480571)
-- Name: automation_rule_executions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.automation_rule_executions (
    id text NOT NULL,
    "ruleId" text NOT NULL,
    "triggerData" jsonb NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    result jsonb,
    error text,
    "executedAt" timestamp(3) without time zone,
    duration integer,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 270 (class 1259 OID 9480526)
-- Name: automation_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.automation_rules (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "churchId" text NOT NULL,
    "createdBy" text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    "executeOnce" boolean DEFAULT false NOT NULL,
    "maxExecutions" integer,
    "executionCount" integer DEFAULT 0 NOT NULL,
    "lastExecuted" timestamp(3) without time zone,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 275 (class 1259 OID 9480580)
-- Name: automation_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.automation_templates (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    category text NOT NULL,
    template jsonb NOT NULL,
    "isSystem" boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "usageCount" integer DEFAULT 0 NOT NULL,
    "createdBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 271 (class 1259 OID 9480538)
-- Name: automation_triggers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.automation_triggers (
    id text NOT NULL,
    "ruleId" text NOT NULL,
    type public."AutomationTriggerType" NOT NULL,
    "eventSource" text,
    configuration jsonb DEFAULT '{}'::jsonb NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 244 (class 1259 OID 9480266)
-- Name: automations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.automations (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    trigger text NOT NULL,
    actions text NOT NULL,
    conditions text,
    "isActive" boolean DEFAULT true NOT NULL,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 299 (class 1259 OID 9480834)
-- Name: availability_matrices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.availability_matrices (
    id text NOT NULL,
    "memberId" text NOT NULL,
    "recurringAvailability" jsonb NOT NULL,
    "blackoutDates" jsonb NOT NULL,
    "preferredMinistries" jsonb NOT NULL,
    "maxCommitmentsPerMonth" integer DEFAULT 4 NOT NULL,
    "preferredTimeSlots" jsonb NOT NULL,
    "travelWillingness" integer DEFAULT 1 NOT NULL,
    "lastUpdated" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 230 (class 1259 OID 9480101)
-- Name: check_ins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.check_ins (
    id text NOT NULL,
    "firstName" text NOT NULL,
    "lastName" text NOT NULL,
    email text,
    phone text,
    "isFirstTime" boolean DEFAULT false NOT NULL,
    "visitReason" text,
    "prayerRequest" text,
    "qrCode" text,
    "eventId" text,
    "churchId" text NOT NULL,
    "checkedInAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "visitorType" text,
    "ministryInterest" text[] DEFAULT ARRAY[]::text[],
    "ageGroup" text,
    "familyStatus" text,
    "referredBy" text,
    "followUpFormId" text,
    "automationTriggered" boolean DEFAULT false NOT NULL,
    "lastContactDate" timestamp(3) without time zone,
    "engagementScore" integer DEFAULT 0 NOT NULL
);


--
-- TOC entry 232 (class 1259 OID 9480125)
-- Name: children_check_ins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.children_check_ins (
    id text NOT NULL,
    "childName" text NOT NULL,
    "childAge" integer,
    "parentName" text NOT NULL,
    "parentPhone" text NOT NULL,
    "parentEmail" text,
    "emergencyContact" text,
    "emergencyPhone" text,
    allergies text,
    "specialNeeds" text,
    "qrCode" text NOT NULL,
    "checkedIn" boolean DEFAULT true NOT NULL,
    "checkedInAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "checkedOut" boolean DEFAULT false NOT NULL,
    "checkedOutAt" timestamp(3) without time zone,
    "checkedOutBy" text,
    "eventId" text,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "childPhotoUrl" text,
    "parentPhotoUrl" text,
    "securityPin" text DEFAULT '000000'::text NOT NULL,
    "biometricHash" text,
    "photoTakenAt" timestamp(3) without time zone,
    "backupAuthCodes" text[] DEFAULT ARRAY[]::text[],
    "pickupAttempts" jsonb[] DEFAULT ARRAY[]::jsonb[],
    "requiresBothAuth" boolean DEFAULT true NOT NULL
);


--
-- TOC entry 310 (class 1259 OID 9671074)
-- Name: church_qualification_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.church_qualification_settings (
    id text NOT NULL,
    "churchId" text NOT NULL,
    "volunteerMinMembershipDays" integer DEFAULT 0 NOT NULL,
    "volunteerRequireActiveStatus" boolean DEFAULT true NOT NULL,
    "volunteerRequireSpiritualAssessment" boolean DEFAULT false NOT NULL,
    "volunteerMinSpiritualScore" integer DEFAULT 0 NOT NULL,
    "leadershipMinMembershipDays" integer DEFAULT 365 NOT NULL,
    "leadershipRequireVolunteerExp" boolean DEFAULT false NOT NULL,
    "leadershipMinVolunteerDays" integer DEFAULT 0 NOT NULL,
    "leadershipRequireTraining" boolean DEFAULT false NOT NULL,
    "leadershipMinSpiritualScore" integer DEFAULT 70 NOT NULL,
    "leadershipMinLeadershipScore" integer DEFAULT 60 NOT NULL,
    "enableSpiritualMaturityScoring" boolean DEFAULT true NOT NULL,
    "enableLeadershipAptitudeScoring" boolean DEFAULT true NOT NULL,
    "enableMinistryPassionMatching" boolean DEFAULT true NOT NULL,
    "spiritualGiftsWeight" double precision DEFAULT 0.4 NOT NULL,
    "availabilityWeight" double precision DEFAULT 0.25 NOT NULL,
    "experienceWeight" double precision DEFAULT 0.15 NOT NULL,
    "ministryPassionWeight" double precision DEFAULT 0.1 NOT NULL,
    "activityWeight" double precision DEFAULT 0.1 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 282 (class 1259 OID 9480653)
-- Name: church_subscription_addons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.church_subscription_addons (
    id text NOT NULL,
    "subscriptionId" text NOT NULL,
    "addonId" text NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 281 (class 1259 OID 9480642)
-- Name: church_subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.church_subscriptions (
    id text NOT NULL,
    "churchId" text NOT NULL,
    "planId" text NOT NULL,
    "billingCycle" text DEFAULT 'MONTHLY'::text NOT NULL,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    "currentPeriodStart" timestamp(3) without time zone NOT NULL,
    "currentPeriodEnd" timestamp(3) without time zone NOT NULL,
    "trialEnd" timestamp(3) without time zone,
    "cancelAtPeriodEnd" boolean DEFAULT false NOT NULL,
    "cancelledAt" timestamp(3) without time zone,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 269 (class 1259 OID 9480509)
-- Name: church_themes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.church_themes (
    id text NOT NULL,
    "churchId" text NOT NULL,
    "themeName" text DEFAULT 'church-default'::text NOT NULL,
    "themeConfig" text NOT NULL,
    "logoUrl" text,
    "faviconUrl" text,
    "bannerUrl" text,
    "brandColors" text,
    "primaryFont" text DEFAULT 'Inter'::text,
    "headingFont" text DEFAULT 'Inter'::text,
    "layoutStyle" text DEFAULT 'default'::text,
    "allowMemberThemes" boolean DEFAULT true NOT NULL,
    "allowColorChanges" boolean DEFAULT true NOT NULL,
    "allowFontChanges" boolean DEFAULT true NOT NULL,
    "allowLayoutChanges" boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 217 (class 1259 OID 9479977)
-- Name: churches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.churches (
    id text NOT NULL,
    name text NOT NULL,
    address text,
    phone text,
    email text,
    website text,
    founded timestamp(3) without time zone,
    logo text,
    description text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 240 (class 1259 OID 9480230)
-- Name: communication_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.communication_templates (
    id text NOT NULL,
    name text NOT NULL,
    subject text,
    content text NOT NULL,
    type text NOT NULL,
    variables text,
    category text,
    "isActive" boolean DEFAULT true NOT NULL,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 239 (class 1259 OID 9480221)
-- Name: communications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.communications (
    id text NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    type text NOT NULL,
    "targetGroup" text,
    recipients integer,
    status text DEFAULT 'BORRADOR'::text NOT NULL,
    "scheduledAt" timestamp(3) without time zone,
    "sentAt" timestamp(3) without time zone,
    "sentBy" text NOT NULL,
    "templateId" text,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 251 (class 1259 OID 9480332)
-- Name: custom_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_reports (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "reportType" text NOT NULL,
    config text NOT NULL,
    filters text,
    columns text NOT NULL,
    "groupBy" text,
    "sortBy" text,
    "chartType" text,
    "isPublic" boolean DEFAULT false NOT NULL,
    "isTemplate" boolean DEFAULT false NOT NULL,
    "createdBy" text NOT NULL,
    "churchId" text NOT NULL,
    "lastRunAt" timestamp(3) without time zone,
    "runCount" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 255 (class 1259 OID 9480371)
-- Name: dashboard_widgets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dashboard_widgets (
    id text NOT NULL,
    "dashboardId" text NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    "chartType" text,
    "dataSource" text NOT NULL,
    filters text,
    "position" text NOT NULL,
    "refreshInterval" integer DEFAULT 300 NOT NULL,
    "isVisible" boolean DEFAULT true NOT NULL,
    config text,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 286 (class 1259 OID 9480700)
-- Name: donation_campaigns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.donation_campaigns (
    id text NOT NULL,
    title text NOT NULL,
    description text,
    "goalAmount" double precision,
    "currentAmount" double precision DEFAULT 0 NOT NULL,
    currency text DEFAULT 'COP'::text NOT NULL,
    "churchId" text NOT NULL,
    "categoryId" text,
    "isActive" boolean DEFAULT true NOT NULL,
    "isPublic" boolean DEFAULT true NOT NULL,
    slug text,
    "coverImage" text,
    "startDate" timestamp(3) without time zone,
    "endDate" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 233 (class 1259 OID 9480140)
-- Name: donation_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.donation_categories (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "churchId" text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 235 (class 1259 OID 9480159)
-- Name: donations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.donations (
    id text NOT NULL,
    amount double precision NOT NULL,
    currency text DEFAULT 'COP'::text NOT NULL,
    "donorName" text,
    "donorEmail" text,
    "donorPhone" text,
    "memberId" text,
    "categoryId" text NOT NULL,
    "paymentMethodId" text NOT NULL,
    reference text,
    notes text,
    "isAnonymous" boolean DEFAULT false NOT NULL,
    status text DEFAULT 'COMPLETADA'::text NOT NULL,
    "donationDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "campaignId" text
);


--
-- TOC entry 242 (class 1259 OID 9480248)
-- Name: event_resource_reservations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_resource_reservations (
    id text NOT NULL,
    "resourceId" text NOT NULL,
    "eventId" text NOT NULL,
    "startTime" timestamp(3) without time zone NOT NULL,
    "endTime" timestamp(3) without time zone NOT NULL,
    notes text,
    status text DEFAULT 'CONFIRMADA'::text NOT NULL,
    "reservedBy" text NOT NULL,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 241 (class 1259 OID 9480239)
-- Name: event_resources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.event_resources (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    type text NOT NULL,
    capacity integer,
    "isActive" boolean DEFAULT true NOT NULL,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 227 (class 1259 OID 9480074)
-- Name: events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.events (
    id text NOT NULL,
    title text NOT NULL,
    description text,
    "startDate" timestamp(3) without time zone NOT NULL,
    "endDate" timestamp(3) without time zone,
    location text,
    "churchId" text NOT NULL,
    "isPublic" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 266 (class 1259 OID 9480474)
-- Name: funnel_conversions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.funnel_conversions (
    id text NOT NULL,
    email text NOT NULL,
    "firstName" text,
    "lastName" text,
    phone text,
    data jsonb,
    source text,
    "ipAddress" text,
    "userAgent" text,
    "funnelId" text NOT NULL,
    "stepId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 265 (class 1259 OID 9480465)
-- Name: funnel_steps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.funnel_steps (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    content jsonb NOT NULL,
    type public."FunnelStepType" NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    settings jsonb NOT NULL,
    "funnelId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 264 (class 1259 OID 9480455)
-- Name: funnels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.funnels (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    description text,
    type public."FunnelType" NOT NULL,
    config jsonb NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "isPublished" boolean DEFAULT false NOT NULL,
    "websiteId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 243 (class 1259 OID 9480257)
-- Name: integration_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.integration_configs (
    id text NOT NULL,
    service text NOT NULL,
    config text NOT NULL,
    "isActive" boolean DEFAULT false NOT NULL,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 308 (class 1259 OID 9579027)
-- Name: invoice_communications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoice_communications (
    id text NOT NULL,
    "invoiceId" text NOT NULL,
    type text NOT NULL,
    direction text NOT NULL,
    subject text,
    message text NOT NULL,
    "sentBy" text,
    "sentTo" text,
    status text DEFAULT 'SENT'::text NOT NULL,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 306 (class 1259 OID 9579009)
-- Name: invoice_line_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoice_line_items (
    id text NOT NULL,
    "invoiceId" text NOT NULL,
    description text NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    "unitPrice" double precision NOT NULL,
    "totalPrice" double precision NOT NULL,
    metadata jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 307 (class 1259 OID 9579018)
-- Name: invoice_payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoice_payments (
    id text NOT NULL,
    "invoiceId" text NOT NULL,
    amount double precision NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "paymentMethod" text NOT NULL,
    reference text,
    notes text,
    "verifiedBy" text,
    "verifiedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 305 (class 1259 OID 9578996)
-- Name: invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoices (
    id text NOT NULL,
    "invoiceNumber" text NOT NULL,
    "churchId" text NOT NULL,
    "subscriptionId" text,
    status text DEFAULT 'DRAFT'::text NOT NULL,
    type text DEFAULT 'SUBSCRIPTION'::text NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    subtotal double precision NOT NULL,
    "taxAmount" double precision DEFAULT 0.0 NOT NULL,
    "totalAmount" double precision NOT NULL,
    "dueDate" timestamp(3) without time zone NOT NULL,
    "isRecurrent" boolean DEFAULT false NOT NULL,
    "recurrentConfig" jsonb,
    notes text,
    "pdfPath" text,
    "sentAt" timestamp(3) without time zone,
    "paidAt" timestamp(3) without time zone,
    "createdBy" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 256 (class 1259 OID 9480381)
-- Name: kpi_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kpi_metrics (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    category text NOT NULL,
    "metricType" text NOT NULL,
    "dataSource" text NOT NULL,
    target double precision,
    "currentValue" double precision NOT NULL,
    "previousValue" double precision,
    "changePercent" double precision,
    "trendDirection" text,
    color text DEFAULT 'blue'::text NOT NULL,
    icon text,
    unit text,
    period text DEFAULT 'MONTHLY'::text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "churchId" text NOT NULL,
    "lastCalculated" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 249 (class 1259 OID 9480312)
-- Name: marketing_campaign_posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.marketing_campaign_posts (
    id text NOT NULL,
    "campaignId" text NOT NULL,
    "postId" text NOT NULL,
    "accountId" text NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    "scheduledAt" timestamp(3) without time zone,
    "publishedAt" timestamp(3) without time zone,
    status text DEFAULT 'PENDING'::text NOT NULL,
    metrics text,
    notes text,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 248 (class 1259 OID 9480302)
-- Name: marketing_campaigns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.marketing_campaigns (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    objectives text,
    "targetAudience" text,
    budget double precision,
    currency text DEFAULT 'USD'::text NOT NULL,
    "startDate" timestamp(3) without time zone NOT NULL,
    "endDate" timestamp(3) without time zone,
    status text DEFAULT 'DRAFT'::text NOT NULL,
    platforms text NOT NULL,
    metrics text,
    tags text,
    "managerId" text NOT NULL,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 298 (class 1259 OID 9480823)
-- Name: member_spiritual_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_spiritual_profiles (
    id text NOT NULL,
    "memberId" text NOT NULL,
    "primaryGifts" jsonb NOT NULL,
    "secondaryGifts" jsonb NOT NULL,
    "spiritualCalling" text,
    "ministryPassions" jsonb NOT NULL,
    "experienceLevel" integer DEFAULT 1 NOT NULL,
    "leadershipScore" integer DEFAULT 1 NOT NULL,
    "servingMotivation" text,
    "previousExperience" jsonb,
    "trainingCompleted" jsonb,
    "assessmentDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "availabilityScore" integer DEFAULT 50 NOT NULL,
    "communicationSkills" integer DEFAULT 50 NOT NULL,
    "discipleshipTraining" boolean DEFAULT false NOT NULL,
    "leadershipAptitudeScore" integer DEFAULT 50 NOT NULL,
    "leadershipReadinessScore" integer DEFAULT 0 NOT NULL,
    "leadershipTrainingCompleted" boolean DEFAULT false NOT NULL,
    "leadershipTrainingDate" timestamp(3) without time zone,
    "mentoringExperience" boolean DEFAULT false NOT NULL,
    "ministryPassionScore" integer DEFAULT 50 NOT NULL,
    "organizationalSkills" integer DEFAULT 50 NOT NULL,
    "pastoralHeart" integer DEFAULT 50 NOT NULL,
    "spiritualMaturityScore" integer DEFAULT 50 NOT NULL,
    "teachingAbility" integer DEFAULT 50 NOT NULL,
    "volunteerReadinessScore" integer DEFAULT 0 NOT NULL
);


--
-- TOC entry 225 (class 1259 OID 9480051)
-- Name: members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.members (
    id text NOT NULL,
    "firstName" text NOT NULL,
    "lastName" text NOT NULL,
    email text,
    phone text,
    address text,
    city text,
    state text,
    "zipCode" text,
    "birthDate" timestamp(3) without time zone,
    "baptismDate" timestamp(3) without time zone,
    "membershipDate" timestamp(3) without time zone,
    "maritalStatus" text,
    gender text,
    occupation text,
    photo text,
    notes text,
    "churchId" text NOT NULL,
    "userId" text,
    "ministryId" text,
    "isActive" boolean DEFAULT true NOT NULL,
    "spiritualGifts" jsonb,
    "secondaryGifts" jsonb,
    "spiritualCalling" text,
    "ministryPassion" jsonb,
    "experienceLevel" integer DEFAULT 1,
    "availabilityScore" double precision DEFAULT 0.0,
    "leadershipReadiness" integer DEFAULT 1,
    "skillsMatrix" jsonb,
    "personalityType" text,
    "transportationOwned" boolean DEFAULT false,
    "childcareAvailable" boolean DEFAULT false,
    "backgroundCheckDate" timestamp(3) without time zone,
    "emergencyContact" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 218 (class 1259 OID 9479986)
-- Name: ministries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ministries (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "churchId" text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 301 (class 1259 OID 9480855)
-- Name: ministry_gap_analyses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ministry_gap_analyses (
    id text NOT NULL,
    "ministryId" text NOT NULL,
    "churchId" text NOT NULL,
    "analysisDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "gapsIdentified" jsonb NOT NULL,
    "urgencyScore" integer NOT NULL,
    "recommendedActions" jsonb NOT NULL,
    "currentStaffing" integer NOT NULL,
    "optimalStaffing" integer NOT NULL,
    "gapPercentage" double precision NOT NULL,
    "seasonalFactor" double precision DEFAULT 1.0 NOT NULL,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 237 (class 1259 OID 9480182)
-- Name: notification_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_preferences (
    id text NOT NULL,
    "userId" text NOT NULL,
    "emailEnabled" boolean DEFAULT true NOT NULL,
    "emailEvents" boolean DEFAULT true NOT NULL,
    "emailDonations" boolean DEFAULT true NOT NULL,
    "emailCommunications" boolean DEFAULT true NOT NULL,
    "emailSystemUpdates" boolean DEFAULT true NOT NULL,
    "inAppEnabled" boolean DEFAULT true NOT NULL,
    "inAppEvents" boolean DEFAULT true NOT NULL,
    "inAppDonations" boolean DEFAULT true NOT NULL,
    "inAppCommunications" boolean DEFAULT true NOT NULL,
    "inAppSystemUpdates" boolean DEFAULT true NOT NULL,
    "pushEnabled" boolean DEFAULT false NOT NULL,
    "pushEvents" boolean DEFAULT true NOT NULL,
    "pushDonations" boolean DEFAULT false NOT NULL,
    "pushCommunications" boolean DEFAULT true NOT NULL,
    "pushSystemUpdates" boolean DEFAULT true NOT NULL,
    "quietHoursEnabled" boolean DEFAULT false NOT NULL,
    "quietHoursStart" text,
    "quietHoursEnd" text,
    "weekendNotifications" boolean DEFAULT true NOT NULL,
    "digestEnabled" boolean DEFAULT false NOT NULL,
    "digestFrequency" text DEFAULT 'DAILY'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 238 (class 1259 OID 9480209)
-- Name: notification_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_templates (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    category text NOT NULL,
    type text DEFAULT 'INFO'::text NOT NULL,
    priority text DEFAULT 'NORMAL'::text NOT NULL,
    "titleTemplate" text NOT NULL,
    "messageTemplate" text NOT NULL,
    "actionLabel" text,
    "isActive" boolean DEFAULT true NOT NULL,
    "isSystem" boolean DEFAULT false NOT NULL,
    "defaultTargetRole" text,
    "churchId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 236 (class 1259 OID 9480171)
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id text NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    type text NOT NULL,
    category text,
    "targetRole" text,
    "targetUser" text,
    "isRead" boolean DEFAULT false NOT NULL,
    "isGlobal" boolean DEFAULT false NOT NULL,
    priority text DEFAULT 'NORMAL'::text NOT NULL,
    "actionUrl" text,
    "actionLabel" text,
    "expiresAt" timestamp(3) without time zone,
    "churchId" text NOT NULL,
    "createdBy" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 284 (class 1259 OID 9480679)
-- Name: online_payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.online_payments (
    id text NOT NULL,
    "paymentId" text NOT NULL,
    amount double precision NOT NULL,
    currency text DEFAULT 'COP'::text NOT NULL,
    "gatewayType" text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    "donorName" text,
    "donorEmail" text,
    "donorPhone" text,
    "donationId" text,
    "churchId" text NOT NULL,
    "categoryId" text,
    reference text,
    "gatewayReference" text,
    "redirectUrl" text,
    "returnUrl" text,
    notes text,
    metadata jsonb,
    "webhookReceived" boolean DEFAULT false NOT NULL,
    "completedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 285 (class 1259 OID 9480690)
-- Name: payment_gateway_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_gateway_configs (
    id text NOT NULL,
    "gatewayType" text NOT NULL,
    "churchId" text NOT NULL,
    "isEnabled" boolean DEFAULT false NOT NULL,
    "isTestMode" boolean DEFAULT true NOT NULL,
    "merchantId" text,
    "apiKey" text,
    "clientId" text,
    "clientSecret" text,
    "webhookSecret" text,
    configuration jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 234 (class 1259 OID 9480149)
-- Name: payment_methods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_methods (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "isDigital" boolean DEFAULT false NOT NULL,
    "churchId" text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 219 (class 1259 OID 9479995)
-- Name: permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permissions (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    resource text NOT NULL,
    action text NOT NULL,
    conditions text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 279 (class 1259 OID 9480623)
-- Name: plan_features; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plan_features (
    id text NOT NULL,
    key text NOT NULL,
    name text NOT NULL,
    description text,
    category text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 304 (class 1259 OID 9480891)
-- Name: platform_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.platform_settings (
    id text DEFAULT 'default'::text NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    "taxRate" double precision DEFAULT 0.0 NOT NULL,
    "freeTrialDays" integer DEFAULT 14 NOT NULL,
    "gracePeriodDays" integer DEFAULT 7 NOT NULL,
    "platformName" text DEFAULT 'Kḥesed-tek Church Management Systems'::text NOT NULL,
    "supportEmail" text DEFAULT 'soporte@khesedtek.com'::text NOT NULL,
    "maintenanceMode" boolean DEFAULT false NOT NULL,
    "allowRegistrations" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 291 (class 1259 OID 9480753)
-- Name: prayer_approvals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prayer_approvals (
    id text NOT NULL,
    "requestId" text NOT NULL,
    "contactId" text NOT NULL,
    "approvedBy" text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    notes text,
    "approvedAt" timestamp(3) without time zone,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 287 (class 1259 OID 9480712)
-- Name: prayer_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prayer_categories (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    icon text,
    color text,
    "isActive" boolean DEFAULT true NOT NULL,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 289 (class 1259 OID 9480731)
-- Name: prayer_contacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prayer_contacts (
    id text NOT NULL,
    "fullName" text NOT NULL,
    phone text,
    email text,
    "preferredContact" text DEFAULT 'sms'::text NOT NULL,
    "churchId" text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    source text DEFAULT 'prayer_form'::text NOT NULL,
    notes text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 292 (class 1259 OID 9480762)
-- Name: prayer_forms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prayer_forms (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    fields jsonb NOT NULL,
    style jsonb,
    "isActive" boolean DEFAULT true NOT NULL,
    "isPublic" boolean DEFAULT true NOT NULL,
    slug text NOT NULL,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 293 (class 1259 OID 9480772)
-- Name: prayer_qr_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prayer_qr_codes (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "formId" text NOT NULL,
    code text NOT NULL,
    design jsonb,
    "isActive" boolean DEFAULT true NOT NULL,
    "scanCount" integer DEFAULT 0 NOT NULL,
    "lastScan" timestamp(3) without time zone,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 290 (class 1259 OID 9480742)
-- Name: prayer_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prayer_requests (
    id text NOT NULL,
    "contactId" text NOT NULL,
    "categoryId" text NOT NULL,
    message text,
    "isAnonymous" boolean DEFAULT false NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    priority text DEFAULT 'normal'::text NOT NULL,
    "scheduledAt" timestamp(3) without time zone,
    "sentAt" timestamp(3) without time zone,
    "responseType" text,
    "churchId" text NOT NULL,
    "formId" text,
    "qrCodeId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 288 (class 1259 OID 9480721)
-- Name: prayer_response_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prayer_response_templates (
    id text NOT NULL,
    "categoryId" text NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    "smsMessage" text,
    "isActive" boolean DEFAULT true NOT NULL,
    "isDefault" boolean DEFAULT false NOT NULL,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 294 (class 1259 OID 9480782)
-- Name: prayer_testimonies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prayer_testimonies (
    id text NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    "contactId" text,
    "prayerRequestId" text,
    category text DEFAULT 'general'::text NOT NULL,
    "isAnonymous" boolean DEFAULT false NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    "isPublic" boolean DEFAULT false NOT NULL,
    "imageUrl" text,
    tags jsonb,
    "churchId" text NOT NULL,
    "formId" text,
    "qrCodeId" text,
    "approvedBy" text,
    "approvedAt" timestamp(3) without time zone,
    "submittedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 277 (class 1259 OID 9480600)
-- Name: push_notification_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.push_notification_logs (
    id text NOT NULL,
    "churchId" text NOT NULL,
    "userId" text,
    title text NOT NULL,
    body text NOT NULL,
    payload jsonb,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "deliveryAttempts" integer DEFAULT 0 NOT NULL,
    "lastAttempt" timestamp(3) without time zone,
    error text,
    "clickedAt" timestamp(3) without time zone,
    "dismissedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 276 (class 1259 OID 9480591)
-- Name: push_subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.push_subscriptions (
    id text NOT NULL,
    "userId" text NOT NULL,
    "churchId" text NOT NULL,
    endpoint text NOT NULL,
    p256dh text NOT NULL,
    auth text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "userAgent" text,
    platform text,
    language text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 253 (class 1259 OID 9480353)
-- Name: report_executions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.report_executions (
    id text NOT NULL,
    "reportId" text NOT NULL,
    status text NOT NULL,
    format text NOT NULL,
    "fileUrl" text,
    parameters text,
    "rowCount" integer,
    "executionTime" integer,
    "errorMessage" text,
    "executedBy" text,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "completedAt" timestamp(3) without time zone
);


--
-- TOC entry 252 (class 1259 OID 9480343)
-- Name: report_schedules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.report_schedules (
    id text NOT NULL,
    "reportId" text NOT NULL,
    frequency text NOT NULL,
    "dayOfWeek" integer,
    "dayOfMonth" integer,
    "time" text NOT NULL,
    recipients text NOT NULL,
    format text DEFAULT 'PDF'::text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "lastSent" timestamp(3) without time zone,
    "nextScheduled" timestamp(3) without time zone,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 221 (class 1259 OID 9480015)
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.role_permissions (
    id text NOT NULL,
    "roleId" text NOT NULL,
    "permissionId" text NOT NULL,
    conditions text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 220 (class 1259 OID 9480004)
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "churchId" text,
    "isSystem" boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 226 (class 1259 OID 9480065)
-- Name: sermons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sermons (
    id text NOT NULL,
    title text NOT NULL,
    content text,
    outline text,
    scripture text,
    date timestamp(3) without time zone,
    speaker text,
    "churchId" text NOT NULL,
    "isPublic" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 259 (class 1259 OID 9480408)
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    id text NOT NULL,
    "sessionToken" text NOT NULL,
    "userId" text NOT NULL,
    expires timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 246 (class 1259 OID 9480284)
-- Name: social_media_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.social_media_accounts (
    id text NOT NULL,
    platform text NOT NULL,
    "accountId" text NOT NULL,
    username text,
    "displayName" text,
    "accessToken" text NOT NULL,
    "refreshToken" text,
    "tokenExpiresAt" timestamp(3) without time zone,
    "isActive" boolean DEFAULT true NOT NULL,
    "lastSync" timestamp(3) without time zone,
    "accountData" text,
    "churchId" text NOT NULL,
    "connectedBy" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 250 (class 1259 OID 9480322)
-- Name: social_media_metrics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.social_media_metrics (
    id text NOT NULL,
    "accountId" text NOT NULL,
    "postId" text,
    "campaignId" text,
    platform text NOT NULL,
    "metricType" text NOT NULL,
    value double precision NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    "periodType" text DEFAULT 'DAILY'::text NOT NULL,
    metadata text,
    "churchId" text NOT NULL,
    "collectedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 247 (class 1259 OID 9480293)
-- Name: social_media_posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.social_media_posts (
    id text NOT NULL,
    title text,
    content text NOT NULL,
    "mediaUrls" text,
    platforms text NOT NULL,
    "accountIds" text NOT NULL,
    status text DEFAULT 'DRAFT'::text NOT NULL,
    "scheduledAt" timestamp(3) without time zone,
    "publishedAt" timestamp(3) without time zone,
    "postIds" text,
    engagement text,
    hashtags text,
    mentions text,
    "campaignId" text,
    "authorId" text NOT NULL,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 297 (class 1259 OID 9480815)
-- Name: spiritual_gifts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.spiritual_gifts (
    id text NOT NULL,
    name text NOT NULL,
    category text NOT NULL,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 280 (class 1259 OID 9480632)
-- Name: subscription_addons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscription_addons (
    id text NOT NULL,
    key text NOT NULL,
    name text NOT NULL,
    description text,
    "priceMonthly" text NOT NULL,
    "priceYearly" text,
    "billingType" text DEFAULT 'MONTHLY'::text NOT NULL,
    "pricePerUnit" text,
    unit text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 278 (class 1259 OID 9480610)
-- Name: subscription_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscription_plans (
    id text NOT NULL,
    name text NOT NULL,
    "displayName" text NOT NULL,
    description text,
    "priceMonthly" text NOT NULL,
    "priceYearly" text,
    "maxChurches" integer DEFAULT 1 NOT NULL,
    "maxMembers" integer DEFAULT 100 NOT NULL,
    "maxUsers" integer DEFAULT 5 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "sortOrder" integer DEFAULT 0 NOT NULL,
    features jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 283 (class 1259 OID 9480663)
-- Name: support_contact_info; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.support_contact_info (
    id text DEFAULT 'default'::text NOT NULL,
    "whatsappNumber" text DEFAULT '+57 300 KHESED (543733)'::text NOT NULL,
    "whatsappUrl" text DEFAULT 'https://wa.me/573003435733'::text NOT NULL,
    email text DEFAULT 'soporte@khesedtek.com'::text NOT NULL,
    schedule text DEFAULT 'Lun-Vie 8AM-8PM (Colombia)'::text NOT NULL,
    "companyName" text DEFAULT 'Khesed-tek Systems'::text NOT NULL,
    location text DEFAULT 'Bogotá, Colombia'::text NOT NULL,
    website text DEFAULT 'https://khesedtek.com'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 309 (class 1259 OID 9579036)
-- Name: tenant_credentials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenant_credentials (
    id text NOT NULL,
    "churchId" text NOT NULL,
    "loginEmail" text NOT NULL,
    "tempPassword" text,
    "isFirstLogin" boolean DEFAULT true NOT NULL,
    "sentAt" timestamp(3) without time zone,
    "lastSentAt" timestamp(3) without time zone,
    "createdBy" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 295 (class 1259 OID 9480795)
-- Name: testimony_forms; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.testimony_forms (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    fields jsonb NOT NULL,
    style jsonb,
    "isActive" boolean DEFAULT true NOT NULL,
    "isPublic" boolean DEFAULT true NOT NULL,
    slug text NOT NULL,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 296 (class 1259 OID 9480805)
-- Name: testimony_qr_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.testimony_qr_codes (
    id text NOT NULL,
    name text NOT NULL,
    description text,
    "formId" text NOT NULL,
    code text NOT NULL,
    design jsonb,
    "isActive" boolean DEFAULT true NOT NULL,
    "scanCount" integer DEFAULT 0 NOT NULL,
    "lastScan" timestamp(3) without time zone,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 222 (class 1259 OID 9480023)
-- Name: user_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_permissions (
    id text NOT NULL,
    "userId" text NOT NULL,
    "permissionId" text NOT NULL,
    granted boolean DEFAULT true NOT NULL,
    conditions text,
    "expiresAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 223 (class 1259 OID 9480032)
-- Name: user_roles_advanced; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles_advanced (
    id text NOT NULL,
    "userId" text NOT NULL,
    "roleId" text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "expiresAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 268 (class 1259 OID 9480493)
-- Name: user_theme_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_theme_preferences (
    id text NOT NULL,
    "userId" text NOT NULL,
    "churchId" text,
    "themeName" text DEFAULT 'default'::text NOT NULL,
    "themeMode" text DEFAULT 'light'::text NOT NULL,
    "primaryColor" text,
    "secondaryColor" text,
    "accentColor" text,
    "destructiveColor" text,
    "backgroundColor" text,
    "foregroundColor" text,
    "cardColor" text,
    "cardForegroundColor" text,
    "borderColor" text,
    "mutedColor" text,
    "mutedForegroundColor" text,
    "fontFamily" text DEFAULT 'Inter'::text,
    "fontSize" text DEFAULT 'medium'::text,
    "borderRadius" text DEFAULT '0.5rem'::text,
    "compactMode" boolean DEFAULT false NOT NULL,
    "logoUrl" text,
    "faviconUrl" text,
    "brandName" text,
    "isActive" boolean DEFAULT true NOT NULL,
    "isPublic" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 224 (class 1259 OID 9480041)
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id text NOT NULL,
    name text,
    email text NOT NULL,
    "emailVerified" timestamp(3) without time zone,
    image text,
    password text,
    role public."UserRole" DEFAULT 'MIEMBRO'::public."UserRole" NOT NULL,
    "churchId" text,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 260 (class 1259 OID 9480415)
-- Name: verification_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.verification_tokens (
    identifier text NOT NULL,
    token text NOT NULL,
    expires timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 231 (class 1259 OID 9480114)
-- Name: visitor_follow_ups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.visitor_follow_ups (
    id text NOT NULL,
    "checkInId" text NOT NULL,
    "followUpType" text NOT NULL,
    status text DEFAULT 'PENDIENTE'::text NOT NULL,
    "scheduledAt" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    notes text,
    "assignedTo" text,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "automationRuleId" text,
    priority text DEFAULT 'MEDIUM'::text NOT NULL,
    category text,
    "touchSequence" integer,
    "responseReceived" boolean DEFAULT false NOT NULL,
    "responseData" jsonb,
    "nextActionDue" timestamp(3) without time zone,
    "ministryMatch" text
);


--
-- TOC entry 229 (class 1259 OID 9480092)
-- Name: volunteer_assignments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.volunteer_assignments (
    id text NOT NULL,
    "volunteerId" text NOT NULL,
    "eventId" text,
    title text NOT NULL,
    description text,
    date timestamp(3) without time zone NOT NULL,
    "startTime" text NOT NULL,
    "endTime" text NOT NULL,
    status text DEFAULT 'ASIGNADO'::text NOT NULL,
    notes text,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 302 (class 1259 OID 9480866)
-- Name: volunteer_engagement_scores; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.volunteer_engagement_scores (
    id text NOT NULL,
    "volunteerId" text NOT NULL,
    "currentScore" double precision DEFAULT 0.0 NOT NULL,
    "participationRate" double precision DEFAULT 0.0 NOT NULL,
    "consistencyScore" double precision DEFAULT 0.0 NOT NULL,
    "feedbackScore" double precision DEFAULT 0.0 NOT NULL,
    "growthTrend" text DEFAULT 'STABLE'::text NOT NULL,
    "lastActivityDate" timestamp(3) without time zone,
    "burnoutRisk" text DEFAULT 'LOW'::text NOT NULL,
    "recommendedActions" jsonb,
    "calculatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 300 (class 1259 OID 9480845)
-- Name: volunteer_recommendations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.volunteer_recommendations (
    id text NOT NULL,
    "memberId" text NOT NULL,
    "ministryId" text NOT NULL,
    "eventId" text,
    "recommendationType" text NOT NULL,
    "matchScore" double precision NOT NULL,
    reasoning jsonb NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    priority text DEFAULT 'MEDIUM'::text NOT NULL,
    "validUntil" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 228 (class 1259 OID 9480083)
-- Name: volunteers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.volunteers (
    id text NOT NULL,
    "memberId" text,
    "firstName" text NOT NULL,
    "lastName" text NOT NULL,
    email text,
    phone text,
    skills text,
    availability text,
    "ministryId" text,
    "churchId" text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 263 (class 1259 OID 9480445)
-- Name: web_page_sections; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.web_page_sections (
    id text NOT NULL,
    type text NOT NULL,
    content jsonb NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    "isVisible" boolean DEFAULT true NOT NULL,
    "pageId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 262 (class 1259 OID 9480434)
-- Name: web_pages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.web_pages (
    id text NOT NULL,
    title text NOT NULL,
    slug text NOT NULL,
    content jsonb NOT NULL,
    "metaTitle" text,
    "metaDescription" text,
    "metaImage" text,
    "isHomePage" boolean DEFAULT false NOT NULL,
    "isPublished" boolean DEFAULT false NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    "websiteId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 267 (class 1259 OID 9480482)
-- Name: website_analytics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.website_analytics (
    id text NOT NULL,
    "pageViews" integer DEFAULT 0 NOT NULL,
    "uniqueVisitors" integer DEFAULT 0 NOT NULL,
    "bounceRate" double precision,
    "avgSessionDuration" integer,
    referrer text,
    page text NOT NULL,
    date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "websiteId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 303 (class 1259 OID 9480881)
-- Name: website_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.website_requests (
    id text NOT NULL,
    "churchId" text NOT NULL,
    "requestType" text NOT NULL,
    "projectName" text NOT NULL,
    description text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    priority text DEFAULT 'medium'::text NOT NULL,
    "contactEmail" text NOT NULL,
    phone text,
    "estimatedPrice" integer,
    "finalPrice" integer,
    "estimatedCompletion" timestamp(3) without time zone,
    "completedAt" timestamp(3) without time zone,
    "adminNotes" text,
    metadata text,
    "existingWebsiteId" text,
    "resultingWebsiteId" text,
    "assignedTo" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 261 (class 1259 OID 9480420)
-- Name: websites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.websites (
    id text NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    domain text,
    description text,
    theme text DEFAULT 'default'::text NOT NULL,
    "primaryColor" text DEFAULT '#3B82F6'::text NOT NULL,
    "secondaryColor" text DEFAULT '#64748B'::text NOT NULL,
    "accentColor" text,
    "fontFamily" text DEFAULT 'Inter'::text NOT NULL,
    "metaTitle" text,
    "metaDescription" text,
    "metaImage" text,
    metadata text,
    "isPublished" boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "churchId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- TOC entry 4107 (class 2606 OID 9480407)
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- TOC entry 4105 (class 2606 OID 9480400)
-- Name: analytics_cache analytics_cache_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.analytics_cache
    ADD CONSTRAINT analytics_cache_pkey PRIMARY KEY (id);


--
-- TOC entry 4098 (class 2606 OID 9480370)
-- Name: analytics_dashboards analytics_dashboards_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.analytics_dashboards
    ADD CONSTRAINT analytics_dashboards_pkey PRIMARY KEY (id);


--
-- TOC entry 4155 (class 2606 OID 9480570)
-- Name: automation_actions automation_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_actions
    ADD CONSTRAINT automation_actions_pkey PRIMARY KEY (id);


--
-- TOC entry 4150 (class 2606 OID 9480558)
-- Name: automation_conditions automation_conditions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_conditions
    ADD CONSTRAINT automation_conditions_pkey PRIMARY KEY (id);


--
-- TOC entry 4077 (class 2606 OID 9480283)
-- Name: automation_executions automation_executions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_executions
    ADD CONSTRAINT automation_executions_pkey PRIMARY KEY (id);


--
-- TOC entry 4160 (class 2606 OID 9480579)
-- Name: automation_rule_executions automation_rule_executions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_rule_executions
    ADD CONSTRAINT automation_rule_executions_pkey PRIMARY KEY (id);


--
-- TOC entry 4141 (class 2606 OID 9480537)
-- Name: automation_rules automation_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_rules
    ADD CONSTRAINT automation_rules_pkey PRIMARY KEY (id);


--
-- TOC entry 4166 (class 2606 OID 9480590)
-- Name: automation_templates automation_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_templates
    ADD CONSTRAINT automation_templates_pkey PRIMARY KEY (id);


--
-- TOC entry 4145 (class 2606 OID 9480547)
-- Name: automation_triggers automation_triggers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_triggers
    ADD CONSTRAINT automation_triggers_pkey PRIMARY KEY (id);


--
-- TOC entry 4075 (class 2606 OID 9480274)
-- Name: automations automations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automations
    ADD CONSTRAINT automations_pkey PRIMARY KEY (id);


--
-- TOC entry 4248 (class 2606 OID 9480844)
-- Name: availability_matrices availability_matrices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.availability_matrices
    ADD CONSTRAINT availability_matrices_pkey PRIMARY KEY (id);


--
-- TOC entry 4043 (class 2606 OID 9480113)
-- Name: check_ins check_ins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.check_ins
    ADD CONSTRAINT check_ins_pkey PRIMARY KEY (id);


--
-- TOC entry 4048 (class 2606 OID 9480139)
-- Name: children_check_ins children_check_ins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.children_check_ins
    ADD CONSTRAINT children_check_ins_pkey PRIMARY KEY (id);


--
-- TOC entry 4281 (class 2606 OID 9671099)
-- Name: church_qualification_settings church_qualification_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.church_qualification_settings
    ADD CONSTRAINT church_qualification_settings_pkey PRIMARY KEY (id);


--
-- TOC entry 4195 (class 2606 OID 9480662)
-- Name: church_subscription_addons church_subscription_addons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.church_subscription_addons
    ADD CONSTRAINT church_subscription_addons_pkey PRIMARY KEY (id);


--
-- TOC entry 4191 (class 2606 OID 9480652)
-- Name: church_subscriptions church_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.church_subscriptions
    ADD CONSTRAINT church_subscriptions_pkey PRIMARY KEY (id);


--
-- TOC entry 4137 (class 2606 OID 9480525)
-- Name: church_themes church_themes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.church_themes
    ADD CONSTRAINT church_themes_pkey PRIMARY KEY (id);


--
-- TOC entry 4009 (class 2606 OID 9479985)
-- Name: churches churches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.churches
    ADD CONSTRAINT churches_pkey PRIMARY KEY (id);


--
-- TOC entry 4067 (class 2606 OID 9480238)
-- Name: communication_templates communication_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_templates
    ADD CONSTRAINT communication_templates_pkey PRIMARY KEY (id);


--
-- TOC entry 4065 (class 2606 OID 9480229)
-- Name: communications communications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communications
    ADD CONSTRAINT communications_pkey PRIMARY KEY (id);


--
-- TOC entry 4092 (class 2606 OID 9480342)
-- Name: custom_reports custom_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_reports
    ADD CONSTRAINT custom_reports_pkey PRIMARY KEY (id);


--
-- TOC entry 4100 (class 2606 OID 9480380)
-- Name: dashboard_widgets dashboard_widgets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_widgets
    ADD CONSTRAINT dashboard_widgets_pkey PRIMARY KEY (id);


--
-- TOC entry 4210 (class 2606 OID 9480711)
-- Name: donation_campaigns donation_campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.donation_campaigns
    ADD CONSTRAINT donation_campaigns_pkey PRIMARY KEY (id);


--
-- TOC entry 4051 (class 2606 OID 9480148)
-- Name: donation_categories donation_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.donation_categories
    ADD CONSTRAINT donation_categories_pkey PRIMARY KEY (id);


--
-- TOC entry 4055 (class 2606 OID 9480170)
-- Name: donations donations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.donations
    ADD CONSTRAINT donations_pkey PRIMARY KEY (id);


--
-- TOC entry 4071 (class 2606 OID 9480256)
-- Name: event_resource_reservations event_resource_reservations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_resource_reservations
    ADD CONSTRAINT event_resource_reservations_pkey PRIMARY KEY (id);


--
-- TOC entry 4069 (class 2606 OID 9480247)
-- Name: event_resources event_resources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_resources
    ADD CONSTRAINT event_resources_pkey PRIMARY KEY (id);


--
-- TOC entry 4037 (class 2606 OID 9480082)
-- Name: events events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- TOC entry 4129 (class 2606 OID 9480481)
-- Name: funnel_conversions funnel_conversions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.funnel_conversions
    ADD CONSTRAINT funnel_conversions_pkey PRIMARY KEY (id);


--
-- TOC entry 4127 (class 2606 OID 9480473)
-- Name: funnel_steps funnel_steps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.funnel_steps
    ADD CONSTRAINT funnel_steps_pkey PRIMARY KEY (id);


--
-- TOC entry 4123 (class 2606 OID 9480464)
-- Name: funnels funnels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.funnels
    ADD CONSTRAINT funnels_pkey PRIMARY KEY (id);


--
-- TOC entry 4073 (class 2606 OID 9480265)
-- Name: integration_configs integration_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.integration_configs
    ADD CONSTRAINT integration_configs_pkey PRIMARY KEY (id);


--
-- TOC entry 4274 (class 2606 OID 9579035)
-- Name: invoice_communications invoice_communications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_communications
    ADD CONSTRAINT invoice_communications_pkey PRIMARY KEY (id);


--
-- TOC entry 4268 (class 2606 OID 9579017)
-- Name: invoice_line_items invoice_line_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_line_items
    ADD CONSTRAINT invoice_line_items_pkey PRIMARY KEY (id);


--
-- TOC entry 4271 (class 2606 OID 9579026)
-- Name: invoice_payments invoice_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_payments
    ADD CONSTRAINT invoice_payments_pkey PRIMARY KEY (id);


--
-- TOC entry 4265 (class 2606 OID 9579008)
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- TOC entry 4102 (class 2606 OID 9480392)
-- Name: kpi_metrics kpi_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kpi_metrics
    ADD CONSTRAINT kpi_metrics_pkey PRIMARY KEY (id);


--
-- TOC entry 4087 (class 2606 OID 9480321)
-- Name: marketing_campaign_posts marketing_campaign_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.marketing_campaign_posts
    ADD CONSTRAINT marketing_campaign_posts_pkey PRIMARY KEY (id);


--
-- TOC entry 4084 (class 2606 OID 9480311)
-- Name: marketing_campaigns marketing_campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.marketing_campaigns
    ADD CONSTRAINT marketing_campaigns_pkey PRIMARY KEY (id);


--
-- TOC entry 4245 (class 2606 OID 9480833)
-- Name: member_spiritual_profiles member_spiritual_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_spiritual_profiles
    ADD CONSTRAINT member_spiritual_profiles_pkey PRIMARY KEY (id);


--
-- TOC entry 4032 (class 2606 OID 9480064)
-- Name: members members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_pkey PRIMARY KEY (id);


--
-- TOC entry 4011 (class 2606 OID 9479994)
-- Name: ministries ministries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ministries
    ADD CONSTRAINT ministries_pkey PRIMARY KEY (id);


--
-- TOC entry 4252 (class 2606 OID 9480865)
-- Name: ministry_gap_analyses ministry_gap_analyses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ministry_gap_analyses
    ADD CONSTRAINT ministry_gap_analyses_pkey PRIMARY KEY (id);


--
-- TOC entry 4059 (class 2606 OID 9480208)
-- Name: notification_preferences notification_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_pkey PRIMARY KEY (id);


--
-- TOC entry 4063 (class 2606 OID 9480220)
-- Name: notification_templates notification_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_templates
    ADD CONSTRAINT notification_templates_pkey PRIMARY KEY (id);


--
-- TOC entry 4057 (class 2606 OID 9480181)
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- TOC entry 4204 (class 2606 OID 9480689)
-- Name: online_payments online_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.online_payments
    ADD CONSTRAINT online_payments_pkey PRIMARY KEY (id);


--
-- TOC entry 4208 (class 2606 OID 9480699)
-- Name: payment_gateway_configs payment_gateway_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_gateway_configs
    ADD CONSTRAINT payment_gateway_configs_pkey PRIMARY KEY (id);


--
-- TOC entry 4053 (class 2606 OID 9480158)
-- Name: payment_methods payment_methods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_methods
    ADD CONSTRAINT payment_methods_pkey PRIMARY KEY (id);


--
-- TOC entry 4014 (class 2606 OID 9480003)
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- TOC entry 4184 (class 2606 OID 9480631)
-- Name: plan_features plan_features_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plan_features
    ADD CONSTRAINT plan_features_pkey PRIMARY KEY (id);


--
-- TOC entry 4259 (class 2606 OID 9480907)
-- Name: platform_settings platform_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.platform_settings
    ADD CONSTRAINT platform_settings_pkey PRIMARY KEY (id);


--
-- TOC entry 4224 (class 2606 OID 9480761)
-- Name: prayer_approvals prayer_approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_approvals
    ADD CONSTRAINT prayer_approvals_pkey PRIMARY KEY (id);


--
-- TOC entry 4214 (class 2606 OID 9480720)
-- Name: prayer_categories prayer_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_categories
    ADD CONSTRAINT prayer_categories_pkey PRIMARY KEY (id);


--
-- TOC entry 4220 (class 2606 OID 9480741)
-- Name: prayer_contacts prayer_contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_contacts
    ADD CONSTRAINT prayer_contacts_pkey PRIMARY KEY (id);


--
-- TOC entry 4227 (class 2606 OID 9480771)
-- Name: prayer_forms prayer_forms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_forms
    ADD CONSTRAINT prayer_forms_pkey PRIMARY KEY (id);


--
-- TOC entry 4231 (class 2606 OID 9480781)
-- Name: prayer_qr_codes prayer_qr_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_qr_codes
    ADD CONSTRAINT prayer_qr_codes_pkey PRIMARY KEY (id);


--
-- TOC entry 4222 (class 2606 OID 9480752)
-- Name: prayer_requests prayer_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_requests
    ADD CONSTRAINT prayer_requests_pkey PRIMARY KEY (id);


--
-- TOC entry 4216 (class 2606 OID 9480730)
-- Name: prayer_response_templates prayer_response_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_response_templates
    ADD CONSTRAINT prayer_response_templates_pkey PRIMARY KEY (id);


--
-- TOC entry 4233 (class 2606 OID 9480794)
-- Name: prayer_testimonies prayer_testimonies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_testimonies
    ADD CONSTRAINT prayer_testimonies_pkey PRIMARY KEY (id);


--
-- TOC entry 4176 (class 2606 OID 9480609)
-- Name: push_notification_logs push_notification_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_notification_logs
    ADD CONSTRAINT push_notification_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 4170 (class 2606 OID 9480599)
-- Name: push_subscriptions push_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT push_subscriptions_pkey PRIMARY KEY (id);


--
-- TOC entry 4096 (class 2606 OID 9480360)
-- Name: report_executions report_executions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_executions
    ADD CONSTRAINT report_executions_pkey PRIMARY KEY (id);


--
-- TOC entry 4094 (class 2606 OID 9480352)
-- Name: report_schedules report_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_schedules
    ADD CONSTRAINT report_schedules_pkey PRIMARY KEY (id);


--
-- TOC entry 4020 (class 2606 OID 9480022)
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (id);


--
-- TOC entry 4018 (class 2606 OID 9480014)
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- TOC entry 4035 (class 2606 OID 9480073)
-- Name: sermons sermons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sermons
    ADD CONSTRAINT sermons_pkey PRIMARY KEY (id);


--
-- TOC entry 4110 (class 2606 OID 9480414)
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- TOC entry 4079 (class 2606 OID 9480292)
-- Name: social_media_accounts social_media_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_media_accounts
    ADD CONSTRAINT social_media_accounts_pkey PRIMARY KEY (id);


--
-- TOC entry 4090 (class 2606 OID 9480331)
-- Name: social_media_metrics social_media_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_media_metrics
    ADD CONSTRAINT social_media_metrics_pkey PRIMARY KEY (id);


--
-- TOC entry 4082 (class 2606 OID 9480301)
-- Name: social_media_posts social_media_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_media_posts
    ADD CONSTRAINT social_media_posts_pkey PRIMARY KEY (id);


--
-- TOC entry 4242 (class 2606 OID 9480822)
-- Name: spiritual_gifts spiritual_gifts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.spiritual_gifts
    ADD CONSTRAINT spiritual_gifts_pkey PRIMARY KEY (id);


--
-- TOC entry 4187 (class 2606 OID 9480641)
-- Name: subscription_addons subscription_addons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_addons
    ADD CONSTRAINT subscription_addons_pkey PRIMARY KEY (id);


--
-- TOC entry 4181 (class 2606 OID 9480622)
-- Name: subscription_plans subscription_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_pkey PRIMARY KEY (id);


--
-- TOC entry 4198 (class 2606 OID 9480678)
-- Name: support_contact_info support_contact_info_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.support_contact_info
    ADD CONSTRAINT support_contact_info_pkey PRIMARY KEY (id);


--
-- TOC entry 4278 (class 2606 OID 9579044)
-- Name: tenant_credentials tenant_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenant_credentials
    ADD CONSTRAINT tenant_credentials_pkey PRIMARY KEY (id);


--
-- TOC entry 4235 (class 2606 OID 9480804)
-- Name: testimony_forms testimony_forms_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.testimony_forms
    ADD CONSTRAINT testimony_forms_pkey PRIMARY KEY (id);


--
-- TOC entry 4239 (class 2606 OID 9480814)
-- Name: testimony_qr_codes testimony_qr_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.testimony_qr_codes
    ADD CONSTRAINT testimony_qr_codes_pkey PRIMARY KEY (id);


--
-- TOC entry 4023 (class 2606 OID 9480031)
-- Name: user_permissions user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_pkey PRIMARY KEY (id);


--
-- TOC entry 4026 (class 2606 OID 9480040)
-- Name: user_roles_advanced user_roles_advanced_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles_advanced
    ADD CONSTRAINT user_roles_advanced_pkey PRIMARY KEY (id);


--
-- TOC entry 4133 (class 2606 OID 9480508)
-- Name: user_theme_preferences user_theme_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_theme_preferences
    ADD CONSTRAINT user_theme_preferences_pkey PRIMARY KEY (id);


--
-- TOC entry 4030 (class 2606 OID 9480050)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 4046 (class 2606 OID 9480124)
-- Name: visitor_follow_ups visitor_follow_ups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visitor_follow_ups
    ADD CONSTRAINT visitor_follow_ups_pkey PRIMARY KEY (id);


--
-- TOC entry 4041 (class 2606 OID 9480100)
-- Name: volunteer_assignments volunteer_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.volunteer_assignments
    ADD CONSTRAINT volunteer_assignments_pkey PRIMARY KEY (id);


--
-- TOC entry 4254 (class 2606 OID 9480880)
-- Name: volunteer_engagement_scores volunteer_engagement_scores_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.volunteer_engagement_scores
    ADD CONSTRAINT volunteer_engagement_scores_pkey PRIMARY KEY (id);


--
-- TOC entry 4250 (class 2606 OID 9480854)
-- Name: volunteer_recommendations volunteer_recommendations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.volunteer_recommendations
    ADD CONSTRAINT volunteer_recommendations_pkey PRIMARY KEY (id);


--
-- TOC entry 4039 (class 2606 OID 9480091)
-- Name: volunteers volunteers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.volunteers
    ADD CONSTRAINT volunteers_pkey PRIMARY KEY (id);


--
-- TOC entry 4121 (class 2606 OID 9480454)
-- Name: web_page_sections web_page_sections_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.web_page_sections
    ADD CONSTRAINT web_page_sections_pkey PRIMARY KEY (id);


--
-- TOC entry 4118 (class 2606 OID 9480444)
-- Name: web_pages web_pages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.web_pages
    ADD CONSTRAINT web_pages_pkey PRIMARY KEY (id);


--
-- TOC entry 4131 (class 2606 OID 9480492)
-- Name: website_analytics website_analytics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.website_analytics
    ADD CONSTRAINT website_analytics_pkey PRIMARY KEY (id);


--
-- TOC entry 4257 (class 2606 OID 9480890)
-- Name: website_requests website_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.website_requests
    ADD CONSTRAINT website_requests_pkey PRIMARY KEY (id);


--
-- TOC entry 4115 (class 2606 OID 9480433)
-- Name: websites websites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.websites
    ADD CONSTRAINT websites_pkey PRIMARY KEY (id);


--
-- TOC entry 4108 (class 1259 OID 9480924)
-- Name: accounts_provider_providerAccountId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "accounts_provider_providerAccountId_key" ON public.accounts USING btree (provider, "providerAccountId");


--
-- TOC entry 4103 (class 1259 OID 9480923)
-- Name: analytics_cache_cacheKey_churchId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "analytics_cache_cacheKey_churchId_key" ON public.analytics_cache USING btree ("cacheKey", "churchId");


--
-- TOC entry 4153 (class 1259 OID 9480945)
-- Name: automation_actions_orderIndex_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "automation_actions_orderIndex_idx" ON public.automation_actions USING btree ("orderIndex");


--
-- TOC entry 4156 (class 1259 OID 9480943)
-- Name: automation_actions_ruleId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "automation_actions_ruleId_idx" ON public.automation_actions USING btree ("ruleId");


--
-- TOC entry 4157 (class 1259 OID 9480944)
-- Name: automation_actions_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX automation_actions_type_idx ON public.automation_actions USING btree (type);


--
-- TOC entry 4148 (class 1259 OID 9480942)
-- Name: automation_conditions_groupId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "automation_conditions_groupId_idx" ON public.automation_conditions USING btree ("groupId");


--
-- TOC entry 4151 (class 1259 OID 9480940)
-- Name: automation_conditions_ruleId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "automation_conditions_ruleId_idx" ON public.automation_conditions USING btree ("ruleId");


--
-- TOC entry 4152 (class 1259 OID 9480941)
-- Name: automation_conditions_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX automation_conditions_type_idx ON public.automation_conditions USING btree (type);


--
-- TOC entry 4158 (class 1259 OID 9480948)
-- Name: automation_rule_executions_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "automation_rule_executions_createdAt_idx" ON public.automation_rule_executions USING btree ("createdAt");


--
-- TOC entry 4161 (class 1259 OID 9480946)
-- Name: automation_rule_executions_ruleId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "automation_rule_executions_ruleId_idx" ON public.automation_rule_executions USING btree ("ruleId");


--
-- TOC entry 4162 (class 1259 OID 9480947)
-- Name: automation_rule_executions_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX automation_rule_executions_status_idx ON public.automation_rule_executions USING btree (status);


--
-- TOC entry 4138 (class 1259 OID 9480934)
-- Name: automation_rules_churchId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "automation_rules_churchId_idx" ON public.automation_rules USING btree ("churchId");


--
-- TOC entry 4139 (class 1259 OID 9480935)
-- Name: automation_rules_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "automation_rules_isActive_idx" ON public.automation_rules USING btree ("isActive");


--
-- TOC entry 4142 (class 1259 OID 9480936)
-- Name: automation_rules_priority_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX automation_rules_priority_idx ON public.automation_rules USING btree (priority);


--
-- TOC entry 4163 (class 1259 OID 9480949)
-- Name: automation_templates_category_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX automation_templates_category_idx ON public.automation_templates USING btree (category);


--
-- TOC entry 4164 (class 1259 OID 9480950)
-- Name: automation_templates_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "automation_templates_isActive_idx" ON public.automation_templates USING btree ("isActive");


--
-- TOC entry 4143 (class 1259 OID 9480939)
-- Name: automation_triggers_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "automation_triggers_isActive_idx" ON public.automation_triggers USING btree ("isActive");


--
-- TOC entry 4146 (class 1259 OID 9480937)
-- Name: automation_triggers_ruleId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "automation_triggers_ruleId_idx" ON public.automation_triggers USING btree ("ruleId");


--
-- TOC entry 4147 (class 1259 OID 9480938)
-- Name: automation_triggers_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX automation_triggers_type_idx ON public.automation_triggers USING btree (type);


--
-- TOC entry 4246 (class 1259 OID 9480984)
-- Name: availability_matrices_memberId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "availability_matrices_memberId_key" ON public.availability_matrices USING btree ("memberId");


--
-- TOC entry 4044 (class 1259 OID 9480916)
-- Name: check_ins_qrCode_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "check_ins_qrCode_key" ON public.check_ins USING btree ("qrCode");


--
-- TOC entry 4049 (class 1259 OID 9480917)
-- Name: children_check_ins_qrCode_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "children_check_ins_qrCode_key" ON public.children_check_ins USING btree ("qrCode");


--
-- TOC entry 4279 (class 1259 OID 9671100)
-- Name: church_qualification_settings_churchId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "church_qualification_settings_churchId_key" ON public.church_qualification_settings USING btree ("churchId");


--
-- TOC entry 4196 (class 1259 OID 9480966)
-- Name: church_subscription_addons_subscriptionId_addonId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "church_subscription_addons_subscriptionId_addonId_key" ON public.church_subscription_addons USING btree ("subscriptionId", "addonId");


--
-- TOC entry 4188 (class 1259 OID 9480963)
-- Name: church_subscriptions_churchId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "church_subscriptions_churchId_idx" ON public.church_subscriptions USING btree ("churchId");


--
-- TOC entry 4189 (class 1259 OID 9480962)
-- Name: church_subscriptions_churchId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "church_subscriptions_churchId_key" ON public.church_subscriptions USING btree ("churchId");


--
-- TOC entry 4192 (class 1259 OID 9480964)
-- Name: church_subscriptions_planId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "church_subscriptions_planId_idx" ON public.church_subscriptions USING btree ("planId");


--
-- TOC entry 4193 (class 1259 OID 9480965)
-- Name: church_subscriptions_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX church_subscriptions_status_idx ON public.church_subscriptions USING btree (status);


--
-- TOC entry 4135 (class 1259 OID 9480933)
-- Name: church_themes_churchId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "church_themes_churchId_key" ON public.church_themes USING btree ("churchId");


--
-- TOC entry 4211 (class 1259 OID 9480973)
-- Name: donation_campaigns_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX donation_campaigns_slug_key ON public.donation_campaigns USING btree (slug);


--
-- TOC entry 4125 (class 1259 OID 9480931)
-- Name: funnel_steps_funnelId_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "funnel_steps_funnelId_slug_key" ON public.funnel_steps USING btree ("funnelId", slug);


--
-- TOC entry 4124 (class 1259 OID 9480930)
-- Name: funnels_websiteId_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "funnels_websiteId_slug_key" ON public.funnels USING btree ("websiteId", slug);


--
-- TOC entry 4272 (class 1259 OID 9579051)
-- Name: invoice_communications_invoiceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "invoice_communications_invoiceId_idx" ON public.invoice_communications USING btree ("invoiceId");


--
-- TOC entry 4275 (class 1259 OID 9579052)
-- Name: invoice_communications_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX invoice_communications_type_idx ON public.invoice_communications USING btree (type);


--
-- TOC entry 4269 (class 1259 OID 9579050)
-- Name: invoice_payments_invoiceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "invoice_payments_invoiceId_idx" ON public.invoice_payments USING btree ("invoiceId");


--
-- TOC entry 4260 (class 1259 OID 9579046)
-- Name: invoices_churchId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "invoices_churchId_idx" ON public.invoices USING btree ("churchId");


--
-- TOC entry 4261 (class 1259 OID 9579048)
-- Name: invoices_dueDate_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "invoices_dueDate_idx" ON public.invoices USING btree ("dueDate");


--
-- TOC entry 4262 (class 1259 OID 9579049)
-- Name: invoices_invoiceNumber_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "invoices_invoiceNumber_idx" ON public.invoices USING btree ("invoiceNumber");


--
-- TOC entry 4263 (class 1259 OID 9579045)
-- Name: invoices_invoiceNumber_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "invoices_invoiceNumber_key" ON public.invoices USING btree ("invoiceNumber");


--
-- TOC entry 4266 (class 1259 OID 9579047)
-- Name: invoices_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX invoices_status_idx ON public.invoices USING btree (status);


--
-- TOC entry 4085 (class 1259 OID 9480921)
-- Name: marketing_campaign_posts_campaignId_postId_accountId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "marketing_campaign_posts_campaignId_postId_accountId_key" ON public.marketing_campaign_posts USING btree ("campaignId", "postId", "accountId");


--
-- TOC entry 4243 (class 1259 OID 9480983)
-- Name: member_spiritual_profiles_memberId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "member_spiritual_profiles_memberId_key" ON public.member_spiritual_profiles USING btree ("memberId");


--
-- TOC entry 4033 (class 1259 OID 9480915)
-- Name: members_userId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "members_userId_key" ON public.members USING btree ("userId");


--
-- TOC entry 4060 (class 1259 OID 9480918)
-- Name: notification_preferences_userId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "notification_preferences_userId_key" ON public.notification_preferences USING btree ("userId");


--
-- TOC entry 4061 (class 1259 OID 9480919)
-- Name: notification_templates_name_churchId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "notification_templates_name_churchId_key" ON public.notification_templates USING btree (name, "churchId");


--
-- TOC entry 4199 (class 1259 OID 9480971)
-- Name: online_payments_churchId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "online_payments_churchId_idx" ON public.online_payments USING btree ("churchId");


--
-- TOC entry 4200 (class 1259 OID 9480968)
-- Name: online_payments_donationId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "online_payments_donationId_key" ON public.online_payments USING btree ("donationId");


--
-- TOC entry 4201 (class 1259 OID 9480969)
-- Name: online_payments_paymentId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "online_payments_paymentId_idx" ON public.online_payments USING btree ("paymentId");


--
-- TOC entry 4202 (class 1259 OID 9480967)
-- Name: online_payments_paymentId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "online_payments_paymentId_key" ON public.online_payments USING btree ("paymentId");


--
-- TOC entry 4205 (class 1259 OID 9480970)
-- Name: online_payments_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX online_payments_status_idx ON public.online_payments USING btree (status);


--
-- TOC entry 4206 (class 1259 OID 9480972)
-- Name: payment_gateway_configs_churchId_gatewayType_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "payment_gateway_configs_churchId_gatewayType_key" ON public.payment_gateway_configs USING btree ("churchId", "gatewayType");


--
-- TOC entry 4012 (class 1259 OID 9480908)
-- Name: permissions_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX permissions_name_key ON public.permissions USING btree (name);


--
-- TOC entry 4015 (class 1259 OID 9480909)
-- Name: permissions_resource_action_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX permissions_resource_action_key ON public.permissions USING btree (resource, action);


--
-- TOC entry 4182 (class 1259 OID 9480960)
-- Name: plan_features_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX plan_features_key_key ON public.plan_features USING btree (key);


--
-- TOC entry 4225 (class 1259 OID 9480977)
-- Name: prayer_approvals_requestId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "prayer_approvals_requestId_key" ON public.prayer_approvals USING btree ("requestId");


--
-- TOC entry 4212 (class 1259 OID 9480974)
-- Name: prayer_categories_churchId_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "prayer_categories_churchId_name_key" ON public.prayer_categories USING btree ("churchId", name);


--
-- TOC entry 4217 (class 1259 OID 9480976)
-- Name: prayer_contacts_churchId_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "prayer_contacts_churchId_email_key" ON public.prayer_contacts USING btree ("churchId", email);


--
-- TOC entry 4218 (class 1259 OID 9480975)
-- Name: prayer_contacts_churchId_phone_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "prayer_contacts_churchId_phone_key" ON public.prayer_contacts USING btree ("churchId", phone);


--
-- TOC entry 4228 (class 1259 OID 9480978)
-- Name: prayer_forms_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX prayer_forms_slug_key ON public.prayer_forms USING btree (slug);


--
-- TOC entry 4229 (class 1259 OID 9480979)
-- Name: prayer_qr_codes_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX prayer_qr_codes_code_key ON public.prayer_qr_codes USING btree (code);


--
-- TOC entry 4173 (class 1259 OID 9480955)
-- Name: push_notification_logs_churchId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "push_notification_logs_churchId_idx" ON public.push_notification_logs USING btree ("churchId");


--
-- TOC entry 4174 (class 1259 OID 9480958)
-- Name: push_notification_logs_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "push_notification_logs_createdAt_idx" ON public.push_notification_logs USING btree ("createdAt");


--
-- TOC entry 4177 (class 1259 OID 9480957)
-- Name: push_notification_logs_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX push_notification_logs_status_idx ON public.push_notification_logs USING btree (status);


--
-- TOC entry 4178 (class 1259 OID 9480956)
-- Name: push_notification_logs_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "push_notification_logs_userId_idx" ON public.push_notification_logs USING btree ("userId");


--
-- TOC entry 4167 (class 1259 OID 9480952)
-- Name: push_subscriptions_churchId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "push_subscriptions_churchId_idx" ON public.push_subscriptions USING btree ("churchId");


--
-- TOC entry 4168 (class 1259 OID 9480953)
-- Name: push_subscriptions_isActive_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "push_subscriptions_isActive_idx" ON public.push_subscriptions USING btree ("isActive");


--
-- TOC entry 4171 (class 1259 OID 9480954)
-- Name: push_subscriptions_userId_endpoint_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "push_subscriptions_userId_endpoint_key" ON public.push_subscriptions USING btree ("userId", endpoint);


--
-- TOC entry 4172 (class 1259 OID 9480951)
-- Name: push_subscriptions_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "push_subscriptions_userId_idx" ON public.push_subscriptions USING btree ("userId");


--
-- TOC entry 4021 (class 1259 OID 9480911)
-- Name: role_permissions_roleId_permissionId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "role_permissions_roleId_permissionId_key" ON public.role_permissions USING btree ("roleId", "permissionId");


--
-- TOC entry 4016 (class 1259 OID 9480910)
-- Name: roles_name_churchId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "roles_name_churchId_key" ON public.roles USING btree (name, "churchId");


--
-- TOC entry 4111 (class 1259 OID 9480925)
-- Name: sessions_sessionToken_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "sessions_sessionToken_key" ON public.sessions USING btree ("sessionToken");


--
-- TOC entry 4080 (class 1259 OID 9480920)
-- Name: social_media_accounts_platform_accountId_churchId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "social_media_accounts_platform_accountId_churchId_key" ON public.social_media_accounts USING btree (platform, "accountId", "churchId");


--
-- TOC entry 4088 (class 1259 OID 9480922)
-- Name: social_media_metrics_accountId_postId_metricType_date_perio_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "social_media_metrics_accountId_postId_metricType_date_perio_key" ON public.social_media_metrics USING btree ("accountId", "postId", "metricType", date, "periodType");


--
-- TOC entry 4240 (class 1259 OID 9480982)
-- Name: spiritual_gifts_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX spiritual_gifts_name_key ON public.spiritual_gifts USING btree (name);


--
-- TOC entry 4185 (class 1259 OID 9480961)
-- Name: subscription_addons_key_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX subscription_addons_key_key ON public.subscription_addons USING btree (key);


--
-- TOC entry 4179 (class 1259 OID 9480959)
-- Name: subscription_plans_name_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX subscription_plans_name_key ON public.subscription_plans USING btree (name);


--
-- TOC entry 4276 (class 1259 OID 9579053)
-- Name: tenant_credentials_churchId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "tenant_credentials_churchId_key" ON public.tenant_credentials USING btree ("churchId");


--
-- TOC entry 4236 (class 1259 OID 9480980)
-- Name: testimony_forms_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX testimony_forms_slug_key ON public.testimony_forms USING btree (slug);


--
-- TOC entry 4237 (class 1259 OID 9480981)
-- Name: testimony_qr_codes_code_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX testimony_qr_codes_code_key ON public.testimony_qr_codes USING btree (code);


--
-- TOC entry 4024 (class 1259 OID 9480912)
-- Name: user_permissions_userId_permissionId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "user_permissions_userId_permissionId_key" ON public.user_permissions USING btree ("userId", "permissionId");


--
-- TOC entry 4027 (class 1259 OID 9480913)
-- Name: user_roles_advanced_userId_roleId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "user_roles_advanced_userId_roleId_key" ON public.user_roles_advanced USING btree ("userId", "roleId");


--
-- TOC entry 4134 (class 1259 OID 9480932)
-- Name: user_theme_preferences_userId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "user_theme_preferences_userId_key" ON public.user_theme_preferences USING btree ("userId");


--
-- TOC entry 4028 (class 1259 OID 9480914)
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- TOC entry 4112 (class 1259 OID 9480927)
-- Name: verification_tokens_identifier_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX verification_tokens_identifier_token_key ON public.verification_tokens USING btree (identifier, token);


--
-- TOC entry 4113 (class 1259 OID 9480926)
-- Name: verification_tokens_token_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX verification_tokens_token_key ON public.verification_tokens USING btree (token);


--
-- TOC entry 4255 (class 1259 OID 9480985)
-- Name: volunteer_engagement_scores_volunteerId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "volunteer_engagement_scores_volunteerId_key" ON public.volunteer_engagement_scores USING btree ("volunteerId");


--
-- TOC entry 4119 (class 1259 OID 9480929)
-- Name: web_pages_websiteId_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "web_pages_websiteId_slug_key" ON public.web_pages USING btree ("websiteId", slug);


--
-- TOC entry 4116 (class 1259 OID 9480928)
-- Name: websites_slug_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX websites_slug_key ON public.websites USING btree (slug);


--
-- TOC entry 4350 (class 2606 OID 9481326)
-- Name: accounts accounts_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT "accounts_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4349 (class 2606 OID 9481321)
-- Name: analytics_cache analytics_cache_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.analytics_cache
    ADD CONSTRAINT "analytics_cache_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4345 (class 2606 OID 9481301)
-- Name: analytics_dashboards analytics_dashboards_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.analytics_dashboards
    ADD CONSTRAINT "analytics_dashboards_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4367 (class 2606 OID 9481411)
-- Name: automation_actions automation_actions_ruleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_actions
    ADD CONSTRAINT "automation_actions_ruleId_fkey" FOREIGN KEY ("ruleId") REFERENCES public.automation_rules(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4366 (class 2606 OID 9481406)
-- Name: automation_conditions automation_conditions_ruleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_conditions
    ADD CONSTRAINT "automation_conditions_ruleId_fkey" FOREIGN KEY ("ruleId") REFERENCES public.automation_rules(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4328 (class 2606 OID 9481216)
-- Name: automation_executions automation_executions_automationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_executions
    ADD CONSTRAINT "automation_executions_automationId_fkey" FOREIGN KEY ("automationId") REFERENCES public.automations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4329 (class 2606 OID 9481221)
-- Name: automation_executions automation_executions_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_executions
    ADD CONSTRAINT "automation_executions_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4368 (class 2606 OID 9481416)
-- Name: automation_rule_executions automation_rule_executions_ruleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_rule_executions
    ADD CONSTRAINT "automation_rule_executions_ruleId_fkey" FOREIGN KEY ("ruleId") REFERENCES public.automation_rules(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4363 (class 2606 OID 9481391)
-- Name: automation_rules automation_rules_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_rules
    ADD CONSTRAINT "automation_rules_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4364 (class 2606 OID 9481396)
-- Name: automation_rules automation_rules_createdBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_rules
    ADD CONSTRAINT "automation_rules_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 4369 (class 2606 OID 9481421)
-- Name: automation_templates automation_templates_createdBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_templates
    ADD CONSTRAINT "automation_templates_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4365 (class 2606 OID 9481401)
-- Name: automation_triggers automation_triggers_ruleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_triggers
    ADD CONSTRAINT "automation_triggers_ruleId_fkey" FOREIGN KEY ("ruleId") REFERENCES public.automation_rules(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4327 (class 2606 OID 9481211)
-- Name: automations automations_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automations
    ADD CONSTRAINT "automations_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4406 (class 2606 OID 9481606)
-- Name: availability_matrices availability_matrices_memberId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.availability_matrices
    ADD CONSTRAINT "availability_matrices_memberId_fkey" FOREIGN KEY ("memberId") REFERENCES public.members(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4301 (class 2606 OID 9481081)
-- Name: check_ins check_ins_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.check_ins
    ADD CONSTRAINT "check_ins_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4302 (class 2606 OID 9481086)
-- Name: check_ins check_ins_eventId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.check_ins
    ADD CONSTRAINT "check_ins_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES public.events(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4306 (class 2606 OID 9481106)
-- Name: children_check_ins children_check_ins_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.children_check_ins
    ADD CONSTRAINT "children_check_ins_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4307 (class 2606 OID 9481111)
-- Name: children_check_ins children_check_ins_eventId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.children_check_ins
    ADD CONSTRAINT "children_check_ins_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES public.events(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4427 (class 2606 OID 9671101)
-- Name: church_qualification_settings church_qualification_settings_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.church_qualification_settings
    ADD CONSTRAINT "church_qualification_settings_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4376 (class 2606 OID 9481456)
-- Name: church_subscription_addons church_subscription_addons_addonId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.church_subscription_addons
    ADD CONSTRAINT "church_subscription_addons_addonId_fkey" FOREIGN KEY ("addonId") REFERENCES public.subscription_addons(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 4377 (class 2606 OID 9481461)
-- Name: church_subscription_addons church_subscription_addons_subscriptionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.church_subscription_addons
    ADD CONSTRAINT "church_subscription_addons_subscriptionId_fkey" FOREIGN KEY ("subscriptionId") REFERENCES public.church_subscriptions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4374 (class 2606 OID 9481446)
-- Name: church_subscriptions church_subscriptions_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.church_subscriptions
    ADD CONSTRAINT "church_subscriptions_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4375 (class 2606 OID 9481451)
-- Name: church_subscriptions church_subscriptions_planId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.church_subscriptions
    ADD CONSTRAINT "church_subscriptions_planId_fkey" FOREIGN KEY ("planId") REFERENCES public.subscription_plans(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 4362 (class 2606 OID 9481386)
-- Name: church_themes church_themes_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.church_themes
    ADD CONSTRAINT "church_themes_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4321 (class 2606 OID 9481181)
-- Name: communication_templates communication_templates_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communication_templates
    ADD CONSTRAINT "communication_templates_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4319 (class 2606 OID 9481171)
-- Name: communications communications_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communications
    ADD CONSTRAINT "communications_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4320 (class 2606 OID 9481176)
-- Name: communications communications_templateId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.communications
    ADD CONSTRAINT "communications_templateId_fkey" FOREIGN KEY ("templateId") REFERENCES public.communication_templates(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4340 (class 2606 OID 9481276)
-- Name: custom_reports custom_reports_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_reports
    ADD CONSTRAINT "custom_reports_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4346 (class 2606 OID 9481306)
-- Name: dashboard_widgets dashboard_widgets_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_widgets
    ADD CONSTRAINT "dashboard_widgets_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4347 (class 2606 OID 9481311)
-- Name: dashboard_widgets dashboard_widgets_dashboardId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dashboard_widgets
    ADD CONSTRAINT "dashboard_widgets_dashboardId_fkey" FOREIGN KEY ("dashboardId") REFERENCES public.analytics_dashboards(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4382 (class 2606 OID 9481486)
-- Name: donation_campaigns donation_campaigns_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.donation_campaigns
    ADD CONSTRAINT "donation_campaigns_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.donation_categories(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4383 (class 2606 OID 9481491)
-- Name: donation_campaigns donation_campaigns_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.donation_campaigns
    ADD CONSTRAINT "donation_campaigns_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4308 (class 2606 OID 9481116)
-- Name: donation_categories donation_categories_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.donation_categories
    ADD CONSTRAINT "donation_categories_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4310 (class 2606 OID 9481126)
-- Name: donations donations_campaignId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.donations
    ADD CONSTRAINT "donations_campaignId_fkey" FOREIGN KEY ("campaignId") REFERENCES public.donation_campaigns(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4311 (class 2606 OID 9481131)
-- Name: donations donations_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.donations
    ADD CONSTRAINT "donations_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.donation_categories(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 4312 (class 2606 OID 9481136)
-- Name: donations donations_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.donations
    ADD CONSTRAINT "donations_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4313 (class 2606 OID 9481141)
-- Name: donations donations_memberId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.donations
    ADD CONSTRAINT "donations_memberId_fkey" FOREIGN KEY ("memberId") REFERENCES public.members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4314 (class 2606 OID 9481146)
-- Name: donations donations_paymentMethodId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.donations
    ADD CONSTRAINT "donations_paymentMethodId_fkey" FOREIGN KEY ("paymentMethodId") REFERENCES public.payment_methods(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 4323 (class 2606 OID 9481191)
-- Name: event_resource_reservations event_resource_reservations_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_resource_reservations
    ADD CONSTRAINT "event_resource_reservations_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4324 (class 2606 OID 9481196)
-- Name: event_resource_reservations event_resource_reservations_eventId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_resource_reservations
    ADD CONSTRAINT "event_resource_reservations_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES public.events(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4325 (class 2606 OID 9481201)
-- Name: event_resource_reservations event_resource_reservations_resourceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_resource_reservations
    ADD CONSTRAINT "event_resource_reservations_resourceId_fkey" FOREIGN KEY ("resourceId") REFERENCES public.event_resources(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4322 (class 2606 OID 9481186)
-- Name: event_resources event_resources_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.event_resources
    ADD CONSTRAINT "event_resources_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4295 (class 2606 OID 9481051)
-- Name: events events_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT "events_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4357 (class 2606 OID 9481361)
-- Name: funnel_conversions funnel_conversions_funnelId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.funnel_conversions
    ADD CONSTRAINT "funnel_conversions_funnelId_fkey" FOREIGN KEY ("funnelId") REFERENCES public.funnels(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4358 (class 2606 OID 9481366)
-- Name: funnel_conversions funnel_conversions_stepId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.funnel_conversions
    ADD CONSTRAINT "funnel_conversions_stepId_fkey" FOREIGN KEY ("stepId") REFERENCES public.funnel_steps(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4356 (class 2606 OID 9481356)
-- Name: funnel_steps funnel_steps_funnelId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.funnel_steps
    ADD CONSTRAINT "funnel_steps_funnelId_fkey" FOREIGN KEY ("funnelId") REFERENCES public.funnels(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4355 (class 2606 OID 9481351)
-- Name: funnels funnels_websiteId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.funnels
    ADD CONSTRAINT "funnels_websiteId_fkey" FOREIGN KEY ("websiteId") REFERENCES public.websites(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4326 (class 2606 OID 9481206)
-- Name: integration_configs integration_configs_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.integration_configs
    ADD CONSTRAINT "integration_configs_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4423 (class 2606 OID 9579084)
-- Name: invoice_communications invoice_communications_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_communications
    ADD CONSTRAINT "invoice_communications_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public.invoices(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4424 (class 2606 OID 9579089)
-- Name: invoice_communications invoice_communications_sentBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_communications
    ADD CONSTRAINT "invoice_communications_sentBy_fkey" FOREIGN KEY ("sentBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4420 (class 2606 OID 9579069)
-- Name: invoice_line_items invoice_line_items_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_line_items
    ADD CONSTRAINT "invoice_line_items_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public.invoices(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4421 (class 2606 OID 9579074)
-- Name: invoice_payments invoice_payments_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_payments
    ADD CONSTRAINT "invoice_payments_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public.invoices(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4422 (class 2606 OID 9579079)
-- Name: invoice_payments invoice_payments_verifiedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_payments
    ADD CONSTRAINT "invoice_payments_verifiedBy_fkey" FOREIGN KEY ("verifiedBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4417 (class 2606 OID 9579054)
-- Name: invoices invoices_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4418 (class 2606 OID 9579064)
-- Name: invoices invoices_createdBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 4419 (class 2606 OID 9579059)
-- Name: invoices invoices_subscriptionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_subscriptionId_fkey" FOREIGN KEY ("subscriptionId") REFERENCES public.church_subscriptions(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4348 (class 2606 OID 9481316)
-- Name: kpi_metrics kpi_metrics_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kpi_metrics
    ADD CONSTRAINT "kpi_metrics_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4334 (class 2606 OID 9481246)
-- Name: marketing_campaign_posts marketing_campaign_posts_accountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.marketing_campaign_posts
    ADD CONSTRAINT "marketing_campaign_posts_accountId_fkey" FOREIGN KEY ("accountId") REFERENCES public.social_media_accounts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4335 (class 2606 OID 9481251)
-- Name: marketing_campaign_posts marketing_campaign_posts_campaignId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.marketing_campaign_posts
    ADD CONSTRAINT "marketing_campaign_posts_campaignId_fkey" FOREIGN KEY ("campaignId") REFERENCES public.marketing_campaigns(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4336 (class 2606 OID 9481256)
-- Name: marketing_campaign_posts marketing_campaign_posts_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.marketing_campaign_posts
    ADD CONSTRAINT "marketing_campaign_posts_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4337 (class 2606 OID 9481261)
-- Name: marketing_campaign_posts marketing_campaign_posts_postId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.marketing_campaign_posts
    ADD CONSTRAINT "marketing_campaign_posts_postId_fkey" FOREIGN KEY ("postId") REFERENCES public.social_media_posts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4333 (class 2606 OID 9481241)
-- Name: marketing_campaigns marketing_campaigns_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.marketing_campaigns
    ADD CONSTRAINT "marketing_campaigns_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4405 (class 2606 OID 9481601)
-- Name: member_spiritual_profiles member_spiritual_profiles_memberId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_spiritual_profiles
    ADD CONSTRAINT "member_spiritual_profiles_memberId_fkey" FOREIGN KEY ("memberId") REFERENCES public.members(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4291 (class 2606 OID 9481031)
-- Name: members members_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT "members_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4292 (class 2606 OID 9481036)
-- Name: members members_ministryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT "members_ministryId_fkey" FOREIGN KEY ("ministryId") REFERENCES public.ministries(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4293 (class 2606 OID 9481041)
-- Name: members members_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT "members_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4282 (class 2606 OID 9480986)
-- Name: ministries ministries_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ministries
    ADD CONSTRAINT "ministries_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4410 (class 2606 OID 9481631)
-- Name: ministry_gap_analyses ministry_gap_analyses_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ministry_gap_analyses
    ADD CONSTRAINT "ministry_gap_analyses_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4411 (class 2606 OID 9481626)
-- Name: ministry_gap_analyses ministry_gap_analyses_ministryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ministry_gap_analyses
    ADD CONSTRAINT "ministry_gap_analyses_ministryId_fkey" FOREIGN KEY ("ministryId") REFERENCES public.ministries(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4317 (class 2606 OID 9481161)
-- Name: notification_preferences notification_preferences_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT "notification_preferences_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4318 (class 2606 OID 9481166)
-- Name: notification_templates notification_templates_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_templates
    ADD CONSTRAINT "notification_templates_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4315 (class 2606 OID 9481151)
-- Name: notifications notifications_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT "notifications_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4316 (class 2606 OID 9481156)
-- Name: notifications notifications_createdBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT "notifications_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4378 (class 2606 OID 9481466)
-- Name: online_payments online_payments_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.online_payments
    ADD CONSTRAINT "online_payments_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.donation_categories(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4379 (class 2606 OID 9481471)
-- Name: online_payments online_payments_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.online_payments
    ADD CONSTRAINT "online_payments_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4380 (class 2606 OID 9481476)
-- Name: online_payments online_payments_donationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.online_payments
    ADD CONSTRAINT "online_payments_donationId_fkey" FOREIGN KEY ("donationId") REFERENCES public.donations(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4381 (class 2606 OID 9481481)
-- Name: payment_gateway_configs payment_gateway_configs_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_gateway_configs
    ADD CONSTRAINT "payment_gateway_configs_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4309 (class 2606 OID 9481121)
-- Name: payment_methods payment_methods_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_methods
    ADD CONSTRAINT "payment_methods_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4391 (class 2606 OID 9481531)
-- Name: prayer_approvals prayer_approvals_approvedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_approvals
    ADD CONSTRAINT "prayer_approvals_approvedBy_fkey" FOREIGN KEY ("approvedBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 4392 (class 2606 OID 9481536)
-- Name: prayer_approvals prayer_approvals_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_approvals
    ADD CONSTRAINT "prayer_approvals_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4393 (class 2606 OID 9481541)
-- Name: prayer_approvals prayer_approvals_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_approvals
    ADD CONSTRAINT "prayer_approvals_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public.prayer_contacts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4394 (class 2606 OID 9481546)
-- Name: prayer_approvals prayer_approvals_requestId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_approvals
    ADD CONSTRAINT "prayer_approvals_requestId_fkey" FOREIGN KEY ("requestId") REFERENCES public.prayer_requests(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4384 (class 2606 OID 9481496)
-- Name: prayer_categories prayer_categories_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_categories
    ADD CONSTRAINT "prayer_categories_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4387 (class 2606 OID 9481511)
-- Name: prayer_contacts prayer_contacts_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_contacts
    ADD CONSTRAINT "prayer_contacts_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4395 (class 2606 OID 9481551)
-- Name: prayer_forms prayer_forms_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_forms
    ADD CONSTRAINT "prayer_forms_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4396 (class 2606 OID 9481556)
-- Name: prayer_qr_codes prayer_qr_codes_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_qr_codes
    ADD CONSTRAINT "prayer_qr_codes_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4397 (class 2606 OID 9481561)
-- Name: prayer_qr_codes prayer_qr_codes_formId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_qr_codes
    ADD CONSTRAINT "prayer_qr_codes_formId_fkey" FOREIGN KEY ("formId") REFERENCES public.prayer_forms(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4388 (class 2606 OID 9481516)
-- Name: prayer_requests prayer_requests_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_requests
    ADD CONSTRAINT "prayer_requests_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.prayer_categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4389 (class 2606 OID 9481521)
-- Name: prayer_requests prayer_requests_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_requests
    ADD CONSTRAINT "prayer_requests_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4390 (class 2606 OID 9481526)
-- Name: prayer_requests prayer_requests_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_requests
    ADD CONSTRAINT "prayer_requests_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public.prayer_contacts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4385 (class 2606 OID 9481501)
-- Name: prayer_response_templates prayer_response_templates_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_response_templates
    ADD CONSTRAINT "prayer_response_templates_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.prayer_categories(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4386 (class 2606 OID 9481506)
-- Name: prayer_response_templates prayer_response_templates_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_response_templates
    ADD CONSTRAINT "prayer_response_templates_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4398 (class 2606 OID 9481581)
-- Name: prayer_testimonies prayer_testimonies_approvedBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_testimonies
    ADD CONSTRAINT "prayer_testimonies_approvedBy_fkey" FOREIGN KEY ("approvedBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4399 (class 2606 OID 9481566)
-- Name: prayer_testimonies prayer_testimonies_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_testimonies
    ADD CONSTRAINT "prayer_testimonies_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4400 (class 2606 OID 9481571)
-- Name: prayer_testimonies prayer_testimonies_contactId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_testimonies
    ADD CONSTRAINT "prayer_testimonies_contactId_fkey" FOREIGN KEY ("contactId") REFERENCES public.prayer_contacts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4401 (class 2606 OID 9481576)
-- Name: prayer_testimonies prayer_testimonies_prayerRequestId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prayer_testimonies
    ADD CONSTRAINT "prayer_testimonies_prayerRequestId_fkey" FOREIGN KEY ("prayerRequestId") REFERENCES public.prayer_requests(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4372 (class 2606 OID 9481436)
-- Name: push_notification_logs push_notification_logs_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_notification_logs
    ADD CONSTRAINT "push_notification_logs_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4373 (class 2606 OID 9481441)
-- Name: push_notification_logs push_notification_logs_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_notification_logs
    ADD CONSTRAINT "push_notification_logs_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4370 (class 2606 OID 9481426)
-- Name: push_subscriptions push_subscriptions_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT "push_subscriptions_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4371 (class 2606 OID 9481431)
-- Name: push_subscriptions push_subscriptions_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.push_subscriptions
    ADD CONSTRAINT "push_subscriptions_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4343 (class 2606 OID 9481291)
-- Name: report_executions report_executions_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_executions
    ADD CONSTRAINT "report_executions_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4344 (class 2606 OID 9481296)
-- Name: report_executions report_executions_reportId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_executions
    ADD CONSTRAINT "report_executions_reportId_fkey" FOREIGN KEY ("reportId") REFERENCES public.custom_reports(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4341 (class 2606 OID 9481281)
-- Name: report_schedules report_schedules_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_schedules
    ADD CONSTRAINT "report_schedules_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4342 (class 2606 OID 9481286)
-- Name: report_schedules report_schedules_reportId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_schedules
    ADD CONSTRAINT "report_schedules_reportId_fkey" FOREIGN KEY ("reportId") REFERENCES public.custom_reports(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4284 (class 2606 OID 9480996)
-- Name: role_permissions role_permissions_permissionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT "role_permissions_permissionId_fkey" FOREIGN KEY ("permissionId") REFERENCES public.permissions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4285 (class 2606 OID 9481001)
-- Name: role_permissions role_permissions_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT "role_permissions_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public.roles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4283 (class 2606 OID 9480991)
-- Name: roles roles_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT "roles_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4294 (class 2606 OID 9481046)
-- Name: sermons sermons_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sermons
    ADD CONSTRAINT "sermons_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4351 (class 2606 OID 9481331)
-- Name: sessions sessions_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT "sessions_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4330 (class 2606 OID 9481226)
-- Name: social_media_accounts social_media_accounts_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_media_accounts
    ADD CONSTRAINT "social_media_accounts_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4338 (class 2606 OID 9481266)
-- Name: social_media_metrics social_media_metrics_accountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_media_metrics
    ADD CONSTRAINT "social_media_metrics_accountId_fkey" FOREIGN KEY ("accountId") REFERENCES public.social_media_accounts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4339 (class 2606 OID 9481271)
-- Name: social_media_metrics social_media_metrics_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_media_metrics
    ADD CONSTRAINT "social_media_metrics_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4331 (class 2606 OID 9481231)
-- Name: social_media_posts social_media_posts_campaignId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_media_posts
    ADD CONSTRAINT "social_media_posts_campaignId_fkey" FOREIGN KEY ("campaignId") REFERENCES public.marketing_campaigns(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4332 (class 2606 OID 9481236)
-- Name: social_media_posts social_media_posts_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.social_media_posts
    ADD CONSTRAINT "social_media_posts_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4425 (class 2606 OID 9579094)
-- Name: tenant_credentials tenant_credentials_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenant_credentials
    ADD CONSTRAINT "tenant_credentials_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4426 (class 2606 OID 9579099)
-- Name: tenant_credentials tenant_credentials_createdBy_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenant_credentials
    ADD CONSTRAINT "tenant_credentials_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 4402 (class 2606 OID 9481586)
-- Name: testimony_forms testimony_forms_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.testimony_forms
    ADD CONSTRAINT "testimony_forms_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4403 (class 2606 OID 9481591)
-- Name: testimony_qr_codes testimony_qr_codes_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.testimony_qr_codes
    ADD CONSTRAINT "testimony_qr_codes_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4404 (class 2606 OID 9481596)
-- Name: testimony_qr_codes testimony_qr_codes_formId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.testimony_qr_codes
    ADD CONSTRAINT "testimony_qr_codes_formId_fkey" FOREIGN KEY ("formId") REFERENCES public.testimony_forms(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4286 (class 2606 OID 9481006)
-- Name: user_permissions user_permissions_permissionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT "user_permissions_permissionId_fkey" FOREIGN KEY ("permissionId") REFERENCES public.permissions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4287 (class 2606 OID 9481011)
-- Name: user_permissions user_permissions_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT "user_permissions_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4288 (class 2606 OID 9481016)
-- Name: user_roles_advanced user_roles_advanced_roleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles_advanced
    ADD CONSTRAINT "user_roles_advanced_roleId_fkey" FOREIGN KEY ("roleId") REFERENCES public.roles(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4289 (class 2606 OID 9481021)
-- Name: user_roles_advanced user_roles_advanced_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles_advanced
    ADD CONSTRAINT "user_roles_advanced_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4360 (class 2606 OID 9481376)
-- Name: user_theme_preferences user_theme_preferences_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_theme_preferences
    ADD CONSTRAINT "user_theme_preferences_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4361 (class 2606 OID 9481381)
-- Name: user_theme_preferences user_theme_preferences_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_theme_preferences
    ADD CONSTRAINT "user_theme_preferences_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4290 (class 2606 OID 9481026)
-- Name: users users_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "users_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4303 (class 2606 OID 9481091)
-- Name: visitor_follow_ups visitor_follow_ups_assignedTo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visitor_follow_ups
    ADD CONSTRAINT "visitor_follow_ups_assignedTo_fkey" FOREIGN KEY ("assignedTo") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4304 (class 2606 OID 9481096)
-- Name: visitor_follow_ups visitor_follow_ups_checkInId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visitor_follow_ups
    ADD CONSTRAINT "visitor_follow_ups_checkInId_fkey" FOREIGN KEY ("checkInId") REFERENCES public.check_ins(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4305 (class 2606 OID 9481101)
-- Name: visitor_follow_ups visitor_follow_ups_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.visitor_follow_ups
    ADD CONSTRAINT "visitor_follow_ups_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4299 (class 2606 OID 9481071)
-- Name: volunteer_assignments volunteer_assignments_eventId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.volunteer_assignments
    ADD CONSTRAINT "volunteer_assignments_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES public.events(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4300 (class 2606 OID 9481076)
-- Name: volunteer_assignments volunteer_assignments_volunteerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.volunteer_assignments
    ADD CONSTRAINT "volunteer_assignments_volunteerId_fkey" FOREIGN KEY ("volunteerId") REFERENCES public.volunteers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4412 (class 2606 OID 9481636)
-- Name: volunteer_engagement_scores volunteer_engagement_scores_volunteerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.volunteer_engagement_scores
    ADD CONSTRAINT "volunteer_engagement_scores_volunteerId_fkey" FOREIGN KEY ("volunteerId") REFERENCES public.volunteers(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4407 (class 2606 OID 9481621)
-- Name: volunteer_recommendations volunteer_recommendations_eventId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.volunteer_recommendations
    ADD CONSTRAINT "volunteer_recommendations_eventId_fkey" FOREIGN KEY ("eventId") REFERENCES public.events(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4408 (class 2606 OID 9481611)
-- Name: volunteer_recommendations volunteer_recommendations_memberId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.volunteer_recommendations
    ADD CONSTRAINT "volunteer_recommendations_memberId_fkey" FOREIGN KEY ("memberId") REFERENCES public.members(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4409 (class 2606 OID 9481616)
-- Name: volunteer_recommendations volunteer_recommendations_ministryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.volunteer_recommendations
    ADD CONSTRAINT "volunteer_recommendations_ministryId_fkey" FOREIGN KEY ("ministryId") REFERENCES public.ministries(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4296 (class 2606 OID 9481056)
-- Name: volunteers volunteers_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.volunteers
    ADD CONSTRAINT "volunteers_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4297 (class 2606 OID 9481061)
-- Name: volunteers volunteers_memberId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.volunteers
    ADD CONSTRAINT "volunteers_memberId_fkey" FOREIGN KEY ("memberId") REFERENCES public.members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4298 (class 2606 OID 9481066)
-- Name: volunteers volunteers_ministryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.volunteers
    ADD CONSTRAINT "volunteers_ministryId_fkey" FOREIGN KEY ("ministryId") REFERENCES public.ministries(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4354 (class 2606 OID 9481346)
-- Name: web_page_sections web_page_sections_pageId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.web_page_sections
    ADD CONSTRAINT "web_page_sections_pageId_fkey" FOREIGN KEY ("pageId") REFERENCES public.web_pages(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4353 (class 2606 OID 9481341)
-- Name: web_pages web_pages_websiteId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.web_pages
    ADD CONSTRAINT "web_pages_websiteId_fkey" FOREIGN KEY ("websiteId") REFERENCES public.websites(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4359 (class 2606 OID 9481371)
-- Name: website_analytics website_analytics_websiteId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.website_analytics
    ADD CONSTRAINT "website_analytics_websiteId_fkey" FOREIGN KEY ("websiteId") REFERENCES public.websites(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4413 (class 2606 OID 9481656)
-- Name: website_requests website_requests_assignedTo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.website_requests
    ADD CONSTRAINT "website_requests_assignedTo_fkey" FOREIGN KEY ("assignedTo") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4414 (class 2606 OID 9481641)
-- Name: website_requests website_requests_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.website_requests
    ADD CONSTRAINT "website_requests_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 4415 (class 2606 OID 9481646)
-- Name: website_requests website_requests_existingWebsiteId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.website_requests
    ADD CONSTRAINT "website_requests_existingWebsiteId_fkey" FOREIGN KEY ("existingWebsiteId") REFERENCES public.websites(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4416 (class 2606 OID 9481651)
-- Name: website_requests website_requests_resultingWebsiteId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.website_requests
    ADD CONSTRAINT "website_requests_resultingWebsiteId_fkey" FOREIGN KEY ("resultingWebsiteId") REFERENCES public.websites(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 4352 (class 2606 OID 9481336)
-- Name: websites websites_churchId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.websites
    ADD CONSTRAINT "websites_churchId_fkey" FOREIGN KEY ("churchId") REFERENCES public.churches(id) ON UPDATE CASCADE ON DELETE CASCADE;


-- Completed on 2025-09-13 15:19:55 UTC

--
-- PostgreSQL database dump complete
--

\unrestrict B3jLODoHhVKSjfpotVRHbM1L7ybdKC8dB9UpLxw3b0EVKJfIRVZN0ftssiU86fc

