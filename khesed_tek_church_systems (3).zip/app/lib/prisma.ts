
export { db as prisma } from './db'
