"use client";
// hooks/use-theme.ts
// Lightweight theme context — no external deps, SSR-safe.
// Persists preference to localStorage under "khesed-theme".

import { createContext, useContext, useState, useEffect, useCallback } from "react";

export type Theme = "dark" | "light";

interface ThemeCtx {
  theme: Theme;
  toggle: () => void;
  isDark: boolean;
}

export const ThemeContext = createContext<ThemeCtx>({
  theme: "dark",
  toggle: () => {},
  isDark: true,
});

export function useTheme() {
  return useContext(ThemeContext);
}

export function useThemeState(): ThemeCtx {
  const [theme, setTheme] = useState<Theme>("dark");

  // Hydrate from localStorage once on mount
  useEffect(() => {
    try {
      const saved = localStorage.getItem("khesed-theme") as Theme | null;
      if (saved === "light" || saved === "dark") setTheme(saved);
    } catch {}
  }, []);

  const toggle = useCallback(() => {
    setTheme((prev) => {
      const next: Theme = prev === "dark" ? "light" : "dark";
      try { localStorage.setItem("khesed-theme", next); } catch {}
      return next;
    });
  }, []);

  return { theme, toggle, isDark: theme === "dark" };
}
