# Khesed-UI · Cosmos Design System v2 — INSTALL

## What's new in v2
- ☀️ **Light / Dark theme toggle** — button in the header (☀️ / 🌙)
- Preference persisted to `localStorage` under `khesed-theme`
- Smooth 300ms transitions on all background/border/text colours
- Canvas backgrounds (star field, constellation map) adapt per theme
- All hardcoded dark rgba values replaced with `--glass-*` CSS variables

## Files added / changed

| File | Change |
|------|--------|
| `styles/cosmos-tokens.css` | Full `[data-theme="light"]` block + `--glass-*` tokens |
| `hooks/use-theme.ts` | **NEW** — `ThemeContext`, `useTheme`, `useThemeState` |
| `app/cosmos-dashboard.tsx` | ThemeProvider wrapper + `ThemeToggle` button in header |
| `components/cosmos/cosmos-background.tsx` | Theme-aware star field canvas |
| `components/cosmos/constellation-map.tsx` | Theme-aware node canvas |
| `components/cosmos/cosmos-stat-card.tsx` | CSS-var backgrounds |
| `components/volunteers/coverage-cosmos-card.tsx` | CSS-var backgrounds |
| `components/dashboard/shepherds-log-cosmos.tsx` | CSS-var backgrounds |
| `components/triage/triage-cosmos-alert.tsx` | CSS-var backgrounds |

## Installation steps

1. Copy `styles/cosmos-tokens.css` → import in `app/globals.css`
2. Copy `hooks/use-theme.ts` alongside your other hooks
3. Copy all updated component files to their directories
4. Replace `dashboard-client.tsx` with `app/cosmos-dashboard.tsx`
5. Run `npm install` (no new packages needed)

## Using the theme in custom components

```tsx
import { useTheme } from "@/hooks/use-theme";

function MyComponent() {
  const { isDark } = useTheme();
  return (
    <div style={{ background: "var(--glass-card-bg)" }}>
      {isDark ? "Dark mode" : "Light mode"}
    </div>
  );
}
```

## CSS token reference (glass layer)

| Token | Dark | Light |
|-------|------|-------|
| `--glass-header-bg` | `rgba(5,8,15,0.78)` | `rgba(255,255,255,0.90)` |
| `--glass-sidebar-bg` | `rgba(5,8,15,0.60)` | `rgba(255,253,248,0.85)` |
| `--glass-card-bg` | `rgba(13,22,40,0.72)` | `rgba(255,255,255,0.92)` |
| `--glass-inner-bg` | `rgba(13,22,40,0.45)` | `rgba(240,234,222,0.55)` |
| `--glass-divider` | `rgba(201,146,42,0.10)` | `rgba(160,120,50,0.12)` |
| `--section-label` | `#7A5218` | `#9a6f2a` |
